// boardmodel.js
var mongoose = require('mongoose');
var BoardSchema = new mongoose.Schema({
	num: Number,
	writer: String,
	title: String,
	content: String,
	pwd: String,
	hit: { type:Number, default: 0 },
	regdate: { type:Date, default: Date.now }
});

var Board = mongoose.model('Board', BoardSchema);
module.exports = Board;