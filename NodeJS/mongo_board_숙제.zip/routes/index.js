var express = require('express');
var router = express.Router();
var ObjectId = require('mongodb').ObjectID;

var db = require('../models/db');
var Board = require('../models/boardmodel');
require('../common/dateFormat');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/list', function(req, res, next) {
	var page = 1;
	if(req.query.page != null)
		page = req.query.page;

	db.collection('boards').count({}, function (err, result){
		if(err) { next(err); return; }
		
		db.collection('boards').find({}, {}, {skip: (page-1) * 10, limit: 10, sort:{ num: -1}}).toArray(function(err, docs) {
			if(err) { next(err);}
			else {
				for(var item in docs) {
					docs[item].regdate = docs[item].regdate.format("yyyy-MM-dd HH:mm:ss");
				}
				
				var data = {
					title: '리스트',
					rows: docs,
					page: page,
					totalCount: result
				}
				res.render('list', data);
			}
		});
	});
});

router.get('/view', function(req, res, next) {
	if (isNaN(req.query.num)) {
		ok(res, '잘못된 요청입니다.', './list');
	}
	else {
		db.collection('boards').findOne({num: eval(req.query.num)}, function(err, doc) {
			if(err) { next(err); }
			else {
				doc.hit = doc.hit + 1;
				db.collection('boards').update({_id: ObjectId(doc._id)}, {$set:{
					hit: doc.hit
				}});
				
				doc.regdate = doc.regdate.format("yyyy-MM-dd HH:mm:ss");
				var data = {
					title: '글보기',
					rows: doc
				}
				
				res.render('view', data);
			}
		});
	}
});

router.get('/writeform', function(req, res, next) {
	if(req.query.num == null) {
		var data = {
			title: '글쓰기',
			rows: null
		}

  		res.render('writeform', data);
	}
	else {
		db.collection('boards').findOne({num: eval(req.query.num)}, function(err, doc) {
			if(err) { next(err); return; }
			else {
				var data = {
					title: '글쓰기',
					rows: doc
				}
				
				res.render('writeform', data);
			}
		});
	}
});

router.get('/deleteform', function(req, res, next) {
	if (isNaN(req.query.num)) {
		ok(res, '잘못된 요청입니다.', './list');
	}
	else {
		db.collection('boards').findOne({num: eval(req.query.num)}, function(err, doc) {
			if(err) { next(err); return; }
			else {
				var data = {
					title: '글삭제',
					rows: doc
				}
				console.log(doc);
				res.render('deleteform', data);
			}
		});
	}
});

router.post('/write', function(req, res, next) {
	var id = req.body.id;
	var num = req.body.num;
	var writer = req.body.writer;
	var pwd = req.body.pwd;
	var title = req.body.title;
	var content = req.body.content;

	if (id === '') {
		db.collection('boards').findOne({}, {num:1}, {sort:{ num: -1}}, function(err, result) {
			if(err) { next(err); return; }
			else {
				num = result.num + 1;
				
				var boardModel = db.model('Board');
				var board = new boardModel({
					num: num,
					writer: writer,
					title: title,
					content: content,
					pwd: pwd
				});
				
				board.save(function(err, doc) {
					if(err) { next(err); }
					else {
						ok(res, '저장성공', './list');
					}
				});
			}
		});
	}
	else {
		db.collection('boards').findOne({_id: ObjectId(id), pwd: pwd}, function(err, result) {
			if(err) { next(err); return; }
			else {
				if(result == null) {
					ok(res, '비밀번호가 틀렸습니다.', './writeform?num=' + num);
				}
				else {
					db.collection('boards').update({_id: ObjectId(id)}, {$set:{
						num: eval(num),
						writer: writer,
						title: title,
						content: content,
						pwd: pwd
					}});
					
					ok(res, '저장성공', './list');
				}
			}
		});
	}
});

router.post('/delete', function(req, res, next) {
	var id = req.body.id;
	var num = req.body.num;
	var pwd = req.body.pwd;

	db.collection('boards').findOne({_id: ObjectId(id), pwd: pwd}, function(err, result) {
		if(err) { next(err); return; }
		else {
			if(result == null) {
				ok(res, '비밀번호가 틀렸습니다.', './deleteform?num=' + num);
			}
			else {
				db.collection('boards').remove({_id: ObjectId(id)});
				
				ok(res, '삭제성공', './list');
			}
		}
	});
});

function ok(res, message, url) {
	var str = "<script type='text/javascript'>alert('" + message + "');location.href = '" + url + "';</script>";
	res.send(str);
	res.end();
}

module.exports = router;


// var express = require('express');
// var router = express.Router();

// var db = require('../models/db');
// require('../models/boardmodel');
// var BoardModel = db.model('Board');

// /* GET home page. */
// router.get('/', function(req, res, next) {
//   res.render('index', { title: 'Express' });
// });

// router.get('/writeform', function(req, res, next) {
//   res.render('writeform', { title: '글쓰기' });
// });

// router.post('/write', function(req, res, next) {
// 	console.log('req.body=', req.body);
// 	var name = req.body.name;
// 	var title = req.body.title;
// 	var content = req.body.content;
// 	var pw = req.body.pw;
// 	// 저장할 객체 생성
// 	var board = new BoardModel({
// 		name: name,
// 		title: title,
// 		content: content,
// 		pwd: pwd
// 	});
// 	board.save(function(err, doc) {
// 		if(err) console.log('err', err);
// 		console.log(doc);
// 		res.send("OK");
// 	});
// });