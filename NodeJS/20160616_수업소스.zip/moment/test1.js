// test1.js
var moment = require('moment');

var day = moment().format('YYYY-MM-DD hh:mm.ss');
console.log('day', day);

var arr = [1,2,3,4,5];

var arr2 = [];
for(var i=0; i<arr.length; i++) {
	arr2.push(arr[i] * arr[i]);
}
console.log(arr2); // [1, 4, 9, 16, 25]

var arr3 = arr.map(function (a) { return a*a; });
console.log(arr3); // [1, 4, 9, 16, 25]