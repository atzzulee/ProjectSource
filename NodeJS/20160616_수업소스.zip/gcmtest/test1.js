// //test1.js
var gcm = require('node-gcm');

// create a message with default values

var message = new gcm.Message({
	collapseKey: 'demo',
	priority: 'high',
	contentAvailable: true,
	delayWhileIdle: true,
	timeToLive: 3,
	restrictedPackageName: "com.pcm.pcmmanager",
	//dryRun: true,
	data: {
		code: 'code',
		title: 'title',
		message: 'message'

	}
});


console.log(message.params.data);
var server_access_key = 'AIzaSyAPE8FqNwZrF0w_0k-LOcq6Ry-5gChWLuI';
var sender = new gcm.Sender(server_access_key);
var registrationIds = [];

var registration_id = "dHBszmqTwq0:APA91bEbIY9gOrPyX1WPUgEGgtOVpATMXWDeKrFlU8BY9E4lmKje44mcJjxIH1rAapkn0JxhFB_kQSUAGe7-Y_JLiC7EByXNxXRWPVzEuot_kaSeuRB3jrQ-Pk1NMIlIkdBsHqIATJ5w";
// At least one required
// for(var i = 0 ; i < 1000 ; ++i)
// 		registrationIds.push(registration_id);
	registrationIds.push(registration_id);

/**
 * Params: message-literal, registrationIds-array, No. of retries, callback-function
 **/
sender.send(message, registrationIds, 4, function (err, result) {
});