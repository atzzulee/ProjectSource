// //test1.js
// var gcm = require('node-gcm');
// // or with object values
// var message = new gcm.Message({
//      collapseKey: 'demo',
//      delayWhileIdle: true,
//      timeToLive: 3,
//      data: {
//           lecture_id:"notice",
//           title:"제목입니다",
//           desc: "설명입니다",
//           param1: '첫번째파람',
//           param2: '두번째파람'
//      }
// });

// // Sender sender = new Sender("AIzaSyC01K-qcS5Vs3X1ar58oFfCfNcKfDkp0Fo"); // 서버 API Key 입력
// // 		String regId = "APA91bENwaQQPCuMkgQyobkouNQvwwoZMaGYDhl9CAQsEQj8IOhZTqDGr5SSrJxRuS9ZsZ_5UzyWD9tnB3nXvaeBzlLoZK9O4RBAc5JHVDs2U-5J--F9hHD5Q7GVkst7-bzvg3fipK_0";

// var server_access_key = 'AIzaSyC01K-qcS5Vs3X1ar58oFfCfNcKfDkp0Fo';
// var sender = new gcm.Sender(server_access_key);
// var registrationIds = [ ];     // 여기에 pushid 문자열을 넣는다.

// registrationIds = ['/*안드로이드 단말기에서 나온 푸시 아이디*/'];

// /*
// for (var i=0; i<push_ids.length; i++) {
//      registrationIds.push(push_ids[i]);
// }
// */
// registrationIds.push("APA91bENwaQQPCuMkgQyobkouNQvwwoZMaGYDhl9CAQsEQj8IOhZTqDGr5SSrJxRuS9ZsZ_5UzyWD9tnB3nXvaeBzlLoZK9O4RBAc5JHVDs2U-5J--F9hHD5Q7GVkst7-bzvg3fipK_0");
// // 푸시를 날린다!
// sender.send(message, registrationIds, 4, function (err, result) {
//      // 여기서 푸시 성공 및 실패한 결과를 준다. 재귀로 다시 푸시를 날려볼 수도 있다.
//      console.log(result);
// });

var gcm = require('node-gcm');

// create a message with default values
var message = new gcm.Message();

// or with object values
// var message = new gcm.Message({
//     collapseKey: 'demo',
//     delayWhileIdle: true,
//     timeToLive: 3,
//     data: {
//         code: '001',
//         message: 'push test'
//     }
// });

var message = new gcm.Message({
	collapseKey: 'demo',
	priority: 'high',
	contentAvailable: true,
	delayWhileIdle: true,
	timeToLive: 3,
	restrictedPackageName: "com.pcm.pcmmanager",
	//dryRun: true,
	data: {
		code: 'code',
		title: 'title',
		message: 'message'

	}
	// notification: {
	// 	title: "Hello, World",
	// 	icon: "ic_launcher",
	// 	body: "Body Message."
	// }
});

//var server_access_key = 'AIzaSyC01K-qcS5Vs3X1ar58oFfCfNcKfDkp0Fo';
var server_access_key = 'AIzaSyAPE8FqNwZrF0w_0k-LOcq6Ry-5gChWLuI';
var sender = new gcm.Sender(server_access_key);
var registrationIds = [];

//var registration_id = "APA91bENwaQQPCuMkgQyobkouNQvwwoZMaGYDhl9CAQsEQj8IOhZTqDGr5SSrJxRuS9ZsZ_5UzyWD9tnB3nXvaeBzlLoZK9O4RBAc5JHVDs2U-5J--F9hHD5Q7GVkst7-bzvg3fipK_0";
var registration_id = "cHqU909mJEQ:APA91bFlkrqnbJHFwwodEnwPwCraVf3G6nKAi3TI02Rl1LiGZy3OzzbW11h8-pnaq3bUBezPtAhGYsZkYi4D9HwXNRS7XJJ29XoDQcMB18j46GY1z6rmiiUY3cVqjvT2yC6lILsRXkl2";
// At least one required
// for(var i = 0 ; i < 1000 ; ++i)
// 		registrationIds.push(registration_id);
	registrationIds.push(registration_id);

/**
 * Params: message-literal, registrationIds-array, No. of retries, callback-function
 **/
sender.send(message, registrationIds, 4, function (err, result) {
    console.log(result);
});