var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.post('/login', function(req, res, next) {
  req.checkBody('email', '맞는 이메일을 입력하세요!').isEmail();
  req.checkBody('pw', '비밀번호는 영어와 숫자만 가능합니다!').isAlphanumeric();

  var errors = req.validationErrors();
  if (errors) {
  	//res.json({errors: errors});
  	res.render('login_error', {errors: errors})
  } else {
  	res.json({result:'ok'});
  }
});

module.exports = router;
