﻿var mongoose = require('mongoose');
var url = 'mongodb://localhost:27017/testdb';
var options = {
	server: { poolSize : 100 }
}
var async = require('async');

var db = mongoose.createConnection(url, options);

db.on('error', function(err) {
	console.err('Error : ', err);
});

db.on('open', function() {
	console.info('Mongo DB Connected Successfully.');

    var expertSchema = new mongoose.Schema({
        expertsn: Number, // 전문가일련번호
        usersn: Number, // 유저일련번호,
        expertname: String, // 이름
        photo: String, // 이미지경로
        diploma: String, // 대학 졸업 증명서
        certificate: String, // 건강보험자격득실확인서
        mainintroduce: String, // 메인소개글
        detailintroduce: String, // 상세소개글
        officename: String, //사무실명
        homepage: String, // 홈페이지
        tel: String, // 전화번호
        address: String, // 번지주소
        regiontype: String, // 지역타입1
        regionsubtype: String, // 지역타입2
        license: String, // 자격증
        academic: [{
            start: Number, // 시작
            end: Number, // 끝
            name: String // 이름
        }], // 학력
        sex: String, // 성별 
        belongto: String, // 소속
        record: [{
            start: Number, // 시작
            end: Number, // 끝
            name: String // 이름
        }], // 이력
        career: Number, //경력
        age: Number, // 나이
        categorys: [{
            markettype: String, // 메인코드
            marketsubtype: String // 서브코드
        }], // 전문분야 카테고리 리스트 (최대3개)
        dishs: [], // 찜 리스트 (최대20개)
        mileage: Number, // 마일리지
        sort: {type: Number, default: 1}, // 정렬값
        regdate: String, // 등록일
        useyn: {type: Boolean, default: true} // 사용여부
    });

var model = db.model('Expert', expertSchema);











	var arr = [1, 2, 3, 4,5];
	var asyncTasks = [];

	// arr.forEach(function(item) {
	// 	var task = function (callback) {
	// 		db.collection('boards').findOne({sn:item}, function(err, doc) {
	// 			if (err) { next(err); return; }
	// 			callback (null, doc);
	// 		});
	// 	}

	// 	asyncTasks.push(task);
	// });

	// async.series(asyncTasks, function (err, results) {
	// 	if (err) { console.log('에러') }
	// 	else {
	// 		console.log(results)
	// 	}
	// });

	// async.parallel(asyncTasks, function (err, results) {
	// 	if (err) { console.log('에러') }
	// 	else {
	// 		console.log(results)
	// 	}
	// });
	
	
	
	
	
    var useyn = { 'useyn': true };
    var field = { 'expertsn': 1 };
    // var where = { 'expertsn': 1 }
    // var set = { '$set' : { 'sort': Math.random() }}
    // model.update(where, set).then( function (dbresult) {
    //     console.log(dbresult);
    //     if (dbresult.n == 0) {
    //         callback(false);
    //     } else {
    //         callback(true);
    //     }
    // }, function (err) {
    //     callback(false);
    // });
    
    // 리스트 조회 프로세스
    model.find(useyn, field).then( function (docs) {
	    var asyncTasks = [];
		console.log(docs);
        // docs.forEach( function (item) {
        //     var task = function (callback) {
        //         var where = { 'expertsn': 1 }
        //         var set = { '$set' : { 'sort': Math.random() }}
        //         model.findOne(where).then( function (err, doc) {
        //             if (err) { next(err); return; }
        //             callback (null, doc);
        //         });
        //         // model.update(where, set).then( function (dbresult) {
        //         //     if (dbresult.n == 0) {
        //         //         cb(false, null);
        //         //     } else {
        //         //         cb(true, doc);
        //         //     }
        //         // }, function (err) {
        //         //     cb(false, null);
        //         // });
        //     }

        //     asyncTasks.push(task);
        // });
        
        // async.series(asyncTasks, function (err, results) {
        //     console.log(results);
        //     if (err) {
        //         callback(false);
        //     }
        //     else {
        //         console.log(results);
        //         callback(true);
        //     }
        // });
        
			
        docs.forEach(function(item) {
			var where = { 'expertsn': item.expertsn };
			var set = { '$set' : { 'sort': Math.random() }};
			
            var task = function (cb) {
                model.update(where, set).then( function (dbresult) {
                    if (dbresult.nModified == 0) {
                        cb(null, false);
                    }
                    else {
                        console.log(4);
                        cb(null, true);
                    }
                }, function (err) {
                    cb(null, false);
                });
            }
            asyncTasks.push(task);
        });
        
        async.parallel(asyncTasks, function (err, results) {
            if (err) { console.log('에러'); }
            else {
                console.log(results);
            }
        });
    });
	
	
	
	
	
	
	
	
	
	
	
	
	
});


// function task1(callback) {
// 	console.log('Task1 시작');
// 	setTimeout(function() {
// 		console.log('Task1 끝');
// 		//callback(null, 'Task1 결과');
// 		callback("Error", null);
// 	}, 300);
// }


// function task2(callback) {
// 	console.log('Task2 시작');
// 	setTimeout(function() {
// 		console.log('Task2 끝');
// 		callback(null, 'Task2 결과');
// 	}, 200);
// }

// async.series([task1, task2], function(err, results) {
// 	if ( err ) {
// 		console.error('Error : ', err);
// 		return;
// 	}
// 	console.log('비동기 동작 모두 종료 ', results)
// });
