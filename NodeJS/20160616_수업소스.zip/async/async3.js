// async3.js
var async = require('async');

async.parallel([
    function(callback){
        setTimeout(function(){
            console.log('1');
            callback(null, 'one');
        }, 200);
    },
    function(callback){
        setTimeout(function(){
            console.log('2');
            callback(null, 'two');
        }, 100);
    }
],
// optional callback
function(err, results){
    console.log(results);
    // the results array will equal ['one','two'] even though
    // the second function had a shorter timeout.
});