// async2.js
var async = require('async');
// an example using an object instead of an array

async.series({
    one: function(callback){
        setTimeout(function(){
        		console.log('1');
            callback(null, 1);
        }, 200);
    },
    two: function(callback){
        setTimeout(function(){
        		console.log('2');
            callback(null, 2);
        }, 100);
    }
},
function(err, results) {
	console.log(results);
    // results is now equal to: {one: 1, two: 2}
});