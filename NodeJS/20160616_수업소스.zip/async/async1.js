// async1.js
var async = require('async');

async.series([
    function(callback){
        // do some stuff ...
        console.log('first');
        callback(null, 'one');
    },
    function(callback){
        // do some more stuff ...
        console.log('second');
        callback(null, 'two');
    }
],
// optional callback
function(err, results){
    console.log(results);
});
