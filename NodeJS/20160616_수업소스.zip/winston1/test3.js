// test3.js
var logger = require('./logger');
logger.debug('debug1');
logger.verbose('verbose1');
logger.info('info1');
logger.warn('warn1');
logger.error('error1');