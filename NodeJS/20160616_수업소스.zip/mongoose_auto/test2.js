//test1.js
var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var connection = mongoose.createConnection('mongodb://localhost/pre');

var CounterSchema = Schema({
	_id:{type:String, required:true},
	seq: {type:Number, default:0}
});

var Counter = connection.model('Counter', CounterSchema);

var EntitySchema = mongoose.Schema({
	num:Number,
	title:String
});

EntitySchema.pre('save', function(next){
	var doc = this;
	Counter.findOneAndUpdate({_id:'entityId'}, {$inc:{seq:1}},{upsert:true, new:true}, function(err, pre_doc){
		if(err){
			return next(err);
		}
		console.log('pre_doc', pre_doc);
		doc.num = pre_doc.seq;
		next();
	});
});

var Entity = connection.model('Entity', EntitySchema);
var entity = new Entity({title:'테스트1'});
entity.save(function(err,doc){
	console.log(doc);
});
