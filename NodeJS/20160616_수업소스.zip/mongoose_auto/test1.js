// test1.js
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    autoIncrement = require('mongoose-auto-increment');

var connection = mongoose.createConnection("mongodb://localhost/myDatabase");

// INSERT 예제
// autoIncrement.initialize(connection);

var bookSchema = new Schema({
    author: String,
    title: String,
    genre: String,
    publishDate: {type: Date, default: Date.now}
});

// bookSchema.plugin(autoIncrement.plugin, { model: 'Book', field: 'Sn' });
// var Book = connection.model('Book', bookSchema);

// var obj = {'author':'홍길동', 'title':'node 개발', 'genre':'it분야', 'publishDate': new Date()};

// var book1 = new Book(obj);
// book1.save().then( function (doc) {
//   console.log(doc);
// }, function (err) {
//   console.log(err);
// });


// // 여러개 SELECT 예제
// var data = {'author':'홍길동1234'};
// var Book = connection.model('Book', bookSchema);
// Book.find(data).then( function (docs) {
// 	console.log(docs);
// }, function (err) {
//   console.log(err);
// });

// 1개 SELECT 예제
// var data = {'author':'홍길동123'};
// var Book = connection.model('Book', bookSchema);
// Book.findOne(data).then( function (doc) {
// 	if (doc != null) {
// 		console.log(doc);
// 	}
// 	else {
// 		console.log('실패');
// 	}
// }, function (err) {
//   console.log(err);
// });


// var data = {'author':'홍길동1112', 'title':'node 개발111', 'genre':'it분야111'};
// var sn = {'Sn':4};
// var Book = connection.model('Book', bookSchema);
// Book.update(sn, {$set:data}).then( function (result) {
// 	console.log(result);
// 	if (result.n > 0) {
// 		console.log('성공');
// 	}
// 	else {
// 		console.log('실패');
// 	}
// }, function (err) {
//   console.log(err);
// });


