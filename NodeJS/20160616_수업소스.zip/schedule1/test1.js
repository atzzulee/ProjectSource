//test1.js

var schedule = require('node-schedule');

var j = schedule.scheduleJob('45 * * * *',function(){
	console.log('The answer to life');
});