// lotto_prize.js
var request = require('request');
var cheerio = require('cheerio');
var iconv = require('iconv-lite');
iconv.skipDecodeWarning = true;

var options = {
	uri: 'http://nlotto.co.kr/lotto645Confirm.do?method=myWin',
	encoding: 'binary'
};

request(options, function(err, res, body) {
	if (err) return console.err('err', err);
	var strContents = iconv.decode(body, 'euc-kr');

	var $ = cheerio.load(strContents);
	$('.lotto_win_number > .number > img').each( function (i, item) {
		console.log($(item).attr('alt'));
	});
	var bonus = $('.number_bonus > img').attr('alt');
	console.log(bonus);
	//console.log($('.lotto_win_number > .number').html());
});