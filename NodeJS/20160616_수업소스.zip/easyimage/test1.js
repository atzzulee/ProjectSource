var easyimage = require('easyimage');
var srcImg = 'lena.png';
var idx = srcImg.lastIndexOf('.');
var name = srcImg.substring(0, idx); // lena
var ext = srcImg.substring(idx); // .png
var dstImg = name + '-thumbnail' + ext; // lena=tumnail.png

var obj = {
	src: srcImg,
	dst: dstImg,
	width: 128,
	heigth : 128,
	x: 0,
	y: 0
};

easyimage.thumbnail(obj).then(function (file) {
	console.log(file);
}, function (err) {
	console.log(err.message);
});