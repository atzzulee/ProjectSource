var express = require('express');
var multer = require('multer');
var router = express.Router();

var upload = multer({
	dest:'./public/images',
});

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/uploadform', function(req, res, next) {
	res.render('uploadform', {title:'업로드'});
});


// var cpUpload = upload.fields([{ name1: 'avatar', maxCount: 1 }, { name: 'gallery', maxCount: 8 }])
// app.post('/cool-profile', cpUpload, function (req, res, next) {
//   // req.files is an object (String -> Array) where fieldname is the key, and the value is array of files
//   //
//   // e.g.
//   //  req.files['avatar'][0] -> File
//   //  req.files['gallery'] -> Array
//   //
//   // req.body will contain the text fields, if there were any
// })

// router.post('/upload', upload.single('file1'), function(req, res, next) {
// 	console.log(req.body);
// 	console.log(req.file);
// });

var cpUpload = upload.fields([{ name: 'file1', maxCount: 1 }, { name: 'file2', maxCount: 1 }, { name: 'file3', maxCount: 1 }])
router.post('/upload', cpUpload, function(req, res, next) {
	console.log(req.body);
	console.log(req.files);
});

module.exports = router;
