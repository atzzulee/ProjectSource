// todo.js
var myTodo = angular.module('myTodo', [])
.controller('mainController', function($scope, $http) {
		$scope.formData = {};
		// todo 리스트 얻기
		$http.get('/todos').success(function (data) {
				$scope.todos = data;
		}).error(function(err) {
				alert('list err=' + err);
				console.log('list err', err);
		});

		// todo 저장
		$scope.createTodo = function () {
				$http.post('/todos', $scope.formData).success(function (data) {
						$scope.todos = data;
						$scope.formData = {};
				}).error(function (err) {
						alert('createTodo err=' + err);
						console.log('createTodo err', err);
				});
		} //createTodo

		// todo 삭제
		$scope.deleteTodo = function (id) {
				$http.delete('/todos/' + id).success(function (data) {
						$scope.todos = data;
				}).error(function (err) {
						alert('deleteTodo err=' + err);
						console.log('deleteTodo err', err);
				});
		} //deleteTodo
	} //mainContoroller
);