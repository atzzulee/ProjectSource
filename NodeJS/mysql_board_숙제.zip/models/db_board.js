//db_board.js
var mysql = require('mysql');
var pool  = mysql.createPool({
  connectionLimit : 10, // default: 250
  host            : 'localhost',
  user            : 'root',
  password        : '1234',
  database        : 'test'
});

module.exports = pool;