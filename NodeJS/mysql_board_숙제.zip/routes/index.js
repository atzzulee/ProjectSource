var express = require('express');
var router = express.Router();
var pool = require('../models/db_board');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/list', function(req, res, next) {
	res.redirect('/list/1');
});

router.get('/list/:page', function(req, res, next) {
	var page = 1;
	if (req.params.page != null)
		page = req.params.page;

	pool.getConnection(function(err, connection) {
		if (err) { next(err); }

		connection.query('SELECT COUNT(*) AS totalCount FROM board', function(err, result) {
			if (err) { next(err); }
			else {
				connection.query('SELECT num, title, writer, DATE_FORMAT(regdate, "%Y-%m-%d %H:%i:%s") AS regdate, hit FROM board order by num desc limit ?, ?', [(page-1) * 10, 10], function(err, rows) {
					if (err) { next(err); }
					else {
						var data = {
							title: '리스트',
							rows: rows,
							page: page,
							totalCount: result[0].totalCount
						}
						res.render('list', data);
					}
				});
			}

			connection.release();
		});
	});
});

router.get('/view/:num', function(req, res, next) {
	var num = req.params.num;

	if (isNaN(num)) {
		ok(res, '잘못된 요청입니다.', '/list');
	}
	else {
		pool.getConnection(function(err, connection) {
			if (err) { next(err); }

			connection.query('UPDATE board SET hit = hit + 1 WHERE num = ?', [num], function(err, result) {
				if (err) { next(err); }
				else {
					if (result.affectedRows == 0) {
						ok(res, '잘못된 요청입니다.', '/list');
					}
					else {
						connection.query('SELECT num, title, writer, content, DATE_FORMAT(regdate, "%Y-%m-%d %H:%i:%s") AS regdate, hit FROM board WHERE num = ?', [num], function(err, rows) {
							if (err) { next(err); }
							else {
								if (rows.length == 0) {
									ok(res, '잘못된 요청입니다.', '/list');
								}
								else {
									var data = {
										title: '글보기',
										row: rows[0]
									}

									res.render('view', data);
								}
							}
						});
					}
				}

				connection.release();
			});
		});
	}
});

router.get('/writeform', function(req, res, next) {
	var data = {
		title: '글쓰기',
		row: null
	}

	res.render('writeform', data);
});

router.get('/writeform/:num', function(req, res, next) {
	var num = req.params.num;

	if (isNaN(num)) {
		ok(res, '잘못된 요청입니다.', '/list');
	}
	else {
		pool.getConnection(function(err, connection) {
			if (err) { next(err); }

			connection.query('SELECT num, title, writer, content, DATE_FORMAT(regdate, "%Y-%m-%d %H:%i:%s") AS regdate, hit FROM board WHERE num = ?', [num], function(err, rows) {
				if (err) { next(err); }
				else {
					if (rows.length == 0) {
						ok(res, '잘못된 요청입니다.', '/view/'+ num);
					}
					else {
						var data = {
							title: '글쓰기',
							row: rows[0]
						}

						res.render('writeform', data);
					}
				}

				connection.release();
			});
		});
	}
});

router.get('/deleteform/:num', function(req, res, next) {
	var num = req.params.num;

	if (isNaN(num)) {
		ok(res, '잘못된 요청입니다.', '/list');
	}
	else {
		pool.getConnection(function(err, connection) {
			if (err) { next(err); }

			connection.query( 'SELECT num, title, writer, content, DATE_FORMAT(regdate, "%Y-%m-%d %H:%i:%s") AS regdate, hit FROM board WHERE num = ?', [num], function(err, rows) {
				if (err) { next(err); }
				else {
					if (rows.length == 0) {
						ok(res, '잘못된 요청입니다.', '/list');
					}
					else {
						var data = {
							title: '글삭제',
							row: rows[0]
						}

						res.render('deleteform', data);
					}
				}

				connection.release();
			});
		});
	}
});

router.post('/write', function(req, res, next) {
	var num = req.body.num;
	var writer = req.body.writer;
	var pwd = req.body.pwd;
	var title = req.body.title;
	var content = req.body.content;

	pool.getConnection(function(err, connection) {
		if (err) { next(err); }
		else {
			if (num == 0) {
				connection.query('INSERT INTO board(writer, title, content, pwd, hit, regdate) VALUES (?, ?, ?, ?, 0, now())', [writer, title, content, pwd], function(err, result) {
					if (err) { next(err); }
					else {
						if (result.affectedRows == 0) {
							ok(res, '잘못된 요청입니다.', '/list');
						}
						else {
							ok(res, '저장성공', '/list');
						}
					}

					connection.release();
				});
			}
			else {
				connection.query('UPDATE board SET writer = ?, title = ?, content = ? WHERE num = ? AND pwd = ?', [writer, title, content, num, pwd], function(err, result) {
					if (err) { next(err); }
					else {
						if (result.affectedRows == 0) {
							back(res, '비밀번호가 틀렸습니다.');
						}
						else {
							ok(res, '저장성공', '/list');
						}
					}

					connection.release();
				});
			}
		}
	});
});

router.post('/delete', function(req, res, next) {
	var num = req.body.num;
	var pwd = req.body.pwd;

	pool.getConnection(function(err, connection) {
		if (err) { next(err); }

		connection.query('DELETE FROM board WHERE num=? AND pwd=?', [num, pwd], function(err, result) {
			if (err) { next(err); }
			else {
				if (result.affectedRows == 0) {
					back(res, '비밀번호가 틀렸습니다.');
				}
				else {
					ok(res, '삭제성공', '/list');
				}
			}

			connection.release();
		});
	});
});

function ok(res, message, url) {
	var str = "<script type='text/javascript'>alert('" + message + "');location.href = '" + url + "';</script>"
	res.send(str);
	res.end();
}

function back(res, message, url) {
	var str = "<script type='text/javascript'>alert('" + message + "');history.back();</script>"
	res.send(str);
	res.end();
}

module.exports = router;
