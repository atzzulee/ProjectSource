//Hello.js
console.log("Hello");