//seven.js

for(var i = 1; i <= 9; i++) {
	console.log("7 * %d = %d", i, 7 * i)
}