// console1.js
console.log('숫자 계산 : %d + %d = %d', 10, 20, 10+20);
console.log('문자열 출력 : %s', 'Hello world');
console.log('JSON 출력 : %j', {name: '홍길동'});

console.time('stopwatch');
var sum = 0;
for(var i = 0; i <= 100; i++) {
	sum += i;
}

console.log('1~100합=', sum);
console.timeEnd('stopwatch');