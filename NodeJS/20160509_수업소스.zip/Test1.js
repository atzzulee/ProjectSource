//Test1.js

function sortNumber(a,b){
    return a-b;
}

var sum = 0;
var arr = [];

while(true) {
	if(arr.length >= 6) {
		if(sum >= 110 && sum <= 170) {
			console.log('----생성완료----');
			break;
		}
		else {
			console.log('----생성실패----');
			sum = 0;
			arr = [];
		}
	}
	else {
		var num = Math.floor(Math.random() * 45) + 1;
		var flag = true;
		for(var item in arr) {
			if(arr[item] == num) {
				flag = false;
				break;
			}
		}

		if(flag) {
			arr.push(num);
			sum += num;
			console.log(num);
		}
	}
}

console.log('생성번호 : ' + arr.sort(sortNumber));
console.log('생성합계 : %d', sum);
