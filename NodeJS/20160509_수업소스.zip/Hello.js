//Hello.js
console.log("Hello, World");