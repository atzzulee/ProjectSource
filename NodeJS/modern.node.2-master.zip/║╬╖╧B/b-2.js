﻿// 모듈을 추출합니다.
var cheerio = require('cheerio');
var request = require('request');
