﻿var output = 0;

for (var i = 0; i < 100; i++) {
    output += i;
}

console.log(output);
