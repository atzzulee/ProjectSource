﻿// 출력합니다.
console.log('\u001b[31m', 'Hello World .. !');
console.log('\u001b[32m', 'Hello World .. !');
console.log('\u001b[33m', 'Hello World .. !');
console.log('\u001b[34m', 'Hello World .. !');
console.log('\u001b[35m', 'Hello World .. !');
console.log('\u001b[36m', 'Hello World .. !');
console.log('\u001b[1m');
console.log('\u001b[31m', 'Hello World .. !');
console.log('\u001b[32m', 'Hello World .. !');
console.log('\u001b[33m', 'Hello World .. !');
console.log('\u001b[34m', 'Hello World .. !');
console.log('\u001b[35m', 'Hello World .. !');
console.log('\u001b[36m', 'Hello World .. !');

// 초기화합니다.
console.log('\u001b[0m');
