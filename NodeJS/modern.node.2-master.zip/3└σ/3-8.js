﻿// 모듈을 추출합니다.
// var module = require('./module.js');
var module = require('./7.js');

// 모듈을 사용합니다.
console.log('abs(-273) = %d', module.abs(-273));
console.log('circleArea(3) = %d', module.circleArea(3));
