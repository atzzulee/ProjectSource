﻿// 데이터베이스에 연결합니다.
var db = require('mongojs').connect('node', ['products']);
