﻿// EventEmitter 객체를 생성합니다.
var custom = new process.EventEmitter();
