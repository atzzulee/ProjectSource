﻿// 이벤트 연결 개수 제한을 15개까지 늘립니다.
process.setMaxListeners(15);

// 이벤트를 연결합니다.
process.on('exit', function () { });
process.on('exit', function () { });
process.on('exit', function () { });
process.on('exit', function () { });
process.on('exit', function () { });
process.on('exit', function () { });
process.on('exit', function () { });
process.on('exit', function () { });
process.on('exit', function () { });
process.on('exit', function () { });
process.on('exit', function () { });
