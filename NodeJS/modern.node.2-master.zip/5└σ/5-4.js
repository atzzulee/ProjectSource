﻿// process 객체에 uncaughtException 이벤트를 연결합니다.
process.on('uncaughtException', function (error) {

});
