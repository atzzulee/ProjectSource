module HelloHelper
  # def format_datetime(datetime, type = :datetime)
  #   return '' unless datetime

  #   case type
  #     when :datetime
  #       format = '%Y년 %m월 %d일 %H:%M:%S'
  #     when :date
  #       format = '%Y년 %m월 %d일'
  #     when :time
  #       format = '%H:%M:%S'
  #   end

  #  datetime.strftime(format)
  #end
end
