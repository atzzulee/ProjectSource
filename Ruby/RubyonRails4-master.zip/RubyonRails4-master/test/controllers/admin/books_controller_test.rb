require 'test_helper'

class Admin::BooksControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
