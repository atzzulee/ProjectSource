require 'test_helper'

class FanCommentsHelperTest < ActionView::TestCase
end
