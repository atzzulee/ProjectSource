AirCheap
============

**Install**
```
npm install
```

**Start the application in development mode**
```
npm start
```

Open http://localhost:8080 in your browser.

## Update: React 15 dependency change
Because react-autosuggest 2 doesn't support React 15, it was substituted for react-autosuggest-legacy.
