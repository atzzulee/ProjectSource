export default {
  CREATED_ACCOUNT: 'created account',
  WITHDREW_FROM_ACCOUNT: 'withdrew from account',
  DEPOSITED_INTO_ACCOUNT: 'deposited into account'
};
