React App Boilerplate
=====================

Sample codes used in the Pro React book, organized per chapter.

### Usage

All chapter folders contain individual projects with individual package.json and webpack configurations. To run anyone of them use:

```
npm install
npm start
```

Open http://localhost:8080 in your browser.
