Redux Bank
============

Based on the alternative chapter 6 available online: "Complex state management with Redux" (http://www.pro-react.com/materials/)

**Install**
```
npm install
```

**Start the application in development mode**
```
npm start
```

Open http://localhost:8080 in your browser.
