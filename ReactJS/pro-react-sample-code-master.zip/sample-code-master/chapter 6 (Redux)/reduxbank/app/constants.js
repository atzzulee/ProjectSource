export default {
  WITHDRAW_FROM_ACCOUNT: 'withdraw from account',
  DEPOSIT_INTO_ACCOUNT: 'deposit into account',
  TOGGLE_EXCHANGE: 'toggle exchange'
};
