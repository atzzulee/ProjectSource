export const REQUEST_AIRPORTS = 'request airports';
export const RECEIVE_AIRPORTS = 'receive airports';
export const CHOOSE_AIRPORT = 'choose airport';
export const REQUEST_TICKETS = 'request tickets';
export const RECEIVE_TICKETS = 'receive tickets';
