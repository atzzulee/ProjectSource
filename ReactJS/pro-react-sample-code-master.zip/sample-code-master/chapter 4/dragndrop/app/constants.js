export default {
  SNACK: 'snack'
};
