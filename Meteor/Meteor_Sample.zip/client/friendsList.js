﻿// client/friendsList.js
Template.friendsList.helpers({
    listName : function(){
        return "나의 친구들 목록";
    },
    list : function(){
    	return Friends.find({} , { sort : {no:-1} }); 
    }
});

Template.friendsList.onCreated(function () {
    this.subscribe("friendsList",{});
});