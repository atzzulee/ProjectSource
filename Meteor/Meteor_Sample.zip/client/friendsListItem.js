﻿// client/friendsListItem.js
Template.friendsListItem.events({
    "click button[name=remove]" : function(evt , tmpl){
    	Friends.remove({_id:this._id});
    }
});