var net = require('net'),
    client = require('./client.js');

var server = net.createServer( function (socket) {
  socket.location = socket.remoteAddress + ':' + socket.remotePort;
  
  socket.on('data', function (data) {
    var id = data.toString().trim();
    if (id != null || id.length > 0) {
      client.addclient(id, socket);
    }
  });

  socket.on('error', function (err) {
    console.error(err.message);
  });
});

var event = net.createServer( function (socket) {
  socket.setEncoding('utf8'); 

  socket.on('data', function (data) {
    var arrPayload = data.split('\n').sort( function (x, y) {
      return x.split('|')[0] - y.split('|')[0];
    });

    for (var i in arrPayload) {
      var message = arrPayload[i];
      var arrPacket = message.split('|');

      switch (arrPacket[1]) {
        case 'B':
          client.broadcast(message);
          break;
        case 'F':
          client.follow(arrPacket[3], arrPacket[2], message);
          break;
        case 'P':
          client.privatemsg(arrPacket[3], message);
          break;
        case 'S':
          client.statusupdate(arrPacket[2], message);
          break;
        case 'U':
          client.unfollow(arrPacket[3], arrPacket[2]);
          break;
        default: 
          break;
      }
    }
  });

  socket.on('error', function (err) {
  	console.error(err.message);
  });
});

module.exports = {
    server: server,
    event: event
}
