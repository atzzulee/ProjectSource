var clients = [];

var sendMessage = function(id, message) {
  var client = clients[id];
  if (client != null && client.socket != null) 
    client.socket.write(message + '\n');
}

module.exports = {
  addclient: function (id, socket) {
    clients[id] = { 'socket': socket, 'follows': [] };
  },
  broadcast: function (message) {
    for (var item in clients) {
      sendMessage(item, message);
    }
  },
  privatemsg: function (id, message) {
    sendMessage(id, message);
  },
  statusupdate: function (id, message) {
    var client = clients[id];

    if (client != null && client.follows != null) {
      for (var item in client.follows) {
        sendMessage(client.follows[item], message);
      }
    }
  },
  follow: function (id, followid, message) {
    var client = clients[id];

    if (client == null) {
      clients[id] = { 'follows': [followid] };
      client = clients[id];
    }
    else {
      client.follows.push(followid);
    }
    
    sendMessage(id, message);
  },
  unfollow: function(id, followid) {
    var client = clients[id];
    
    if (client != null && client.follows != null) {
      var follows = client.follows;
      var index = follows.indexOf(followid);
      if (index > -1) {
        follows.splice(index, 1);
      }
    }
  }
};