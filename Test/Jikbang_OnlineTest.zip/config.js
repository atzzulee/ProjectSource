var config = {
	clientListenerPort: 9099,
    eventListenerPort: 9090
};

module.exports = config;