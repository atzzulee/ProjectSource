var config = require('./config');
    service = require('./service');

service.server.listen(config.clientListenerPort, () => {
    console.log('%s running on port %s.', 'Server', config.clientListenerPort);
        
    service.server.on('error', function (err) {
        console.log('Server Error:', err.message);
    });

    service.server.on('close', function () {
        console.log('Server Terminated');
    });
});

service.event.listen(config.eventListenerPort, () => {
    console.log('%s running on port %s.', 'Event', config.eventListenerPort);
        
    service.event.on('error', function (err) {
        console.log('Event Error:', err.message);
    });

    service.event.on('close', function () {
        console.log('Event Terminated');
    });
});