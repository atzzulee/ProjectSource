﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;

using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApplication9
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            text = string.Empty;

            int startDate = Convert.ToInt32(txtStartDate.Text);
            int endDate = Convert.ToInt32(txtEndDate.Text);

            i = 0;
            for (int x = startDate; x <= endDate; x++)
            {
                for (int j = 0; j <= 23; j++)
                {
                    try
                    {
                        DirectoryInfo dir = new DirectoryInfo(textBox2.Text + x.ToString("00") + "\\" + j.ToString("00") + "\\" + textBox4.Text);
                        CheckData(dir);
                        this.textBox1.Update();
                    }
                    catch (Exception ex)
                    {
                        //MessageBox.Show(ex.Message);
                    }
                }
            }

            textBox1.Text = text;
            MessageBox.Show(i.ToString());
        }

        private string text = string.Empty;
        private int i = 0;

        private void CheckData(DirectoryInfo dir)
        {
            foreach (DirectoryInfo subdir in dir.GetDirectories())
            {
                CheckData(subdir);
            }

            foreach (FileInfo fi in dir.GetFiles())
            {
                i++;
                StreamReader reader = new StreamReader(fi.FullName, Encoding.UTF8);
                if (reader.ReadToEnd().IndexOf(textBox3.Text) > -1)
                {
                    text += fi.FullName.ToString() + Environment.NewLine;
                }

                reader.Close();
                reader.Dispose();
                reader = null;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog fbd = new FolderBrowserDialog())
            {
                if (fbd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    textBox2.Text = fbd.SelectedPath;
                }
            }
        }
    }
}
