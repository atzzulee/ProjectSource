var config = {
  name: "TaxAccountingAdminAPI",
  serviceIP: 'localhost',
	servicePort: 3001,
  gcm: {
      packagename: 'com.pcm.pcmmanager',
      server_access_key: 'AIzaSyAPE8FqNwZrF0w_0k-LOcq6Ry-5gChWLuI'
  },
  token: {
    secret: 'TAM_AdminAPI_Secret',
    timeout: 60 * 60 * 24 * 365
  }
};

module.exports = config;