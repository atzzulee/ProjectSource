var express = require('express'),
    bodyParser = require('body-parser'),
    //logger = require('morgan'),
		config = require('./config'),
		errorHandlers = require('./common/errorhandlers'),
    index = require('./routes/index'),
    codes = require('./routes/codes'),
    experts = require('./routes/experts'),
    faqs = require('./routes/faqs'),
    markets = require('./routes/markets'),
    mileagelogs = require('./routes/mileagelogs'),
    notices = require('./routes/notices'),
    qnas = require('./routes/qnas'),
    reviews = require('./routes/reviews'),
    services = require('./routes/services'),
    tips = require('./routes/tips'),
    users = require('./routes/users'),
		app = express();
    
require('./common/dateFormat');

//app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

// 라우터 설정
app.use('/', index);
app.use('/codes', codes);
app.use('/experts', experts);
app.use('/faqs', faqs);
app.use('/markets', markets);
app.use('/mileagelogs', mileagelogs);
app.use('/notices', notices);
app.use('/qnas', qnas);
app.use('/reviews', reviews);
app.use('/services', services);
app.use('/tips', tips);
app.use('/users', users);

app.use(errorHandlers.notFound);
app.use(errorHandlers.error);

app.listen(config.servicePort);
console.log("%s running on port %s.", config.name, config.servicePort);