var mongoose = require('mongoose'),
    db = require('../common/mongooseHelper'),
    loggerHelper = require('../common/loggerHelper'),
	reviewSchema = new mongoose.Schema({
        marketsn: Number, // 경매일련번호
        expertsn: Number, // 전문가일련번호
        usersn: Number, // 유저일련번호
        username: String, // 유저명
        score: Number, // 점수
        content: String, // 내용
        regdate: String, // 등록일
        useyn: {type: Boolean, default: true} // 사용여부
	});

var model = db.model('Review', reviewSchema);
    
exports.list = function (page, pagesize, callback) {
    model.count({}).then( function (totalcount) {
        var sort = { 'marketsn': -1 };
        
        // 리스트 조회 프로세스
        model.find({}, {}).sort(sort).skip((page-1) * pagesize).limit(pagesize).then( function (docs) {
		    callback(true, docs, totalcount);
        }, function (err) {
            loggerHelper.error(err);
		    callback(false, null, 0);
        });
    }, function (err) {
        loggerHelper.error(err);
		callback(false, null, 0);
    });
}
    
exports.search = function (page, pagesize, expertsn, username, callback) {
    var where =  { 'username': { '$regex': username }, 'expertsn': expertsn };

    if (expertsn == null || expertsn == undefined) {
        delete where['expertsn'];
    }

    model.count(where).then( function (totalcount) {
        var sort = { 'marketsn': -1 };
        
        // 리스트 조회 프로세스
        model.find(where, {}).sort(sort).skip((page-1) * pagesize).limit(pagesize).then( function (docs) {
		    callback(true, docs, totalcount);
        }, function (err) {
            loggerHelper.error(err);
		    callback(false, null, 0);
        });
    }, function (err) {
        loggerHelper.error(err);
		callback(false, null, 0);
    });
}

exports.deleteByData = function (data, callback) {
	// 삭제프로세스
    model.remove(data).then( function (dbresult) {
		callback(true);
    }, function (err) {
        loggerHelper.error(err);
		callback(false);
    });
}