var mongoose = require('mongoose'),
    autoIncrement = require('mongoose-auto-increment'),
    db = require('../common/mongooseHelper'),
    loggerHelper = require('../common/loggerHelper'),
	successfulbidSchema = new mongoose.Schema({
		successfulbidsn: Number, // 입찰완료일련번호
		marketsn: Number, // 경매일련번호
		expertsn: Number, // 전문가일련번호
        regdate: String, // 등록일
		useyn: {type: Boolean, default: true} // 사용여부
	});

var model = db.model('Successfulbid', successfulbidSchema);

exports.list = function (page, pagesize, callback) {
    model.count({}).then( function (totalcount) {
        // 리스트 조회 프로세스
        model.find({}, {}).sort({'successfulbidsn': -1}).skip((page-1) * pagesize).limit(pagesize).then( function (docs) {
            callback(true, docs, totalcount);
        }, function (err) {
            loggerHelper.error(err);
		    callback(false, null, totalcount);
        });
    }, function (err) {
        loggerHelper.error(err);
		callback(false, null, 0);
    });
}

exports.search = function (page, pagesize, expertsn, callback) {
    var where =  { 'expertsn': expertsn };

    if (expertsn.length == 0) {
        delete where['expertsn'];
    }

    model.count(where).then( function (totalcount) {
        var sort = { 'marketsn': -1 };
        
        // 리스트 조회 프로세스
        model.find(where, {}).sort(sort).skip((page-1) * pagesize).limit(pagesize).then( function (docs) {
		    callback(true, docs, totalcount);
        }, function (err) {
            loggerHelper.error(err);
		    callback(false, null, 0);
        });
    }, function (err) {
        loggerHelper.error(err);
		callback(false, null, 0);
    });
}

exports.deleteByData = function (data, callback) {
	// 삭제프로세스
    model.remove(data).then( function (dbresult) {
	    callback(true);
    }, function (err) {
        loggerHelper.error(err);
		callback(false);
    });
}