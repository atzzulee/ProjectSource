var mongoose = require('mongoose'),
    autoIncrement = require('mongoose-auto-increment'),
    ObjectID = require('mongodb').ObjectID,
    db = require('../common/mongooseHelper'),
    loggerHelper = require('../common/loggerHelper'),
    marketSchema = new mongoose.Schema({
        marketsn: Number, // 경매일련번호
        usersn: Number, // 유저일련번호 
        username: String, // 유저명
        phone: String, // 전화번호
        markettype: String, // 경매타입1
        marketsubtype: String, // 경매타입2
        regiontype: String, // 지역타입1
        regionsubtype: String, // 지역타입2
        markettype1_1: String, // 경매타입1의1
        markettype1_2: Number, // 경매타입1의2 (매출규모) 
        markettype1_3: String, // 경매타입1의3 (사업종류)
        markettype1_4: Number, // 경매타입1의4 (종업원수)
        markettype2_1: [], // 경매타입2의1 (재산대상)
        markettype2_2: [], // 경매타입2의2 (재산대상 시가)
        bids: [{
            expertsn: Number, // 관리자일련번호
            expertname: String, // 관리자이름 
            usersn: Number, // 유저일련번호
            mainintroduce: String, // 메인소개글
            photo: String, // 사진
            sex: String, // 성별
            comment: String, // 코멘트
            price1: Number, // 기장료
            price2: Number, // 조정료
            regdate: String, // 등록일
            useyn: {type: Boolean, default: true} // 사용여부
        }], // 입찰리스트
        content: String, // 내용
        success_expertsn: Number, // 낙찰전문가일련번호
        status: String, // 경매상태
        regdate: String, // 등록일
        enddate: Number, // 마감일
        useyn: {type: Boolean, default: true} // 사용여부
    }),
    bidSchema = new mongoose.Schema({
        expertsn: Number, // 관리자일련번호
        expertname: String, // 관리자이름 
        usersn: Number, // 유저일련번호
        mainintroduce: String, // 메인소개글
        photo: String, // 사진
        sex: String, // 성별
        comment: String, // 코멘트
        price1: Number, // 기장료
        price2: Number, // 조정료
        regdate: String, // 등록일
        useyn: {type: Boolean, default: true} // 사용여부
    }); // 입찰리스트

var model = db.model('Market', marketSchema);
    
exports.count = function (callback) {
    model.count({}).then( function (totalcount) {
        callback(true, totalcount);
    }, function (err) {
        loggerHelper.error(err);
        callback(false, 0);
    });
}

exports.list = function (page, pagesize, callback) {
    model.count({}).then( function (totalcount) {
        var sort = { 'marketsn': -1 };

        // 리스트 조회 프로세스
        model.find({}, {}).sort(sort).skip((page-1) * pagesize).limit(pagesize).then( function (docs) {
			callback(true, docs, totalcount);
        }, function (err) {
			callback(false, null, totalcount);
        });
    }, function (err) {
        loggerHelper.error(err);
		callback(false, null, 0);
    });
}

exports.search = function (page, pagesize, username, callback) {
    var where =  { 'username': { '$regex': username } };
    
    model.count(where).then( function (totalcount) {
        var sort = { 'marketsn': -1 };

        // 리스트 조회 프로세스
        model.find(where, {}).sort(sort).skip((page-1) * pagesize).limit(pagesize).then( function (docs) {
			callback(true, docs, totalcount);
        }, function (err) {
            loggerHelper.error(err);
			callback(false, null, totalcount);
        });
    }, function (err) {
        loggerHelper.error(err);
		callback(false, null, 0);
    });
}

exports.info = function (marketsn, callback) {
    var where = { 'marketsn': marketsn };

    // 상세조회 프로세스
    model.findOne(where).then( function (doc) {
        if (doc == null) {
            callback(false, null);
        }
        else {
            callback(true, doc);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}

exports.update = function (marketsn, data, callback) {
    var where = { 'marketsn': marketsn };
    var set = { '$set': data };

    // 수정 프로세스
    model.update(where, set).then( function (dbresult) {
        if (dbresult.nModified == 0) {
		    callback(false);
        } else {
		    callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
		callback(false);
    });
}

// exports.bidPush = function (marketsn, data, callback) {
//     var bid = db.model('Bid', bidSchema);
//     var obj = new bid(data);
//     var pushdata = { '$push': { 'bids': obj } };
    
//     model.update(marketsn, pushdata, { upsert: true }).then( function (dbresult) {
//         if (dbresult.n == 0) {
//             callback(false);
//         }
//         else {
//             callback(true);
//         }
//     }, function (err) {
//         loggerHelper.error(err);
//         callback(false);
//     });
// }

exports.bidPull = function (marketsn, _id, callback) {
    var where = { 'marketsn': marketsn };
    var pulldata = { '$pull': { 'bids': { '_id': ObjectID(_id) } } };
    
    model.update(where, pulldata).then( function (dbresult) {
        if (dbresult.nModified == 0) {
            callback(false);
        }
        else {
            callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false);
    });
}

exports.deleteByData = function (data, callback) {
	// 삭제프로세스
    model.remove(data).then( function (dbresult) {
		callback(true);
    }, function (err) {
        loggerHelper.error(err);
		callback(false);
    });
}

exports.pullByData = function (data, callback) {
    var pulldata = { '$pull': { 'bids': data } };
    
	// 수정 프로세스
    model.update(pulldata).then( function (dbresult) {
		callback(true);
    }, function (err) {
        loggerHelper.error(err);
		callback(false);
    });
}

exports.bidCheckList = function (status, addDate, callback) {
    // 리스트 조회 프로세스
    //var where = { 'status': status, 'useyn': true, '$where': 'new Date(new Date().getTime() + 10*60000) >= new Date(this.regdate).setDate(new Date(this.regdate).getDate() + this.enddate + ' + addDate + ' )' };
    var where = { 'status': status, 'useyn': true, '$where': 'new ISODate().getTime() + 9*60*60*1000 + 10*60000 >= new ISODate(this.regdate).getTime() + 24*60*60*1000*(this.enddate + ' + addDate + ')' };
    model.find(where).then( function (docs) {
        callback(true, docs);
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}