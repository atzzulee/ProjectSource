var mongoose = require('mongoose'),
    autoIncrement = require('mongoose-auto-increment'),
    db = require('../common/mongooseHelper'),
    loggerHelper = require('../common/loggerHelper'),
	noticeSchema = new mongoose.Schema({
		noticesn: Number,
		title: String,
		content: String,
        attachurl: String,
        detailattachurl: String,
        status: String,
        regdate: String, // 등록일
        upddate: String, // 수정일
		useyn: { type:Boolean, default: true }
	});
    
var model = db.model('Notice', noticeSchema);

exports.list = function (page, pagesize, callback) {
    model.count({}).then( function (totalcount) {
        var sort = { 'upddate': -1 };

        // 리스트 조회 프로세스
        model.find({}, {}).sort(sort).skip((page-1) * pagesize).limit(pagesize).then( function (docs) {
			callback(true, docs, totalcount);
        }, function (err) {
            loggerHelper.error(err);
			callback(false, null, totalcount);
        });
    }, function (err) {
        loggerHelper.error(err);
		callback(false, null, 0);
    });
}

exports.info = function (noticesn, callback) {
    // 상세조회 프로세스
    model.findOne(noticesn).then( function (doc) {
        if (doc == null) {
            callback(false, null);
        }
        else {
            callback(true, doc);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}

exports.insert = function (data, callback) {
    // 등록 프로세스
    autoIncrement.initialize(db);
    noticeSchema.plugin(autoIncrement.plugin, { 'model': 'Notice', 'field': 'noticesn', 'startAt': 1, 'incrementBy': 1 });
    data.regdate = new Date().format('yyyy-MM-dd HH:mm:ss');
    data.upddate = new Date().format('yyyy-MM-dd HH:mm:ss');

    model(data).save().then( function (doc) {
        if (doc == null) {
		    callback(false);
        }
        else {
		    callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
	    callback(false);
    });
}

exports.update = function (noticesn, data, callback) {
    data.upddate = new Date().format('yyyy-MM-dd HH:mm:ss');
    var set = { '$set': data };

    // 수정 프로세스
    model.update(noticesn, set).then( function (dbresult) {
        if (dbresult.nModified == 0) {
		    callback(false);
        } else {
		    callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
		callback(false);
    });
}

exports.delete = function (noticesn, callback) {
	// 삭제프로세스
    model.remove(noticesn).then( function (dbresult) {
        if (dbresult.result.n == 0) {
		    callback(false);
        }
        else {
		    callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
		callback(false);
    });
}