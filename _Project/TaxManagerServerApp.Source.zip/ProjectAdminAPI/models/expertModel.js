var mongoose = require('mongoose'),
    autoIncrement = require('mongoose-auto-increment'),
    db = require('../common/mongooseHelper'),
    loggerHelper = require('../common/loggerHelper'),
    expertSchema = new mongoose.Schema({
        expertsn: Number, // 전문가일련번호
        usersn: Number, // 유저일련번호,
        expertname: String, // 이름
        photo: String, // 이미지경로
        diploma: String, // 대학 졸업 증명서
        certificate: String, // 건강보험자격득실확인서
        mainintroduce: String, // 메인소개글
        detailintroduce: String, // 상세소개글
        officename: String, //사무실명
        homepage: String, // 홈페이지
        tel: String, // 전화번호
        address: String, // 번지주소
        latitude: String, // 위도
        longitude: String, // 경도
        regiontype: String, // 지역타입1
        regionsubtype: String, // 지역타입2
        license: String, // 자격증
        academic: [{
            start: Number, // 시작
            end: Number, // 끝
            name: String // 이름
        }], // 학력
        sex: String, // 성별 
        belongto: String, // 소속
        record: [{
            start: Number, // 시작
            end: Number, // 끝
            name: String // 이름
        }], // 이력
        career: Number, //경력
        age: Number, // 나이
        categorys: [{
            markettype: String, // 메인코드
            marketsubtype: String // 서브코드
        }], // 전문분야 카테고리 리스트 (최대3개)
        dishs: [], // 찜 리스트 (최대20개)
        mileage: Number, // 마일리지
        sort: {type: Number, default: 1}, // 정렬값
        regdate: String, // 등록일
        useyn: {type: Boolean, default: true} // 사용여부
    });

var model = db.model('Expert', expertSchema);
    
exports.count = function (callback) {
    model.count({}).then( function (totalcount) {
        callback(true, totalcount);
    }, function (err) {
        loggerHelper.error(err);
        callback(false, 0);
    });
}

exports.list = function (page, pagesize, callback) {
    model.count({}).then( function (totalcount) {
        var sort = { 'sort': -1, 'expertsn': -1 };

        // 리스트 조회 프로세스
        model.find({}, {}).sort(sort).skip((page-1) * pagesize).limit(pagesize).then( function (docs) {
			callback(true, docs, totalcount);
        }, function (err) {
			callback(false, null, totalcount);
        });
    }, function (err) {
        loggerHelper.error(err);
		callback(false, null, 0);
    });
}

exports.search = function (page, pagesize, expertname, callback) {
    var where =  { 'expertname': { '$regex': expertname } };
    
    model.count(where).then( function (totalcount) {
        var sort = { 'sort': -1, 'expertsn': -1 };

        // 리스트 조회 프로세스
        model.find(where, {}).sort(sort).skip((page-1) * pagesize).limit(pagesize).then( function (docs) {
			callback(true, docs, totalcount);
        }, function (err) {
            loggerHelper.error(err);
			callback(false, null, totalcount);
        });
    }, function (err) {
        loggerHelper.error(err);
		callback(false, null, 0);
    });
}

exports.info = function (expertsn, callback) {
    // 상세조회 프로세스
    model.findOne(expertsn).then( function (doc) {
        if (doc == null) {
            callback(false, null);
        }
        else {
            callback(true, doc);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}

exports.insert = function (data, callback) {
    // 등록 프로세스
    autoIncrement.initialize(db);
    expertSchema.plugin(autoIncrement.plugin, { 'model': 'Expert', 'field': 'expertsn', 'startAt': 1, 'incrementBy': 1 });
    data.regdate = new Date().format('yyyy-MM-dd HH:mm:ss');
    
    model(data).save().then( function (doc) {
        if (doc == null) {
		    callback(false, null);
        }
        else {
		    callback(true, doc);
        }
    }, function (err) {
        loggerHelper.error(err);
		callback(false, null);
    });
}

exports.update = function (expertsn, data, callback) {
    var set = { '$set': data };

    // 수정 프로세스
    model.update(expertsn, set).then( function (dbresult) {
        if (dbresult.n == 0) {
		    callback(false);
        } else {
		    callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
		callback(false);
    });
}

exports.deleteByData = function (data, callback) {
	// 삭제프로세스
    model.remove(data).then( function (dbresult) {
		callback(true);
    }, function (err) {
        loggerHelper.error(err);
		callback(false);
    });
}

exports.pullByData = function (data, callback) {
    var pulldata = { '$pull': { 'dishs': data } };
    
	// 수정 프로세스
    model.update(pulldata).then( function (dbresult) {
		callback(true);
    }, function (err) {
        loggerHelper.error(err);
		callback(false);
    });
}

exports.listByExpert = function (arrExpert, callback) {
    var where = { 'expertsn': { '$in': arrExpert }, 'useyn': true };

    model.find(where).then( function (docs) {
        callback(true, docs);
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}

exports.bidsCancel = function (arrExpert, mileage, callback) {
    var where = { 'expertsn': { '$in': arrExpert }, 'useyn': true };
    var inc = { '$inc': { 'mileage': mileage } };
    var multi = { 'multi': true };
    
	// 수정 프로세스
    model.update(where, inc, multi).then( function (dbresult) {
        if (dbresult.nModified == 0) {
		    callback(false);
        } else {
		    callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false);
    });
}