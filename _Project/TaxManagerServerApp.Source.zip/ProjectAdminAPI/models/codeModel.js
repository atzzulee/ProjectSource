var mongoose = require('mongoose'),
    autoIncrement = require('mongoose-auto-increment'),
    db = require('../common/mongooseHelper'),
    loggerHelper = require('../common/loggerHelper'),
	codeSchema = new mongoose.Schema({
		codesn: Number,
		code: String,
		value: String,
        regdate: String, // 등록일
	});
    
var model = db.model('Code', codeSchema);

exports.list = function (page, pagesize, callback) {
    model.count({}).then( function (totalcount) {
        var sort = { 'codesn': -1 };
        
        // 리스트 조회 프로세스
        model.find({}, {}).sort(sort).skip((page-1) * pagesize).limit(pagesize).then( function (docs) {
			callback(true, docs, totalcount);
        }, function (err) {
            loggerHelper.error(err);
			callback(false, null, totalcount);
        });
    }, function (err) {
        loggerHelper.error(err);
		callback(false, null, 0);
    });
}

exports.listByJob = function (callback) {
    // 리스트 조회 프로세스
    var where = { $or:[ { 'code': /^001/ }, { 'code': /^002/ }, { 'code': /^003/ } ] };
    var field = { 'code': 1, 'value': 1 };
    var sort = { 'code': 1 };
    
    model.find(where, field).sort(sort).then( function (docs) {
        callback(true, docs);
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}

exports.info = function (codesn, callback) {
    // 상세조회 프로세스
    model.findOne(codesn).then( function (doc) {
        if (doc == null) {
            callback(false, null);
        }
        else {
            callback(true, doc);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}

exports.insert = function (data, callback) {
    // 등록 프로세스
    autoIncrement.initialize(db);
    codeSchema.plugin(autoIncrement.plugin, { 'model': 'Code', 'field': 'codesn', 'startAt': 78, 'incrementBy': 1 });
    data.regdate = new Date().format('yyyy-MM-dd HH:mm:ss');
    
    model(data).save().then( function (doc) {
        if (doc == null) {
		    callback(false);
        }
        else {
		    callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
	    callback(false);
    });
}

exports.update = function (codesn, data, callback) {
    var set = { '$set': data };
    
    // 수정 프로세스
    model.update(codesn, set).then( function (dbresult) {
        if (dbresult.nModified == 0) {
		    callback(false);
        } else {
		    callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
		callback(false);
    });
}

exports.delete = function (codesn, callback) {
	// 삭제프로세스
    model.remove(codesn).then( function (dbresult) {
        if (dbresult.result.n == 0) {
		    callback(false);
        }
        else {
		    callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
		callback(false);
    });
}