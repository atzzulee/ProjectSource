var mongoose = require('mongoose'),
    autoIncrement = require('mongoose-auto-increment'),
    db = require('../common/mongooseHelper'),
    loggerHelper = require('../common/loggerHelper'),
	tipSchema = new mongoose.Schema({
        tipsn: Number, // 팁일련번호
        title: String, // 제목
        linkurl: String, // 링크경로
        attachurl: String, // 이미지경로
        regdate: String, // 등록일
        upddate: String, // 수정일
        useyn: {type: Boolean, default: true} // 사용여부
	});
    
var model = db.model('Tip', tipSchema);
    
exports.list = function (page, pagesize, callback) {
    model.count({}).then( function (totalcount) {
        var sort = { 'upddate': -1 };
        
        // 리스트 조회 프로세스
        model.find({}, {}).sort(sort).skip((page-1) * pagesize).limit(pagesize).then( function (docs) {
			callback(true, docs, totalcount);
        }, function (err) {
			callback(false, null, totalcount);
        });
    }, function (err) {
        loggerHelper.error(err);
		callback(false, null, 0);
    });
}

exports.info = function (tipsn, callback) {
    // 상세조회 프로세스
    model.findOne(tipsn).then( function (doc) {
        if (doc == null) {
            callback(false, null);
        }
        else {
            callback(true, doc);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}

exports.insert = function (data, callback) {
    // 등록 프로세스
    autoIncrement.initialize(db);
    tipSchema.plugin(autoIncrement.plugin, { 'model': 'Tip', 'field': 'tipsn', 'startAt': 1, 'incrementBy': 1 });
    data.regdate = new Date().format('yyyy-MM-dd HH:mm:ss');
    data.upddate = new Date().format('yyyy-MM-dd HH:mm:ss');

    model(data).save().then( function (doc) {
        if (doc == null) {
		    callback(false);
        }
        else {
		    callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
	    callback(false);
    });
}

exports.update = function (tipsn, data, callback) {
    data.upddate = new Date().format('yyyy-MM-dd HH:mm:ss');
    var set = { '$set': data };
    
    // 수정 프로세스
    model.update(tipsn, set).then( function (dbresult) {
        if (dbresult.nModified == 0) {
		    callback(false);
        } else {
		    callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
		callback(false);
    });
}

exports.delete = function (tipsn, callback) {
	// 삭제프로세스
    model.remove(tipsn).then( function (dbresult) {
        if (dbresult.result.n == 0) {
		    callback(false);
        }
        else {
		    callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
		callback(false);
    });
}