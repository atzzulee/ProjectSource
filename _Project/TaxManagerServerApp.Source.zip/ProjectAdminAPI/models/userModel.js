var mongoose = require('mongoose'),
    autoIncrement = require('mongoose-auto-increment'),
    crypto = require('crypto'),
    db = require('../common/mongooseHelper'),
    loggerHelper = require('../common/loggerHelper'),
	userSchema = new mongoose.Schema({
        usersn: Number,
        username: String,
        email: String,
        password: String,
        salt: String,
        phone: String,
        pushkey: String,
        pushyn: {type: Boolean, default: true},
        usertype1: String,
        usertype2: String,
        roles: String,
        warning: {type: Number, default: 0},
        regdate: String, // 등록일
        status: String,
        useyn: {type: Boolean, default: true}
	});
    
var model = db.model('User', userSchema);

exports.count = function (callback) {
    model.count({}).then( function (totalcount) {
        callback(true, totalcount);
    }, function (err) {
        loggerHelper.error(err);
        callback(false, 0);
    });
}

exports.list = function (page, pagesize, callback) {
    model.count({}).then( function (totalcount) {
        var sort = { 'usersn': -1 };

        // 리스트 조회 프로세스
        model.find({}, {}).sort(sort).skip((page-1) * pagesize).limit(pagesize).then( function (docs) {
			callback(true, docs, totalcount);
        }, function (err) {
            loggerHelper.error(err);
			callback(false, null, totalcount);
        });
    }, function (err) {
        loggerHelper.error(err);
		callback(false, null, 0);
    });
}

exports.search = function (page, pagesize, username, phone, email, callback) {
    var where =  { '$and': [ { 'username': { '$regex': username } }, { 'phone': { '$regex': phone } }, { 'email': { '$regex': email } } ] };
    
    model.count(where).then( function (totalcount) {
        var sort = { 'usersn': -1 };

        // 리스트 조회 프로세스
        model.find(where, {}).sort(sort).skip((page-1) * pagesize).limit(pagesize).then( function (docs) {
			callback(true, docs, totalcount);
        }, function (err) {
            loggerHelper.error(err);
			callback(false, null, totalcount);
        });
    }, function (err) {
        loggerHelper.error(err);
		callback(false, null, 0);
    });
}

exports.pushlist = function (arruser, callback) {
    var where = { 'usersn': { '$in': arruser }, 'pushyn': true, 'useyn': true };
    var field = { '_id': 0, 'usersn': 1, 'pushkey': 1 };

    // 리스트 조회 프로세스
    model.find(where, field).then( function (docs) {
        callback(true, docs);
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}

exports.info = function (data, callback) {
    // 상세조회 프로세스
    model.findOne(data).then( function (doc) {
        if (doc == null) {
            callback(false, null);
        }
        else {
            callback(true, doc);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}

exports.insert = function (data, callback) {
    // 등록 프로세스
    autoIncrement.initialize(db);
    userSchema.plugin(autoIncrement.plugin, { 'model': 'User', 'field': 'usersn', 'startAt': 1, 'incrementBy': 1 } );

    var salt = crypto.randomBytes(5).toString('hex');
    var sha1 = crypto.createHash('sha1');
    sha1.update(data.password + salt);
    data.salt = salt;
    data.password = sha1.digest('hex');
    data.regdate = new Date().format('yyyy-MM-dd HH:mm:ss');
    
    model(data).save().then( function (doc) {
        if (doc == null) {
            callback(false, null);
        }
        else {
            callback(true, doc);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}

exports.update = function (usersn, data, callback) {
    if (data.password != undefined) {
        var salt = crypto.randomBytes(5).toString('hex');
        var sha1 = crypto.createHash('sha1');
        sha1.update(data.password + salt);
        data.salt = salt;
        data.password = sha1.digest('hex');
    }
    
    var set = { '$set': data };
    // 수정 프로세스
    model.update(usersn, set).then( function (dbresult) {
        if (dbresult.nModified == 0) {
		    callback(false);
        } else {
		    callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
		callback(false);
    });
}

exports.delete = function (usersn, callback) {
	// 삭제프로세스
    model.remove(usersn).then( function (dbresult) {
        if (dbresult.result.n == 0) {
		    callback(false);
        }
        else {
		    callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
		callback(false);
    });
}

exports.checkAdmin = function (data, password, callback) {
    // 상세조회 프로세스
    model.findOne(data).then( function (doc) {
        if (doc == null) {
            callback(false, null);
        }
        else {
            var sha1 = crypto.createHash('sha1');
            sha1.update(password + doc.salt);
            
            if (doc.password != sha1.digest('hex')) {
                callback(false, null);
            }
            else {
                callback(true, doc);
            }
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}

exports.increment = function (usersn, data, callback) {
    // 숫자 증가/감소
    var inc = { '$inc': data };
    
    model.update(usersn, inc).then( function (dbresult) {
        callback(true);
    }, function (err) {
        loggerHelper.error(err);
        callback(false);
    });
}