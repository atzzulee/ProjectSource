var mongoose = require('mongoose'),
    autoIncrement = require('mongoose-auto-increment'),
    db = require('../common/mongooseHelper'),
    loggerHelper = require('../common/loggerHelper'),
	mileagelogSchema = new mongoose.Schema({
		mileagelogsn: Number, // 마일리지로그일련번호
		expertsn: Number, // 관리자일련번호
		expertname: String, // 관리자이름
		mileagetype: String, // 충전,
		mileage: Number, // 마일리지,
		remainmileage: Number, // 남은 마일리지
        regdate: String, // 등록일
	});

var model = db.model('Mileagelog', mileagelogSchema);

exports.list = function (page, pagesize, callback) {
    model.count({}).then( function (totalcount) {
        var sort = { 'mileagelogsn': -1 }

        // 리스트 조회 프로세스
        model.find({}, {}).sort(sort).skip((page-1) * pagesize).limit(pagesize).then( function (docs) {
			callback(true, docs, totalcount);
        }, function (err) {
			callback(false, null, totalcount);
        });
    }, function (err) {
        loggerHelper.error(err);
		callback(false, null, 0);
    });
}

exports.search = function (page, pagesize, expertsn, callback) {
    var where =  { 'expertsn': expertsn };

    if (expertsn.length == 0) {
        delete where['expertsn'];
    }

    model.count(where).then( function (totalcount) {
        var sort = { 'mileagelogsn': -1 }

        // 리스트 조회 프로세스
        model.find(where, {}).sort(sort).skip((page-1) * pagesize).limit(pagesize).then( function (docs) {
			callback(true, docs, totalcount);
        }, function (err) {
            loggerHelper.error(err);
			callback(false, null, totalcount);
        });
    }, function (err) {
        loggerHelper.error(err);
		callback(false, null, 0);
    });
}

exports.insert = function (data, callback) {
    // 등록 프로세스
    autoIncrement.initialize(db);
    mileagelogSchema.plugin(autoIncrement.plugin, { 'model': 'Mileagelog', 'field': 'mileagelogsn', 'startAt': 1, 'incrementBy': 1 });
    data.regdate = new Date().format('yyyy-MM-dd HH:mm:ss');
    
    switch (data.mileagetype) {
        case '111_001':
        case '111_003':
        case '111_004':
        case '111_006':
            data.remainmileage = data.remainmileage + data.mileage;
            break;
        case '111_002':
        case '111_005':
            data.remainmileage = data.remainmileage - data.mileage;
            break;
        default:
            break;
    }
    
    model(data).save().then( function (doc) {
        if (doc == null) {
		    callback(false, null);
        }
        else {
		    callback(true, doc);
        }
    }, function (err) {
        loggerHelper.error(err);
	    callback(false, null);
    });
}

exports.delete = function (mileagelogsn, callback) {
	// 삭제프로세스
    model.remove(mileagelogsn).then( function (dbresult) {
        if (dbresult.result.n == 0) {
		    callback(false);
        }
        else {
		    callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
		callback(false);
    });
}

exports.deleteByData = function (data, callback) {
	// 삭제프로세스
    model.remove(data).then( function (dbresult) {
		callback(true);
    }, function (err) {
        loggerHelper.error(err);
		callback(false);
    });
}