var mongoose = require('mongoose'),
    autoIncrement = require('mongoose-auto-increment'),
    async = require('async'),
    ObjectID = require('mongodb').ObjectID,
    db = require('../common/mongooseHelper'),
    loggerHelper = require('../common/loggerHelper'),
    qnaSchema = new mongoose.Schema({
        qnasn: Number, // qna일련번호
        usersn: Number, // 유저일련번호
        username: String, // 유저명
        title: String, // 제목
        content: String, // 컨텐츠
        comments: [{
            _id: String, // 답글일련번호
            expertsn: String, // 전문가일련번호
            expertname: String, // 전문가이름
            sex: String, // 성별
            photo: String, // 이미지경로
            license: String, // 자격증
            mainintroduce: String, // 메인소개글
            officename: String, //사무실명
            career: Number, //경력
            age: Number, // 나이
            content: String, // 전문가내용
            likeusers: [], // 좋아요
            regdate: String, // 등록일
            useyn: {type: Boolean, default: true} // 사용여부
        }], // 답글리스트
        secretyn: Boolean, // 비밀글여부
        regdate: String, // 등록일
        useyn: {type: Boolean, default: true} // 사용여부
    }),
    commentSchema = new mongoose.Schema({
        expertsn: String, // 전문가일련번호
        expertname: String, // 전문가이름
        sex: String, // 성별
        photo: String, // 이미지경로
        license: String, // 자격증
        mainintroduce: String, // 메인소개글
        officename: String, //사무실명
        career: Number, //경력
        age: Number, // 나이
        content: String, // 전문가내용
        likeusers: [], // 좋아요
        regdate: String, // 등록일
        useyn: {type: Boolean, default: true} // 사용여부
    });

var model = db.model('Qna', qnaSchema);

exports.count = function (callback) {
    model.count({}).then( function (totalcount) {
        callback(true, totalcount);
    }, function (err) {
        loggerHelper.error(err);
        callback(false, 0);
    });
}
    
exports.list = function (page, pagesize, callback) {
    model.count({}).then( function (totalcount) {
        var sort = { 'qnasn': -1 };
        
        // 리스트 조회 프로세스
        model.find({}, {}).sort(sort).skip((page-1) * pagesize).limit(pagesize).then( function (docs) {
			callback(true, docs, totalcount);
        }, function (err) {
            loggerHelper.error(err);
            callback(false, null, totalcount);
        });
    }, function (err) {
        loggerHelper.error(err);
		callback(false, null, 0);
    });
}

exports.search = function (page, pagesize, expertsn, username, callback) {
    var where =  { 'username': { '$regex': username }, 'comments.expertsn': expertsn };
    
    if (expertsn == null || expertsn == undefined) {
        delete where['comments.expertsn'];
    }

    model.count(where).then( function (totalcount) {
        var sort = { 'marketsn': -1 };
        
        // 리스트 조회 프로세스
        model.find(where, {}).sort(sort).skip((page-1) * pagesize).limit(pagesize).then( function (docs) {
		    callback(true, docs, totalcount);
        }, function (err) {
            loggerHelper.error(err);
		    callback(false, null, 0);
        });
    }, function (err) {
        loggerHelper.error(err);
		callback(false, null, 0);
    });
}

exports.info = function (qnasn, callback) {
    // 상세조회 프로세스
    model.findOne(qnasn).then( function (doc) {
        if (doc == null) {
            callback(false, null);
        }
        else {
            callback(true, doc);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}

exports.delete = function (qnasn, callback) {
	// 삭제프로세스
    model.remove(qnasn).then( function (dbresult) {
        if (dbresult.result.n == 0) {
            callback(false);
        }
        else {
            callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false);
    });
}

exports.commentPush = function (qnasn, data, callback) {
    var comment = db.model('Comment', commentSchema);
    var obj = new comment(data);
    data.regdate = new Date().format('yyyy-MM-dd HH:mm:ss');
    var pushdata = { '$push': { 'comments': obj } };
    
    model.update(qnasn, pushdata, { upsert: true }).then( function (dbresult) {
        if (dbresult.nModified == 0) {
            callback(false);
        }
        else {
            callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false);
    });
}

exports.commentPull = function (qnasn, _id, callback) {
    var pulldata = { '$pull': { 'comments': { '_id': ObjectID(_id) } } };
    
    model.update(qnasn, pulldata).then( function (dbresult) {
        if (dbresult.nModified == 0) {
            callback(false);
        }
        else {
            callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false);
    });
}

exports.deleteByData = function (data, callback) {
	// 삭제프로세스
    model.remove(data).then( function (dbresult) {
		callback(true);
    }, function (err) {
        loggerHelper.error(err);
		callback(false);
    });
}

exports.pullByData = function (data, callback) {
    var pulldata = { '$pull': { 'comments': data } };
    
	// 수정 프로세스
    model.update(pulldata).then( function (dbresult) {
		callback(true);
    }, function (err) {
        loggerHelper.error(err);
		callback(false);
    });
}