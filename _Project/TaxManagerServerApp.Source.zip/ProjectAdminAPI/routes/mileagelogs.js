var express = require('express'),
    tokenHelper = require('../common/tokenHelper'),
    mileagelogModel = require('../models/mileagelogModel'),
    router = express.Router();

router.get('/list/:page/:pagesize', [tokenHelper.authMethod], function (req, res, next) {
    var page = eval(req.params.page);
    var pagesize = eval(req.params.pagesize);
	var result = {
        'result': 0,
        'message': '',
        'list': null,
        'totalcount': 0
    };
    
    mileagelogModel.list(page, pagesize, function (dbresult, list, totalcount) {
        if (!dbresult) {
            result.result = -1;
            result.message = '리스트 조회 실패.';
        }
        else {
            result.list = list;
            result.totalcount = totalcount;
        }
        res.json(result);
    });
});

router.get('/search/:page/:pagesize', [tokenHelper.authMethod], function (req, res, next) {
    var page = eval(req.params.page);
    var pagesize = eval(req.params.pagesize);
	var result = {
        'result': 0,
        'message': '',
        'list': null,
        'totalcount': 0
    };
    var expertsn = req.query.expertsn;
    
    mileagelogModel.search(page, pagesize, expertsn, function (dbresult, list, totalcount) {
        if (!dbresult) {
            result.result = -1;
            result.message = '리스트 조회 실패.';
        }
        else {
            result.list = list;
            result.totalcount = totalcount;
        }
        res.json(result);
    });
});

module.exports = router;