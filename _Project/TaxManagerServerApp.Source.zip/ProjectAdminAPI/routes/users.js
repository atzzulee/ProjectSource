var express = require('express'),
    async = require('async'),
    gcmHelper = require('../common/gcmHelper'),
    tokenHelper = require('../common/tokenHelper'),
    expertModel = require('../models/expertModel'),
    marketModel = require('../models/marketModel'),
    qnaModel = require('../models/qnaModel'),
    reviewModel = require('../models/reviewModel'),
    userModel = require('../models/userModel'),
    router = express.Router();
    
router.get('/list/:page/:pagesize', [tokenHelper.authMethod], function (req, res, next) {
    var page = eval(req.params.page);
    var pagesize = eval(req.params.pagesize);
	var result = {
        'result': 0,
        'message': '',
        'list': null,
        'totalcount': 0
    };
    
    userModel.list(page, pagesize, function (dbresult, list, totalcount) {
        if (!dbresult) {
            result.result = -1;
            result.message = '리스트 조회 실패.';
        }
        else {
            result.list = list;
            result.totalcount = totalcount;
        }
        res.json(result);
    });
});

router.get('/search/:page/:pagesize', [tokenHelper.authMethod], function (req, res, next) {
    var page = eval(req.params.page);
    var pagesize = eval(req.params.pagesize);
	var result = {
        'result': 0,
        'message': '',
        'list': null,
        'totalcount': 0
    };
    var username = req.query.username;
    var phone = req.query.phone;
    var email = req.query.email;
    
    userModel.search(page, pagesize, username, phone, email, function (dbresult, list, totalcount) {
        if (!dbresult) {
            result.result = -1;
            result.message = '리스트 조회 실패.';
        }
        else {
            result.list = list;
            result.totalcount = totalcount;
        }
        res.json(result);
    });
});

router.get('/info/:usersn', [tokenHelper.authMethod], function (req, res, next) {
    var usersn = { 'usersn': eval(req.params.usersn) };
    var result = {
        'result': 0,
        'message': '',
        'item': null
    };
    
    userModel.info(usersn, function (dbresult, item) {
        if (!dbresult) {
            result.result = -1;
            result.message = '상세 실패.';
        }
        else {
            result.item = item;
        }
        res.json(result);
    });
});

router.post('/insert', [tokenHelper.authMethod], function (req, res, next) {
    req.body.warning = eval(req.body.warning);
    req.body.pushyn = (req.body.pushyn == '1' ? true : false);
    req.body.useyn = (req.body.useyn == '1' ? true : false);
    var result = {
        'result': 0,
        'message': ''
    }
    var usersn = { 'usersn': 0 };
    var errcode = 0;
    
    async.waterfall([
        function (cb) {
            var data = { 'email': req.body.email, 'useyn': true };
            userModel.info(data, function (dbresult, doc) {
                if (!dbresult) {
                    cb(null);
                }
                else {
                    result.result = -1;
                    result.message = '이메일 조회 실패.';
                    cb(null);
                }
            });
        },
        function (cb) {
            userModel.insert(req.body, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '등록 실패.';
                    cb(true);
                }
                else {
                    if (req.body.status != '100_002') {
                        cb(true);
                    } else {
                        usersn.usersn = doc.usersn;
                        cb(null, doc);
                    }
                }
            });
        },
        function (doc, cb) {
            errcode = -1;
            var data = {
                'usersn': doc.usersn,
                'expertname': doc.username,
                'mileage': 50000
            };
            
            expertModel.insert(data, function (dbresult) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '등록 실패.';
                    cb(null);
                } else {
                    errcode = 0;
                    cb(null);
                }
            });
        }
    ], function (err, results) {
        switch (errcode) {
            case -1:
                userModel.delete(usersn, function (dbresult) {
                    res.json(result);
                });
                break;
            default:
                res.json(result);
                break;
        }
    });
});

router.post('/update', [tokenHelper.authMethod], function (req, res, next) {
    var usersn = { 'usersn': eval(req.body.usersn) };
    delete req.body['usersn'];
    
    req.body.warning = eval(req.body.warning);
    req.body.pushyn = (req.body.pushyn == '1' ? true : false);
    req.body.useyn = (req.body.useyn == '1' ? true : false);
    var result = {
        'result': 0,
        'message': ''
    }
    
    var expertsn = { 'expertsn': 0 };
    var user = null;
    var errcode = 0;

    async.waterfall([
        function (cb) {
            var data = { 'email': req.body.email, 'useyn': true };
            userModel.info(data, function (dbresult, doc) {
                if (!dbresult) {
                    cb(null);
                }
                else {
                    if (usersn.usersn != doc.usersn) {
                        result.result = -1;
                        result.message = '이메일 조회 실패.';
                        cb(true);
                    }
                    else {
                        user = doc;
                        cb(null);
                    }
                }
            });
        },
        function (cb) {
            if (user == null) {
                userModel.info(usersn, function (dbresult, doc) {
                    if (!dbresult) {
                        result.result = -1;
                        result.message = '유저 조회 실패.';
                        cb(true);
                    }
                    else {
                        user = doc;
                        cb(null);
                    }
                });
            }
            else {
                cb(null);
            }
        },
        function (cb) {
            if (req.body.roles == '100_002') {
                expertModel.info(usersn, function (dbresult, doc) {
                    if (!dbresult) {
                        cb(true);
                    }
                    else {
                        expertsn.expertsn = doc.expertsn;
                        cb(null);
                    }
                });
            }
            else {
                cb(null);
            }
        },
        function (cb) {
            userModel.update(usersn, req.body, function (dbresult) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '수정 실패.';
                    cb(true);
                }
                else {
                    if (expertsn.expertsn == 0) {
                        errcode = 0;
                        cb(true);
                    }
                    else {
                        cb(null);
                    }
                }
            });
        },
        function (cb) {
            errcode = -1;
            var data = {
                'expertname': req.body.username
            };
            
            expertModel.update(expertsn, data, function (dbresult) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '수정 실패.';
                } else {
                    errcode = 0;
                    cb(null);
                }
            });
        }
    ], function (err, results) {
        switch (errcode) {
            case -1:
                userModel.update(usersn, user, function (dbresult) {
                    res.json(result);
                });
                break;
            default:
                if (user != null && user.status == '101_003' && req.body.status == '101_002' && req.body.pushyn) {
                    var arrPushKey = [];
                    arrPushKey.push(req.body.pushkey);
                    gcmHelper.send(2, '', arrPushKey);
                }
                res.json(result);
                break;
        }
    });
});

router.post('/delete', [tokenHelper.authMethod], function (req, res, next) {
    var usersn = { 'usersn': eval(req.body.usersn) };
    var result = {
        'result': 0,
        'message': ''
    }

    async.series([
        function (cb) {
            reviewModel.deleteByData(usersn, function (dbresult) {
                cb(null, dbresult);
            });
        },
        function (cb) {
            marketModel.deleteByData(usersn, function (dbresult) {
                cb(null, dbresult);
            });
        },
        function (cb) {
            qnaModel.deleteByData(usersn, function (dbresult) {
                cb(null, dbresult);
            });
        },
        function (cb) {
            expertModel.deleteByData(usersn, function (dbresult) {
                cb(null, dbresult);
            });
        },
        function (cb) {
            userModel.delete(usersn, function (dbresult) {
                cb(null, dbresult);
            });
        }
    ], function (err, results) {
        if (err) {
            result.result = -1;
            result.message = '에러.';
        }
        else {
            for (var item in results) {
                if (!results[item]) {
                    result.result = -1;
                    result.message = '에러.';
                }
            }
        }
        res.json(result);
    });
});

router.post('/checkAdmin', [tokenHelper.authMethod], function (req, res, next) {
    var data = { 'email': req.body.email, 'roles': '100_003', 'useyn': true };
    var password = req.body.password;
    var result = {
        'result': 0,
        'message': '',
        'item': null,
        'token': ''
    };
    
    userModel.checkAdmin(data, password, function (dbresult, doc) {
        if (!dbresult) {
            result.result = -1;
            result.message = '이메일 조회 실패.';
        }
        else {
            result.item = doc;
        }
        res.json(result);
    });
});

module.exports = router;