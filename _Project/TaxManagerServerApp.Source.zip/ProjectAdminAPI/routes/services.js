var express = require('express'),
    async = require('async'),
    gcmHelper = require('../common/gcmHelper'),
    tokenHelper = require('../common/tokenHelper'),
    expertModel = require('../models/expertModel'),
    marketModel = require('../models/marketModel'),
    mileagelogModel = require('../models/mileagelogModel'),
    userModel = require('../models/userModel'),
    router = express.Router();

router.get('/bidCheckList', [tokenHelper.authMethod], function (req, res) {
    var result = {
        'result': 0,
        'message': '',
        'list': null
    }

    async.parallel([
        function (cb) {
            // 리스트 조회 프로세스
            var status = '110_002';
            var addDate = 0;

            marketModel.bidCheckList(status, addDate, function (dbresult, docs) {
                if (!dbresult) {
                    cb(null, null);
                }
                else {
                    cb(null, docs);
                }
            });
        },
        function (cb) {
            // 리스트 조회 프로세스
            var status = '110_003';
            var addDate = 7;
            
            marketModel.bidCheckList(status, addDate, function (dbresult, docs) {
                if (!dbresult) {
                    cb(null, null);
                }
                else {
                    cb(null, docs);
                }
            });
        }
    ], function (err, results) {
        if (err) {
            result.result = -1;
            result.message = '리스트 조회 실패.';
        }
        else {
            var list = [];
            
            results.forEach( function (docs) {
                if (docs != null) {
                    docs.forEach( function (item) {
                        list.push(item);
                    });
                }
            });
            result.list = list;
        }
        res.json(result);
    });
});

router.post('/bidClose/:marketsn', [tokenHelper.authMethod], function (req, res) {
    var marketsn = eval(req.params.marketsn);
    var result = {
        'result': 0,
        'message': ''
    }
    var arruser = [];
    var arrPushKey = [];

    async.waterfall([
        function (cb) {
            marketModel.info(marketsn, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '처리 실패.';
                    cb(true);
                }
                else {
                    if (doc.status != '110_002') {
                        cb(true);
                    } else {
                        arruser.push(doc.usersn);
                        doc.bids.forEach( function (item) {
                            arruser.push(item.usersn);
                        });
                        cb(null);
                    }
                }
            });
        },
        function (cb) {
            userModel.pushlist(arruser, function (dbresult, docs) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '처리 실패.';
                    cb(true);
                } else {
                    docs.forEach( function (item) {
                        arrPushKey.push(item.pushkey);
                    });
                    cb(null);
                }
            });
        },
        function (cb) {
            var data = { 'status': '110_003' };

            marketModel.update(marketsn, data, function (dbresult) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '처리 실패.';
                    cb(true);
                }
                else {
                    cb(null);
                }
            });
        }
    ], function (err, results) {
        if (result.result == 0) {
            gcmHelper.send(5, '110_003', arrPushKey);
        }
        res.json(result);
    });

});

router.post('/bidCancel/:marketsn', [tokenHelper.authMethod], function (req, res) {
    var marketsn = eval(req.params.marketsn);
    var usersn = 0;
    var userdata = { 'warning': 0, 'status': '' };
    var arrExpertsn = [];
    var asyncTasks = [];
    var arrMileagelogsn = [];
    var mileage = 5000;
    var result = {
        'result': 0,
        'message': ''
    }
    var arruser = [];
    var arrPushKey = [];
    var errcode = 0;

    async.waterfall([
        function (cb) {
            marketModel.info(marketsn, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '조회 실패.';
                    cb(true);
                }
                else {
                    if (doc.status != '110_003') {
                        cb(true);
                    }
                    else {
                        usersn = doc.usersn;
                        
                        arruser.push(doc.usersn);
                        doc.bids.forEach( function (item) {
                            arruser.push(item.usersn);
                            arrExpertsn.push(item.expertsn);
                        });
                        cb(null);
                    }
                }
            });
        },
        // function (cb) {
        //     userModel.info(usersn, function (dbresult, doc) {
        //         if (!dbresult) {
        //             result.result = -1;
        //             result.message = '조회 실패.';
        //             cb(true);
        //         }
        //         else {
        //             userdata.warning = doc.warning;
        //             userdata.status = doc.status;
        //             cb(null);
        //         }
        //     });
        // },
        function (cb) {
            userModel.pushlist(arruser, function (dbresult, docs) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '처리 실패.';
                    cb(true);
                } else {
                    docs.forEach( function (item) {
                        arrPushKey.push(item.pushkey);
                    });
                    cb(null);
                }
            });
        },
        function (cb) {
            var data = { 'status': '110_005' };
            marketModel.update(marketsn, data, function (dbresult) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '처리 실패.';
                    cb(true);
                }
                else {
                    cb(null);
                }
            });
        },
        function (cb) {
            errcode = -1;
            
            var data = { 'warning': 1 };
            userModel.increment(usersn, data, function (dbresult) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '수정 실패.';
                    cb(true);
                }
                else {
                    cb(null);
                }
            });
        },
        function (cb) {
            errcode = -2;

            expertModel.listByExpert(arrExpertsn , function (dbresult, docs) {
                docs.forEach( function(item) {
                    var data = {
                        'expertsn': item.expertsn, 'expertname': item.expertname, 'mileagetype': '111_003',
                        'mileage': mileage, 'remainmileage': item.mileage
                    };

                    var task = function (cb) {
                        mileagelogModel.insert(data, function (dbresult, doc) {
                            if (!dbresult) {
                                cb(null, null);
                            }
                            else {
                                cb(null, doc);
                            }
                        });
                    }
                    asyncTasks.push(task);
                });
                
                async.parallel(asyncTasks, function (err, results) {
                    results.forEach( function (item) {
                        if (item != null) {
                            arrMileagelogsn.push(item.mileagelogsn);
                        }
                    })
                    cb(null);
                });
            });
        },
        function (cb) {
            errcode = -3;

            if (arrExpertsn.length > 0) {
                expertModel.bidsCancel(arrExpertsn, mileage, function (dbresult) {
                    if (!dbresult) {
                        result.result = -1;
                        result.message = '마일리지 지급 실패.';
                        cb(true);
                    }
                    else {
                        errcode = 0;
                        cb(null);
                    }
                });
            } else {
                errcode = 0;
                cb(null);
            }
        },
    ], function (err, results) {
        switch (errcode) {
            case -1:
                var data = { 'status': '110_003' };
                marketModel.update(marketsn, data, function (dbresult) {
                    result.result = -1;
                    result.message = '시스템 에러.';
                    res.json(result);
                });
                break;
            case -2:
                var data = { 'status': '110_003' };
                marketModel.update(marketsn, data, function (dbresult) {
                    
                    var data = { 'warning': -1 };
                    userModel.increment(usersn, data, function (dbresult) {

                    });
                });
                break;
            case -3:
                var data = { 'status': '110_003' };
                marketModel.update(marketsn, data, function (dbresult) {

                    var data = { 'warning': -1 };
                    userModel.increment(usersn, data, function (dbresult) {

                        var where = { 'mileagelogsn': { '$in': arrMileagelogsn } };
                        mileagelogModel.deleteByData(where, function (dbresult) {
                            result.result = -1;
                            result.message = '시스템 에러.';
                            res.json(result);
                        });
                    });
                });
                break;
            default:
                if (result.result == 0) {
                    gcmHelper.send(6, '110_005', arrPushKey);
                }
                res.json(result);
                break;
        }
    });
});

module.exports = router;