var express = require('express'),
    tokenHelper = require('../common/tokenHelper'),
    reviewModel = require('../models/reviewModel'),
    router = express.Router();

router.get('/list/:page/:pagesize', [tokenHelper.authMethod], function (req, res, next) {
	var result = {
        'result': 0,
        'message': '',
        'list': null,
        'totalcount': 0
    };
	
    var page = eval(req.params.page);
    var pagesize = eval(req.params.pagesize);
    
    reviewModel.list(page, pagesize, function (dbresult, list, totalcount) {
        if (!dbresult) {
            result.result = -1;
            result.message = '리스트 조회 실패.';
        } else {
            result.list = list;
            result.totalcount = totalcount;
        }
        res.json(result);
    });
});

router.get('/search/:page/:pagesize', [tokenHelper.authMethod], function (req, res, next) {
    var page = eval(req.params.page);
    var pagesize = eval(req.params.pagesize);
	var result = {
        'result': 0,
        'message': '',
        'list': null,
        'totalcount': 0
    };
    var expertsn = req.query.expertsn;
    var username = req.query.username;
    
    reviewModel.search(page, pagesize, expertsn, username, function (dbresult, list, totalcount) {
        if (!dbresult) {
            result.result = -1;
            result.message = '리스트 조회 실패.';
        }
        else {
            result.list = list;
            result.totalcount = totalcount;
        }
        res.json(result);
    });
});

router.post('/delete', [tokenHelper.authMethod], function (req, res) {
    var marketsn = { 'marketsn': eval(req.body.marketsn) };
	var result = {
        'result': 0,
        'message': ''
    };
    
    reviewModel.deleteByData(marketsn, function (dbresult) {
        if (!dbresult) {
            result.result = -1;
            result.message = '삭제 실패.';
        }
        res.json(result);
    });
});

module.exports = router;