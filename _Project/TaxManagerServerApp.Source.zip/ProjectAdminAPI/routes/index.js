var express = require('express'),
    async = require('async'),
    tokenHelper = require('../common/tokenHelper'),
    userModel = require('../models/userModel'),
    expertModel = require('../models/expertModel'),
    marketModel = require('../models/marketModel'),
    qnaModel = require('../models/qnaModel'),
    router = express.Router();

router.get('/', function (req, res) {
    res.json('');
});

// router.post('/gettoken', function (req, res) {
//     var profile = {
//         'name': 'ProjectAdminAPI'
//     };

//     var token = tokenHelper.setToken(profile);
//     res.json(token);
// });

router.get('/main', [tokenHelper.authMethod], function (req, res) {
    var result = {
   		'result': 0,
   		'message': '',
   		'item': {
            'usersCount': 0,
            'expertsCount': 0,
            'marketsCount': 0,
            'qnasCount': 0
        }
    };

    async.series([
        function (cb) {
            userModel.count( function(dbresult, totalcount) {
                if (!dbresult) { cb(null, null); }
                else { cb(null, totalcount); }
            });
        },
        function (cb) {
            expertModel.count( function(dbresult, totalcount) {
                if (!dbresult) { cb(null, null); }
                else { cb(null, totalcount); }
            });
        },
        function (cb) {
            marketModel.count( function(dbresult, totalcount) {
                if (!dbresult) { cb(null, null); }
                else { cb(null, totalcount); }
            });
        },
        function (cb) {
            qnaModel.count( function(dbresult, totalcount) {
                if (!dbresult) { cb(null, null); }
                else { cb(null, totalcount); }
            });
        }
    ], function (err, results) {
        if (err) {
            result.result = -1;
            result.message = '에러.';
        }
        else {
            result.item.usersCount = results[0];
            result.item.expertsCount = results[1];
            result.item.marketsCount = results[2];
            result.item.qnasCount = results[3];
        }
        res.json(result);
    });
});

module.exports = router;