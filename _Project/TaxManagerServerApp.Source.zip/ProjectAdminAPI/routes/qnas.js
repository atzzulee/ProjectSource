var express = require('express'),
    tokenHelper = require('../common/tokenHelper'),
    qnaModel = require('../models/qnaModel'),
    router = express.Router();
    
router.get('/list/:page/:pagesize', [tokenHelper.authMethod], function (req, res, next) {
    var page = eval(req.params.page);
    var pagesize = eval(req.params.pagesize);
    var result = {
        'result': 0,
        'message': '',
        'list': null,
        'totalcount': 0
    };
    
    qnaModel.list(page, pagesize, function (dbresult, list, totalcount) {
        if (!dbresult) {
            result.result = -1;
            result.message = '리스트 조회 실패.';
        }
        else {
            result.list = list;
            result.totalcount = totalcount;
        }
        res.json(result);
    });
});

router.get('/search/:page/:pagesize', [tokenHelper.authMethod], function (req, res, next) {
    var page = eval(req.params.page);
    var pagesize = eval(req.params.pagesize);
	var result = {
        'result': 0,
        'message': '',
        'list': null,
        'totalcount': 0
    };
    var expertsn = req.query.expertsn;
    var username = req.query.username;
    
    qnaModel.search(page, pagesize, expertsn, username, function (dbresult, list, totalcount) {
        if (!dbresult) {
            result.result = -1;
            result.message = '리스트 조회 실패.';
        }
        else {
            result.list = list;
            result.totalcount = totalcount;
        }
        res.json(result);
    });
});

router.post('/delete', [tokenHelper.authMethod], function (req, res, next) {
    var qnasn = { 'qnasn': eval(req.body.qnasn) };
    var result = {
        'result': 0,
        'message': ''
    };
    
    qnaModel.delete(qnasn, function (dbresult) {
        if (!dbresult) {
            result.result = -1;
            result.message = '삭제 실패.';
        }
        res.json(result);
    });
});

// router.post('/comments/insert', [tokenHelper.authMethod], function (req, res, next) {
//     var qnasn = { 'qnasn': eval(req.body.qnasn) };
//     delete req.body['qnasn'];
//     var result = {
//         'result': 0,
//         'message': ''
//     };
    
//     qnaModel.commentPush(qnasn, req.body, function (dbresult) {
//         if (!dbresult) {
//             result.result = -1;
//             result.message = '등록 실패.';
//         }
//         res.json(result);
//     });
// });

router.post('/comments/delete', [tokenHelper.authMethod], function (req, res, next) {
    var qnasn = { 'qnasn': eval(req.body.qnasn) };
    var _id = req.body._id;
    var result = {
        'result': 0,
        'message': ''
    };
    
    qnaModel.commentPull(qnasn, _id, function (dbresult) {
        if (!dbresult) {
            result.result = -1;
            result.message = '삭제 실패.';
        }
        res.json(result);
    });
});

module.exports = router;