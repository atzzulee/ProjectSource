var express = require('express'),
    async = require('async'),
    regioncode = require('../common/regioncode'),
    tokenHelper = require('../common/tokenHelper'),
    codeModel = require('../models/codeModel'),
    expertModel = require('../models/expertModel'),
    qnaModel = require('../models/qnaModel'),
    marketModel = require('../models/marketModel'),
    mileagelogModel = require('../models/mileagelogModel'),
    reviewModel = require('../models/reviewModel'),
    successfulbidModel = require('../models/successfulbidModel'),
    userModel = require('../models/userModel'),
    router = express.Router();

router.get('/list/:page/:pagesize', [tokenHelper.authMethod], function (req, res, next) {
    var page = eval(req.params.page);
    var pagesize = eval(req.params.pagesize);
	var result = {
        'result': 0,
        'message': '',
        'list': null,
        'totalcount': 0
    };
    
    expertModel.list(page, pagesize, function (dbresult, list, totalcount) {
        if (!dbresult) {
            result.result = -1;
            result.message = '리스트 조회 실패.';
        }
        else {
            result.list = list;
            result.totalcount = totalcount;
        }
        res.json(result);
    });
});

router.get('/search/:page/:pagesize', [tokenHelper.authMethod], function (req, res, next) {
    var page = eval(req.params.page);
    var pagesize = eval(req.params.pagesize);
	var result = {
        'result': 0,
        'message': '',
        'list': null,
        'totalcount': 0
    };
    var expertname = req.query.expertname;
    
    expertModel.search(page, pagesize, expertname, function (dbresult, list, totalcount) {
        if (!dbresult) {
            result.result = -1;
            result.message = '리스트 조회 실패.';
        }
        else {
            result.list = list;
            result.totalcount = totalcount;
        }
        res.json(result);
    });
});

router.get('/info/:expertsn', [tokenHelper.authMethod], function (req, res, next) {
    var expertsn = { 'expertsn': eval(req.params.expertsn) };
    
    var result = {
        'result': 0,
        'message': '',
        'item': null,
        'codelist': null,
        'regionlist': regioncode
    };
    
    async.series([
        function (cb) {
            codeModel.listByJob( function (dbresult, list) {
                if (!dbresult) {
                    cb(true, null);
                }
                else {
                    cb(null, list);
                }
            });
        },
        function (cb) {
            expertModel.info(expertsn, function (dbresult, item) {
                if (!dbresult) {
                    cb(true, null);
                }
                else {
                    cb(null, item);
                }
            });
        }
    ], function (err, results) {
        if (err) {
            result.result = -1;
            result.message = '리스트 조회 시 에러가 발생했습니다.';
        }
        else {
            var codeData = [];
            var item = [];
            var listitem = [];
            var count = 0;
            
            for (var i = 0 ; i < results[0].length ; ++i) {
                if (results[0][i].code.length == 3) {
                    if (count > 0)
                        codeData.push(item);
                    item = {
                        'code': results[0][i].code,
                        'value': results[0][i].value,
                        'list': []
                    };
                    count++;
                } else {
                    listitem = {
                        'code': results[0][i].code,
                        'value': results[0][i].value
                    }
                    item.list.push(listitem);
                }
            }
            
            if (count > 0)
                codeData.push(item);
            
            result.codelist = codeData;
            result.item = results[1];
        }
        
        res.json(result);
    });
});

router.post('/update', [tokenHelper.authMethod], function (req, res, next) {
    var expertsn = { 'expertsn': eval(req.body.expertsn) };
    req.body.academic = JSON.parse('[' + req.body.academic.substring(1) + ']');
    req.body.record = JSON.parse('[' + req.body.record.substring(1) + ']');
    req.body.categorys = JSON.parse('[' + req.body.categorys.substring(1) + ']');
    delete req.body['expertsn'];
    
    req.body.career = eval(req.body.career);
    req.body.age = eval(req.body.age);
    req.body.useyn = (req.body.useyn == '1' ? true : false);
    var result = {
        'result': 0,
        'message': ''
    };
    
    expertModel.update(expertsn, req.body, function (dbresult) {
        if (!dbresult) {
            result.result = -1;
            result.message = '수정 실패.';
        }
        res.json(result);
    });
});

router.post('/delete', [tokenHelper.authMethod], function (req, res, next) {
    var usersn = { 'usersn': eval(req.body.usersn) };
    var expertsn = { 'expertsn': eval(req.body.expertsn) };
    var result = {
        'result': 0,
        'message': ''
    };

    async.series([
        function (cb) {
            successfulbidModel.deleteByData(expertsn, function (dbresult) {
                cb(null, dbresult);
            });
        },
        function (cb) {
            reviewModel.deleteByData(expertsn, function (dbresult) {
                cb(null, dbresult);
            });
        },
        function (cb) {
            mileagelogModel.deleteByData(expertsn, function (dbresult) {
                cb(null, dbresult);
            });
        },
        function (cb) {
            marketModel.pullByData(expertsn, function (dbresult) {
                cb(null, dbresult);
            });
        },
        function (cb) {
            qnaModel.pullByData(expertsn, function (dbresult) {
                cb(null, dbresult);
            });
        },
        function (cb) {
            expertModel.deleteByData(expertsn, function (dbresult) {
                cb(null, dbresult);
            });
        },
        function (cb) {
            userModel.delete(usersn, function (dbresult) {
                cb(null, dbresult);
            });
        }
    ], function (err, results) {
        if (err) {
            result.result = -1;
            result.message = '에러.';
        }
        else {
            for (var item in results) {
                if (!results[item]) {
                    result.result = -1;
                    result.message = '에러.';
                }
            }
        }
        res.json(result);
    });
});

router.post('/update/mileage', [tokenHelper.authMethod], function (req, res) {
    var result = {
        'result': 0,
        'message': ''
    };
    
    async.waterfall([
        function (cb) {
            var expertsn = { 'expertsn': eval(req.body.expertsn) };
            
            expertModel.info(expertsn, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '에러.';
                    cb(true);
                }
                else {
                    cb(null, doc);
                }
            });
        },
        function (doc, cb) {
            var data = {
                'expertsn': eval(req.body.expertsn), 'expertname': doc.expertname, 'mileagetype': req.body.mileagetype,
                'mileage': eval(req.body.mileage), 'remainmileage': eval(doc.mileage)
            };
            
            mileagelogModel.insert(data, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '에러.';
                    cb(true);
                }
                else {
                    cb(null, doc);
                }
            });
        },
        function (doc, cb) {
            var expertsn = { 'expertsn': eval(req.body.expertsn) };
            var data = { 'mileage': doc.remainmileage };
            
            expertModel.update(expertsn, data, function (dbresult) {
                if (!dbresult) {
                    var mileagelogsn = { 'mileagelogsn': doc.mileagelogsn };
                    
                    mileagelogModel.delete(mileagelogsn, function (dbresult) {
                        result.result = -1;
                        result.message = '에러.';
                        cb(null);
                    });
                } else {
                    cb(null);
                }
            });
        }
    ], function (err, results) {
        res.json(result);
    });
});

router.post('/resort', [tokenHelper.authMethod], function (req, res, next) {
    var page = 1;
    var pagesize = 999999999;
    var result = {
        'result': 0,
        'message': ''
    };

    var useyn = { 'useyn': true };
    var field = { 'expertsn': 1 };
    expertModel.list(page, pagesize, function (dbresult, docs) {
	    var asyncTasks = [];
        
        docs.forEach( function(item) {
			var where = { 'expertsn': item.expertsn };
			var data = { 'sort': Math.random() };
			
            var task = function (cb) {
                expertModel.update(where, data, function (dbresult) {
                    
                    if (!dbresult) {
                        cb(null, false);
                    }
                    else {
                        cb(null, true);
                    }
                });
            }
            asyncTasks.push(task);
        });
        
        async.parallel(asyncTasks, function (err, results) {
            if (err) {
                result.result = -1;
                result.message = '전문가 재정렬 에러.';
            }
            res.json(result);
        });
    });
});

module.exports = router;