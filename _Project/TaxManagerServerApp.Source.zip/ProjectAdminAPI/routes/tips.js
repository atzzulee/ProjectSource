var express = require('express'),
    tokenHelper = require('../common/tokenHelper'),
    tipModel = require('../models/tipModel'),
    router = express.Router();
    
router.get('/list/:page/:pagesize', [tokenHelper.authMethod], function (req, res, next) {
    var page = eval(req.params.page);
    var pagesize = eval(req.params.pagesize);
	var result = {
        'result': 0,
        'message': '',
        'list': null,
        'totalcount': 0
    };
    
    tipModel.list(page, pagesize, function (dbresult, list, totalcount) {
        if (!dbresult) {
            result.result = -1;
            result.message = '리스트 조회 실패.';
        }
        else {
            result.list = list;
            result.totalcount = totalcount;
        }
        res.json(result);
    });
});

router.get('/info/:tipsn', [tokenHelper.authMethod], function (req, res, next) {
    var tipsn = { 'tipsn': eval(req.params.tipsn) };
    var result = {
        'result': 0,
        'message': '',
        'item': null
    };
    
    tipModel.info(tipsn, function (dbresult, item) {
        if (!dbresult) {
            result.result = -1;
            result.message = '상세 실패.';
        }
        else {
            result.item = item;
        }
        res.json(result);
    });
});

router.post('/insert', [tokenHelper.authMethod], function (req, res, next) {
    req.body.useyn = (req.body.useyn == '1' ? true : false);
    var result = {
        'result': 0,
        'message': ''
    };
    
    tipModel.insert(req.body, function (dbresult) {
        if (!dbresult) {
            result.result = -1;
            result.message = '등록 실패.';
        }
        res.json(result);
    });
});

router.post('/update', [tokenHelper.authMethod], function (req, res, next) {
    var tipsn = { 'tipsn': eval(req.body.tipsn) };
    delete req.body['tipsn'];
    req.body.useyn = (req.body.useyn == '1' ? true : false);
    var result = {
        'result': 0,
        'message': ''
    };
    
    tipModel.update(tipsn, req.body, function (dbresult) {
        if (!dbresult) {
            result.result = -1;
            result.message = '수정 실패.';
        }
        res.json(result);
    });
});

router.post('/delete', [tokenHelper.authMethod], function (req, res, next) {
    var tipsn = { 'tipsn': eval(req.body.tipsn) };
    var result = {
        'result': 0,
        'message': ''
    };
    
    tipModel.delete(tipsn, function (dbresult) {
        if (!dbresult) {
            result.result = -1;
            result.message = '삭제 실패.';
        }
        res.json(result);
    });
});

module.exports = router;