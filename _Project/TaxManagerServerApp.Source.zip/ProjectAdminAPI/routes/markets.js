var express = require('express'),
    async = require('async'),
    gcmHelper = require('../common/gcmHelper'),
    regioncode = require('../common/regioncode'),
    tokenHelper = require('../common/tokenHelper'),
    codeModel = require('../models/codeModel'),
    expertModel = require('../models/expertModel'),
    marketModel = require('../models/marketModel'),
    successfulbidModel = require('../models/successfulbidModel'),
    userModel = require('../models/userModel'),
    router = express.Router();

router.get('/finishlist/:page/:pagesize', [tokenHelper.authMethod], function (req, res, next) {
    var page = eval(req.params.page);
    var pagesize = eval(req.params.pagesize);
	var result = {
        'result': 0,
        'message': '',
        'list': null,
        'totalcount': 0
    };
    
    successfulbidModel.list(page, pagesize, function (dbresult, list, totalcount) {
        if (!dbresult) {
            result.result = -1;
            result.message = '리스트 조회 실패.';
            res.json(result);
        }
        else {
            var asyncTasks = [];
            list.forEach( function (item) {
                var task = function (cb) {
                    marketModel.info(item.marketsn, function (dbresult, doc) {
                        if (!dbresult) {
                            cb(null, null);
                        }
                        else {
                            cb(null, doc);
                        }
                    });
                }

                asyncTasks.push(task);
            });
            
            async.series(asyncTasks, function (err, results) {
                if (err) {
                    result.result = -1;
                    result.message = '리스트 조회 실패.';
                }
                else {
                    var datalist = [];
                    
                    list.forEach( function (item) {
                        var jsonData = item.toJSON();
                        
                        for (var i = 0; i < results.length; i++) {
                            var marketitem = results[i];
                            if (marketitem != null) {
                                if (jsonData.marketsn == marketitem.marketsn) {
                                    jsonData.usersn = marketitem.usersn;
                                    jsonData.username = marketitem.username;
                                    
                                    for (var j in marketitem.bids) {
                                        var biditem = marketitem.bids[j];

                                        if (biditem.expertsn == marketitem.success_expertsn) {
                                            jsonData.expertsn = biditem.expertsn;
                                            jsonData.expertname = biditem.expertname;
                                            jsonData.price1 = biditem.price1;
                                            jsonData.price2 = biditem.price2;
                                            break;
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                        
                        datalist.push(jsonData);
                    });
                    result.list = datalist;
                    result.totalcount = totalcount;
                }
                res.json(result);
            });
        }
    });
});

router.get('/finishsearch/:page/:pagesize', [tokenHelper.authMethod], function (req, res, next) {
    var page = eval(req.params.page);
    var pagesize = eval(req.params.pagesize);
	var result = {
        'result': 0,
        'message': '',
        'list': null,
        'totalcount': 0
    };
    var expertsn = req.query.expertsn;
    
    successfulbidModel.search(page, pagesize, expertsn, function (dbresult, list, totalcount) {
        if (!dbresult) {
            result.result = -1;
            result.message = '리스트 조회 실패.';
            res.json(result);
        }
        else {
            var asyncTasks = [];
            list.forEach( function (item) {
                var task = function (cb) {
                    marketModel.info(item.marketsn, function (dbresult, doc) {
                        if (!dbresult) {
                            cb(null, null);
                        }
                        else {
                            cb(null, doc);
                        }
                    });
                }

                asyncTasks.push(task);
            });
            
            async.series(asyncTasks, function (err, results) {
                if (err) {
                    result.result = -1;
                    result.message = '리스트 조회 실패.';
                }
                else {
                    var datalist = [];
                    
                    list.forEach( function (item) {
                        var jsonData = item.toJSON();
                        
                        for (var i = 0; i < results.length; i++) {
                            var marketitem = results[i];
                            if (marketitem != null) {
                                if (jsonData.marketsn == marketitem.marketsn) {
                                    jsonData.usersn = marketitem.usersn;
                                    jsonData.username = marketitem.username;
                                    
                                    for (var j in marketitem.bids) {
                                        var biditem = marketitem.bids[j];

                                        if (biditem.expertsn == marketitem.success_expertsn) {
                                            jsonData.expertsn = biditem.expertsn;
                                            jsonData.expertname = biditem.expertname;
                                            jsonData.price1 = biditem.price1;
                                            jsonData.price2 = biditem.price2;
                                            break;
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                        
                        datalist.push(jsonData);
                    });
                    result.list = datalist;
                    result.totalcount = totalcount;
                }
                res.json(result);
            });
        }
    });
});

router.get('/list/:page/:pagesize', [tokenHelper.authMethod], function (req, res, next) {
    var page = eval(req.params.page);
    var pagesize = eval(req.params.pagesize);
	var result = {
        'result': 0,
        'message': '',
        'list': null,
        'totalcount': 0
    };
    
    marketModel.list(page, pagesize, function (dbresult, list, totalcount) {
        if (!dbresult) {
            result.result = -1;
            result.message = '리스트 조회 실패.';
        }
        else {
            result.list = list;
            result.totalcount = totalcount;
        }
        res.json(result);
    });
});

router.get('/search/:page/:pagesize', function (req, res, next) {
    var page = eval(req.params.page);
    var pagesize = eval(req.params.pagesize);
	var result = {
        'result': 0,
        'message': '',
        'list': null,
        'totalcount': 0
    };
    var username = req.query.username;
    
    marketModel.search(page, pagesize, username, function (dbresult, list, totalcount) {
        if (!dbresult) {
            result.result = -1;
            result.message = '리스트 조회 실패.';
        }
        else {
            result.list = list;
            result.totalcount = totalcount;
        }
        res.json(result);
    });
});

router.get('/info/:marketsn', [tokenHelper.authMethod], function (req, res, next) {
    var marketsn = eval(req.params.marketsn);
    var result = {
        'result': 0,
        'message': '',
        'item': null,
        'codelist': null,
        'regionlist': regioncode
    };
    
    async.series([
        function (cb) {
            codeModel.listByJob( function (dbresult, list) {
                if (!dbresult) {
                    cb(true, null);
                }
                else {
                    cb(null, list);
                }
            });
        },
        function (cb) {
            marketModel.info(marketsn, function (dbresult, item) {
                if (!dbresult) {
                    cb(true, null);
                }
                else {
                    cb(null, item);
                }
            });
        }
    ], function (err, results) {
        if (err) {
            result.result = -1;
            result.message = '리스트 조회 시 에러가 발생했습니다.';
        }
        else {
            var codeData = [];
            var item = [];
            var listitem = [];
            var count = 0;
            
            for (var i = 0 ; i < results[0].length ; ++i) {
                if (results[0][i].code.length == 3) {
                    if (count > 0)
                        codeData.push(item);
                    item = {
                        'code': results[0][i].code,
                        'value': results[0][i].value,
                        'list': []
                    };
                    count++;
                } else {
                    listitem = {
                        'code': results[0][i].code,
                        'value': results[0][i].value
                    }
                    item.list.push(listitem);
                }
            }
            
            if (count > 0)
                codeData.push(item);
            
            result.codelist = codeData;
            result.item = results[1];
        }
        
        res.json(result);
    });
});

router.post('/update', [tokenHelper.authMethod], function (req, res, next) {
    var marketsn = eval(req.body.marketsn);
    delete req.body['marketsn'];
    
    if (req.body.markettype == '001') {
        delete req.body['markettype2_1'];
        delete req.body['markettype2_2'];
        
        req.body.markettype1_2 = eval(req.body.markettype1_2);
        req.body.markettype1_4 = eval(req.body.markettype1_4);
    } else if (req.body.markettype == '002') {
        delete req.body['markettype1_1'];
        delete req.body['markettype1_2'];
        delete req.body['markettype1_3'];
        delete req.body['markettype1_4'];
        
        req.body.markettype2_1 = req.body.markettype2_1.split(',');
        req.body.markettype2_2 = req.body.markettype2_2.split(',');
    } else {
        delete req.body['markettype1_1'];
        delete req.body['markettype1_2'];
        delete req.body['markettype1_3'];
        delete req.body['markettype1_4'];
        delete req.body['markettype1_4'];
        delete req.body['markettype2_1'];
        delete req.body['markettype2_2'];
    }
    
    req.body.enddate = eval(req.body.enddate);
    req.body.useyn = (req.body.useyn == '1' ? true : false);
    var result = {
        'result': 0,
        'message': ''
    };
    var status;
    var arruser = [];
    var arrPushKey = [];
    
    async.waterfall([
        function (cb) {
            marketModel.info(marketsn, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '수정 실패.';
                    cb(true);
                }
                else {
                    arruser.push(doc.usersn);
                    status = doc.status;
                    cb(null);
                }
            });
        },
        function (cb) {
            userModel.pushlist(arruser, function (dbresult, docs) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '수정 실패.';
                    cb(true);
                } else {
                    docs.forEach( function (item) {
                        arrPushKey.push(item.pushkey);
                    });
                    cb(null);
                }
            });
        },
        function (cb) {
            marketModel.update(marketsn, req.body, function (dbresult) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '수정 실패.';
                    cb(true);
                } else {
                    cb(null);
                }
            });
        }
    ], function (err, results) {
        if (status == '110_001' && req.body.status == '110_002' && arrPushKey.length > 0) {
            gcmHelper.send(3, '', arrPushKey);
        }

        res.json(result);
    });
});

router.post('/delete', [tokenHelper.authMethod], function (req, res, next) {
    var marketsn = { 'marketsn': eval(req.body.marketsn) };
    var result = {
        'result': 0,
        'message': ''
    }

    async.series([
        function (cb) {
            marketModel.deleteByData(marketsn, function (dbresult) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '삭제 실패.';
                    cb(true);
                }
                else {
                    cb(null);
                }
            });
        },
        function (cb) {
            expertModel.pullByData(eval(req.body.marketsn), function (dbresult) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '삭제 실패.';
                    cb(true);
                } else {
                    cb(null);
                }
            });
        }
    ], function (err, results) {
        res.json(result);
    });
});

// router.post('/bids/insert', [tokenHelper.authMethod], function (req, res, next) {
//     var marketsn = { 'marketsn': eval(req.body.marketsn) };
//     delete req.body['marketsn'];
//     var result = {
//         'result': 0,
//         'message': ''
//     };
    
//     var data = {
//         expertsn: 1, // 관리자일련번호
//         expertname: 1, // 관리자이름 
//         mainintroduce: '111111', // 메인소개글
//         price1: 10000, // 기장료
//         price2: 10000 // 조정료
//     }
    
//     marketModel.bidPush(marketsn, data, function (dbresult) {
//         if (!dbresult) {
//             result.result = -1;
//             result.message = '등록 실패.';
//         }
//         res.json(result);
//     });
// });

router.post('/bids/delete', [tokenHelper.authMethod], function (req, res, next) {
    var marketsn = eval(req.body.marketsn);
    var _id = req.body._id;
    var result = {
        'result': 0,
        'message': ''
    };
    
    marketModel.bidPull(marketsn, _id, function (dbresult) {
        if (!dbresult) {
            result.result = -1;
            result.message = '삭제 실패.';
        }
        res.json(result);
    });
});

module.exports = router;