var mongoose = require('mongoose');
var url = 'mongodb://localhost:27017/testdb';
var options = {
	server: { poolSize : 100 }
}

var db = mongoose.createConnection(url, options);

db.on('error', function(err) {
   console.log('Error : ', err);
});

db.on('open', function() {
   console.log('Mongo DB Connected Successfully.');
});

// DB 생성
module.exports = db;