var loggerHelper = require('../common/loggerHelper');

exports.notFound = function (req, res, next) {
	var result = {
        'result': -1,
        'message': '라우터를 찾을 수 없습니다.',
        'name': 'NotFound',
        'code': 'Bad Request',
        'status': 404
    };
    loggerHelper.warn(res);
    res.json(result);
};

exports.error = function (err, req, res, next){
	var result = {
        'result': -1,
        'message': err.message,
        'name': 'Error',
        'code': 'Bad Request',
        'status': 500
    };
    loggerHelper.error(err);
    res.json(result);
};