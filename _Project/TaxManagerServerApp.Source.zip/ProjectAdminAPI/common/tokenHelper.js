var expressJwt = require('express-jwt'),
    jwt = require('jsonwebtoken'),
    config = require('../config');

var SECRET = config.token.secret;

function getToken(req) {
    if (req.headers.authorization && req.headers.authorization.split(' ')[0] === 'Bearer') {
        return req.headers.authorization.split(' ')[1];
    } else if (req.query && req.query.token) {
        return req.query.token;
    }
    
    return null;
}

function getProfile(token) {
    return jwt.verify(token, SECRET);
}

function setToken(profile) {
    return jwt.sign(profile, SECRET, { expiresIn: config.token.timeout });
}

exports.getToken = getToken;
exports.getProfile = getProfile;
exports.setToken = setToken;
exports.authMethod = expressJwt({
    secret: SECRET,
    getToken: getToken
});

exports.refreshToken = function (token, callback) {
    var profile = getProfile(token);
    var newToken = setToken(profile);
    callback(true, newToken);
}