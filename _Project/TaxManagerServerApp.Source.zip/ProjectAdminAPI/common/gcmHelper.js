// gcmHelper.js
var gcm = require('node-gcm'),
    config = require('../config');

exports.send = function (sendtype, param, pushkeys) {
    var msg = new gcm.Message({
        collapseKey: 'demo',
        priority: 'high',
        contentAvailable: true,
        delayWhileIdle: true,
        timeToLive: 3,
        restrictedPackageName: config.gcm.packagename,
        //dryRun: true,
        data: {
            'code': sendtype,
            'title': '회계매니저',
            'message': '',
            'url': '',
            'param': param
        }
    });

    switch (sendtype) {
        case 1:
            // 공지사항 전체공지 // ProjectAdminAPI // 사용안함
            msg.params.data.message = '회계 매니저에서 새로운 공지가 올라왔습니다.';
            msg.params.data.url = '/notices/list';
            break;
        case 2:
            // 견적-전문가에게 공지, 메인 페이지로 이동 // ProjectAdminAPI
            msg.params.data.message = '축하드립니다. 승인이 완료 되었습니다.';
            msg.params.data.url = '/api/markets/list';
            break;
        case 3:
            // 견적-소비자에게 공지, 견적페이지로 이동 // ProjectAdminAPI
            msg.params.data.message = '견적 승인이 완료 되었습니다.';
            msg.params.data.url = '/api/users/myprofile';
            break;
        case 4:
            // 견적-소비자에게 공지, 견적페이지로 이동 // ProjectAPI
            msg.params.data.message = '전문가가 입찰을 하였습니다.';
            msg.params.data.url = '/api/markets/info/';
            msg.params.data.param = param;
            break;
        case 5:
            // 견적-소비자에게 공지, 견적페이지로 이동 // ProjectAdminAPI
            msg.params.data.message = '입찰이 마감 되었습니다.';
            msg.params.data.url = '/api/experts/list';
            msg.params.data.param = param;
            break;
        case 6:
            // 견적-소비자에게 공지, 견적페이지로 이동 // ProjectAdminAPI
            msg.params.data.message = '입찰이 취소 되었습니다.';
            msg.params.data.url = '/api/experts/list';
            msg.params.data.param = param;
            break;
        case 7:
            // 견적-소비자에게 공지, 견적페이지로 이동 // ProjectAPI
            msg.params.data.message = '축하드립니다. 낙찰되셨습니다.';
            msg.params.data.url = '/api/experts/list';
            msg.params.data.param = param;
            break;
        case 8:
            // 견적-소비자에게 공지, 견적페이지로 이동 // ProjectAPI
            msg.params.data.message = '유찰되셨습니다. 다음 기회를 이용 부탁드립니다.';
            msg.params.data.url = '/api/experts/list';
            msg.params.data.param = param;
            break;
        case 9:
            // 견적-소비자에게 공지, 견적페이지로 이동 // ProjectAPI
            msg.params.data.message = '리뷰가 도착 하였습니다.';
            msg.params.data.url = '/experts/info/';
            msg.params.data.param = param;
            break;
        case 10:
            // QNA 답글 추가 / ProjectAPI
            msg.params.data.message = 'QNA 답글이 도착 하였습니다.';
            msg.params.data.url = '/api/qnas/info/';
            msg.params.data.param = param;
            break;
        default:
            break;
    }
    
    var sender = new gcm.Sender(config.gcm.server_access_key);
    sender.send(msg, pushkeys, 4, function (err, result) { });
}