var config = require('../config');

module.exports.authenticated = function authenticated (req, res, next) {
	req.session.isAuthenticated = req.session.isAuthenticated ? true : false;
	
	//req.session.isAuthenticated = true;
	res.locals.isAuthenticated = req.session.isAuthenticated;
	if (req.session.isAuthenticated) {
		res.locals.user = req.session.user;
	}
	next();
};

module.exports.requireAuthentication = function requireAuthentication (req, res, next) {
	if (req.session.isAuthenticated) {
		next();
	} else {
		res.redirect('/');
	}
};

module.exports.logOut = function logOut (req, res){
    req.session.destroy();  // 세션 삭제
	res.clearCookie(config.secret); // 세션 쿠키 삭제
};