var request = require('request'),
    fs = require('fs'),
	config = require('../config');

exports.getRequest = function (routerUrl, method, data) {
    return new Promise( function (resolve, reject) {
        request({
            'uri': 'http://' + config.serviceIP + ':' + config.adminAPIServicePort + routerUrl,
            'form': data,
            'headers': { 'Authorization': 'Bearer ' + config.token },
            'method': method,
            'timeout': 10000,
            'followRedirect': true,
            'maxRedirects': 10
        }, function (err, res, result) {
            if (result != null) {
                resolve(result);
            }
            else {
                reject(Error('AdminAPI 에러.'));
            }
        });
    });
}

exports.registScript = function (res, message, url) {
    var script = '<script type="text/javascript">alert("' + message + '");';

    if (url != null) {
        script += 'location.href="' + url + '"';
    } else {
        script += 'history.back();';
    }

    script += '</script>';

    res.send(script);
}

exports.getNewFileName = function (file) {
    var date = new Date().format('yyyyMMddHHmmss');
    var idx =  file.originalname.lastIndexOf('.');
    var name = file.originalname.substring(0, idx);
    var ext = file.originalname.substring(idx);
    var baseUrl = './public/images/';
    
    var i = 1;
    var oldFileName = baseUrl + file.filename;
    var newFileName = baseUrl + date + '_' + name + ext;
    flag = fs.existsSync(newFileName);
    
    while (flag) {
        newFileName = baseUrl + date + '_' + name + '_' + i + ext;
        flag = fs.existsSync(newFileName);
        i++;
    }
    
    fs.renameSync(oldFileName, newFileName);
    return newFileName.replace('./public', '');
}