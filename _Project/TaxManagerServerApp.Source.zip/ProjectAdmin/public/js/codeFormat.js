String.prototype.codeFormat = function () {
    var returnValue = '';

    switch(this.toString()) {
        case '001':
            returnValue = '기장';
            break;
        case '001_001':
            returnValue = '음식';
            break;
        case '001_002':
            returnValue = '소매';
            break;
        case '001_003':
            returnValue = '생활서비스';
            break;
        case '001_004':
            returnValue = '제조';
            break;
        case '001_005':
            returnValue = '도매/유통/무역';
            break;
        case '001_006':
            returnValue = '학문/교육';
            break;
        case '001_007':
            returnValue = '의료';
            break;
        case '001_008':
            returnValue = '부동산';
            break;
        case '001_009':
            returnValue = '문화/예술/종교';
            break;
        case '001_010':
            returnValue = '금융';
            break;
        case '001_011':
            returnValue = '숙박';
            break;
        case '001_012':
            returnValue = '교통/운송';
            break;
        case '001_013':
            returnValue = '관광/여가/오락';
            break;
        case '001_014':
            returnValue = '스타트업';
            break;
        case '002':
            returnValue = 'TAX';
            break;
        case '002_001':
            returnValue = '상속세';
            break;
        case '002_002':
            returnValue = '증여세';
            break;
        case '002_003':
            returnValue = '양도세';
            break;
        case '003':
            returnValue = '기타';
            break;
        case '100_001':
            returnValue = 'Users';
            break;
        case '100_002':
            returnValue = 'Experts';
            break;
        case '100_003':
            returnValue = 'Admins';
            break;
        case '101_001':
            returnValue = '정상';
            break;
        case '101_002':
            returnValue = '전문가';
            break;
        case '101_003':
            returnValue = '전문가 가입중';
            break;
        case '101_004':
            returnValue = '블럭';
            break;
        case '101_005':
            returnValue = '탈퇴';
            break;
        case '102_001':
            returnValue = '회계사';
            break;
        case '102_002':
            returnValue = '세무사';
            break;
        case '103_001':
            returnValue = '남자';
            break;
        case '103_002':
            returnValue = '여자';
            break;
        case '104_001':
            returnValue = '개인사무소';
            break;
        case '104_002':
            returnValue = '법인사무소';
            break;
        case '105_001':
            returnValue = '국세청';
            break;
        case '105_002':
            returnValue = '금감원';
            break;
        case '105_003':
            returnValue = '공무원';
            break;
        case '105_004':
            returnValue = '은행,증권';
            break;
        case '105_005':
            returnValue = '기타';
            break;
        case '108_001':
            returnValue = '신규';
            break;
        case '108_002':
            returnValue = '기존';
            break;
        case '109_001':
            returnValue = '개인';
            break;
        case '109_002':
            returnValue = '법인';
            break;
        case '109_003':
            returnValue = '간이';
            break;
        case '110_001':
            returnValue = '입찰전';
            break;
        case '110_002':
            returnValue = '입찰중';
            break;
        case '110_003':
            returnValue = '입찰마감';
            break;
        case '110_004':
            returnValue = '낙찰완료';
            break;
        case '110_005':
            returnValue = '입찰취소';
            break;
        case '110_006':
            returnValue = '유찰';
            break;
        case '111_001':
            returnValue = '충전';
            break;
        case '111_002':
            returnValue = '사용';
            break;
        case '111_003':
            returnValue = '입찰취소';
            break;
        case '111_004':
            returnValue = '관리자지급';
            break;
        case '111_005':
            returnValue = '관리자회수';
            break;
        case '111_006':
            returnValue = '리뷰지급';
            break;
        case '112_001':
            returnValue = '일반';
            break;
        case '112_002':
            returnValue = '이벤트공지';
            break;
        case '113_001':
            returnValue = '면세';
            break;
        case '113_002':
            returnValue = '과세';
            break;
        case '114_001':
            returnValue = '토지';
            break;
        case '114_002':
            returnValue = '주택';
            break;
        case '114_003':
            returnValue = '주식';
            break;
        case '114_004':
            returnValue = '예금';
            break;

 // region
        case '11':
            returnValue = '서울특별시';
            break;
        case '11010':
            returnValue = '종로구';
            break;
        case '11020':
            returnValue = '중구';
            break;
        case '11030':
            returnValue = '용산구';
            break;
        case '11040':
            returnValue = '성동구';
            break;
        case '11050':
            returnValue = '광진구';
            break;
        case '11060':
            returnValue = '동대문구';
            break;
        case '11070':
            returnValue = '중랑구';
            break;
        case '11080':
            returnValue = '성북구';
            break;
        case '11090':
            returnValue = '강북구';
            break;
        case '11100':
            returnValue = '도봉구';
            break;
        case '11110':
            returnValue = '노원구';
            break;
        case '11120':
            returnValue = '은평구';
            break;
        case '11130':
            returnValue = '서대문구';
            break;
        case '11140':
            returnValue = '마포구';
            break;
        case '11150':
            returnValue = '양천구';
            break;
        case '11160':
            returnValue = '강서구';
            break;
        case '11170':
            returnValue = '구로구';
            break;
        case '11180':
            returnValue = '금천구';
            break;
        case '11190':
            returnValue = '영등포구';
            break;
        case '11200':
            returnValue = '동작구';
            break;
        case '11210':
            returnValue = '관악구';
            break;
        case '11220':
            returnValue = '서초구';
            break;
        case '11230':
            returnValue = '강남구';
            break;
        case '11240':
            returnValue = '송파구';
            break;
        case '11250':
            returnValue = '강동구';
            break;
        case '21':
            returnValue = '부산광역시';
            break;
        case '21010':
            returnValue = '중구';
            break;
        case '21020':
            returnValue = '서구';
            break;
        case '21030':
            returnValue = '동구';
            break;
        case '21040':
            returnValue = '영도구';
            break;
        case '21050':
            returnValue = '부산진구';
            break;
        case '21060':
            returnValue = '동래구';
            break;
        case '21070':
            returnValue = '남구';
            break;
        case '21080':
            returnValue = '북구';
            break;
        case '21090':
            returnValue = '해운대구';
            break;
        case '21100':
            returnValue = '사하구';
            break;
        case '21110':
            returnValue = '금정구';
            break;
        case '21120':
            returnValue = '강서구';
            break;
        case '21130':
            returnValue = '연제구';
            break;
        case '21140':
            returnValue = '수영구';
            break;
        case '21150':
            returnValue = '사상구';
            break;
        case '21310':
            returnValue = '기장군';
            break;
        case '22':
            returnValue = '대구광역시';
            break;
        case '22010':
            returnValue = '중구';
            break;
        case '22020':
            returnValue = '동구';
            break;
        case '22030':
            returnValue = '서구';
            break;
        case '22040':
            returnValue = '남구';
            break;
        case '22050':
            returnValue = '북구';
            break;
        case '22060':
            returnValue = '수성구';
            break;
        case '22070':
            returnValue = '달서구';
            break;
        case '22310':
            returnValue = '달성군';
            break;
        case '23':
            returnValue = '인천광역시';
            break;
        case '23010':
            returnValue = '중구';
            break;
        case '23020':
            returnValue = '동구';
            break;
        case '23030':
            returnValue = '남구';
            break;
        case '23040':
            returnValue = '연수구';
            break;
        case '23050':
            returnValue = '남동구';
            break;
        case '23060':
            returnValue = '부평구';
            break;
        case '23070':
            returnValue = '계양구';
            break;
        case '23080':
            returnValue = '서구';
            break;
        case '23310':
            returnValue = '강화군';
            break;
        case '23320':
            returnValue = '웅진군';
            break;
        case '24':
            returnValue = '광주광역시';
            break;
        case '24010':
            returnValue = '동구';
            break;
        case '24020':
            returnValue = '서구';
            break;
        case '24030':
            returnValue = '남구';
            break;
        case '24040':
            returnValue = '북구';
            break;
        case '24050':
            returnValue = '광산구';
            break;
        case '25':
            returnValue = '대전광역시';
            break;
        case '25010':
            returnValue = '동구';
            break;
        case '25020':
            returnValue = '중구';
            break;
        case '25030':
            returnValue = '서구';
            break;
        case '25040':
            returnValue = '유성구';
            break;
        case '25050':
            returnValue = '대덕구';
            break;
        case '26':
            returnValue = '울산광역시';
            break;
        case '26010':
            returnValue = '중구';
            break;
        case '26020':
            returnValue = '남구';
            break;
        case '26030':
            returnValue = '동구';
            break;
        case '26040':
            returnValue = '북구';
            break;
        case '26310':
            returnValue = '울주군';
            break;
        case '29':
            returnValue = '세종특별자치시';
            break;
        case '29010':
            returnValue = '세종시';
            break;
        case '31':
            returnValue = '경기도';
            break;
        case '31010':
            returnValue = '수원시';
            break;
        case '31020':
            returnValue = '성남시';
            break;
        case '31030':
            returnValue = '의정부시';
            break;
        case '31040':
            returnValue = '안양시';
            break;
        case '31050':
            returnValue = '부천시';
            break;
        case '31060':
            returnValue = '광명시';
            break;
        case '31070':
            returnValue = '평택시';
            break;
        case '31080':
            returnValue = '동두천시';
            break;
        case '31090':
            returnValue = '안산시';
            break;
        case '31100':
            returnValue = '고양시';
            break;
        case '31110':
            returnValue = '과천시';
            break;
        case '31120':
            returnValue = '구리시';
            break;
        case '31130':
            returnValue = '남양주시';
            break;
        case '31140':
            returnValue = '오산시';
            break;
        case '31150':
            returnValue = '시흥시';
            break;
        case '31160':
            returnValue = '군포시';
            break;
        case '31170':
            returnValue = '의왕시';
            break;
        case '31180':
            returnValue = '하남시';
            break;
        case '31190':
            returnValue = '용인시';
            break;
        case '31200':
            returnValue = '파주시';
            break;
        case '31210':
            returnValue = '이천시';
            break;
        case '31220':
            returnValue = '안성시';
            break;
        case '31230':
            returnValue = '김포시';
            break;
        case '31240':
            returnValue = '화성시';
            break;
        case '31250':
            returnValue = '광주시';
            break;
        case '31260':
            returnValue = '양주시';
            break;
        case '31270':
            returnValue = '포천시';
            break;
        case '31280':
            returnValue = '여주시';
            break;
        case '31350':
            returnValue = '연천군';
            break;
        case '31370':
            returnValue = '가평군';
            break;
        case '31380':
            returnValue = '양평군';
            break;
        case '32':
            returnValue = '강원도';
            break;
        case '32010':
            returnValue = '춘천시';
            break;
        case '32020':
            returnValue = '원주시';
            break;
        case '32030':
            returnValue = '강릉시';
            break;
        case '32040':
            returnValue = '동해시';
            break;
        case '32050':
            returnValue = '태백시';
            break;
        case '32060':
            returnValue = '속초시';
            break;
        case '32070':
            returnValue = '삼척시';
            break;
        case '32310':
            returnValue = '홏천군`';
            break;
        case '32320':
            returnValue = '회성군';
            break;
        case '32330':
            returnValue = '영월군';
            break;
        case '32340':
            returnValue = '평창군';
            break;
        case '32350':
            returnValue = '정선군';
            break;
        case '32360':
            returnValue = '철원군';
            break;
        case '32370':
            returnValue = '화천군';
            break;
        case '32380':
            returnValue = '양구군';
            break;
        case '32390':
            returnValue = '인제군';
            break;
        case '32400':
            returnValue = '고성군';
            break;
        case '32410':
            returnValue = '양양군';
            break;
        case '33':
            returnValue = '충청북도';
            break;
        case '33020':
            returnValue = '충주시';
            break;
        case '33030':
            returnValue = '제천시';
            break;
        case '33040':
            returnValue = '청주시';
            break;
        case '33320':
            returnValue = '보은군';
            break;
        case '33330':
            returnValue = '옥천군';
            break;
        case '33340':
            returnValue = '영동군';
            break;
        case '33350':
            returnValue = '진천군';
            break;
        case '33360':
            returnValue = '괴산군';
            break;
        case '33370':
            returnValue = '음성군';
            break;
        case '33380':
            returnValue = '단양군';
            break;
        case '33390':
            returnValue = '증평군';
            break;
        case '34':
            returnValue = '충청남도';
            break;
        case '34010':
            returnValue = '천안시';
            break;
        case '34020':
            returnValue = '공주시';
            break;
        case '34030':
            returnValue = '보령시';
            break;
        case '34040':
            returnValue = '아산시';
            break;
        case '34050':
            returnValue = '서산시';
            break;
        case '34060':
            returnValue = '논산시';
            break;
        case '34070':
            returnValue = '계룡시';
            break;
        case '34080':
            returnValue = '당진시';
            break;
        case '34310':
            returnValue = '금산군';
            break;
        case '34330':
            returnValue = '부여군';
            break;
        case '34340':
            returnValue = '서천군';
            break;
        case '34350':
            returnValue = '청양군';
            break;
        case '34360':
            returnValue = '홍성군';
            break;
        case '34370':
            returnValue = '예산군';
            break;
        case '34380':
            returnValue = '태안군';
            break;
        case '35':
            returnValue = '전라북도';
            break;
        case '35010':
            returnValue = '전주시';
            break;
        case '35020':
            returnValue = '군산시';
            break;
        case '35030':
            returnValue = '익산시';
            break;
        case '35040':
            returnValue = '정읍시';
            break;
        case '35050':
            returnValue = '남원시';
            break;
        case '35060':
            returnValue = '김제시';
            break;
        case '35310':
            returnValue = '완주군';
            break;
        case '35320':
            returnValue = '진안군';
            break;
        case '35330':
            returnValue = '무주군';
            break;
        case '35340':
            returnValue = '장수군';
            break;
        case '35350':
            returnValue = '임실군';
            break;
        case '35360':
            returnValue = '순창군';
            break;
        case '35370':
            returnValue = '고창군';
            break;
        case '35380':
            returnValue = '부안군';
            break;
        case '36':
            returnValue = '전라남도';
            break;
        case '36010':
            returnValue = '목포시';
            break;
        case '36020':
            returnValue = '여수시';
            break;
        case '36030':
            returnValue = '순천시';
            break;
        case '36040':
            returnValue = '나주시';
            break;
        case '36060':
            returnValue = '광양시';
            break;
        case '36310':
            returnValue = '담양군';
            break;
        case '36320':
            returnValue = '곡성군';
            break;
        case '36330':
            returnValue = '구례군';
            break;
        case '36350':
            returnValue = '고흥군';
            break;
        case '36360':
            returnValue = '보성군';
            break;
        case '36370':
            returnValue = '화순군';
            break;
        case '36380':
            returnValue = '장흥군';
            break;
        case '36390':
            returnValue = '강진군';
            break;
        case '36400':
            returnValue = '해남군';
            break;
        case '36410':
            returnValue = '영암군';
            break;
        case '36420':
            returnValue = '무안군';
            break;
        case '36430':
            returnValue = '함평군';
            break;
        case '36440':
            returnValue = '영광군';
            break;
        case '36450':
            returnValue = '장성군';
            break;
        case '36460':
            returnValue = '완도군';
            break;
        case '36470':
            returnValue = '진도군';
            break;
        case '36480':
            returnValue = '신안군';
            break;
        case '37':
            returnValue = '경상북도';
            break;
        case '37010':
            returnValue = '포항시';
            break;
        case '37020':
            returnValue = '경주시';
            break;
        case '37030':
            returnValue = '김천시';
            break;
        case '37040':
            returnValue = '안동시';
            break;
        case '37050':
            returnValue = '구미시';
            break;
        case '37060':
            returnValue = '영주시';
            break;
        case '37070':
            returnValue = '영천시';
            break;
        case '37080':
            returnValue = '상주시';
            break;
        case '37090':
            returnValue = '문경시';
            break;
        case '37100':
            returnValue = '경산시';
            break;
        case '37310':
            returnValue = '군위군';
            break;
        case '37320':
            returnValue = '의성군';
            break;
        case '37330':
            returnValue = '청송군';
            break;
        case '37340':
            returnValue = '양양군';
            break;
        case '37350':
            returnValue = '영덕군';
            break;
        case '37360':
            returnValue = '청도군';
            break;
        case '37370':
            returnValue = '고령군';
            break;
        case '37380':
            returnValue = '성주군';
            break;
        case '37390':
            returnValue = '칠곡군';
            break;
        case '37400':
            returnValue = '예천군';
            break;
        case '37410':
            returnValue = '봉화군';
            break;
        case '37420':
            returnValue = '울진군';
            break;
        case '37430':
            returnValue = '울릉군';
            break;
        case '38':
            returnValue = '경상남도';
            break;
        case '38110':
            returnValue = '창원시';
            break;
        case '38030':
            returnValue = '진주시';
            break;
        case '38050':
            returnValue = '통영시';
            break;
        case '38060':
            returnValue = '사천시';
            break;
        case '38070':
            returnValue = '김해시';
            break;
        case '38080':
            returnValue = '밀양시';
            break;
        case '38090':
            returnValue = '거제시';
            break;
        case '38100':
            returnValue = '양산시';
            break;
        case '38310':
            returnValue = '의령군';
            break;
        case '38320':
            returnValue = '함안군';
            break;
        case '38330':
            returnValue = '창녕군';
            break;
        case '38340':
            returnValue = '고성군';
            break;
        case '38350':
            returnValue = '남해군';
            break;
        case '38360':
            returnValue = '하동군';
            break;
        case '38370':
            returnValue = '산청군';
            break;
        case '38380':
            returnValue = '함양군';
            break;
        case '38390':
            returnValue = '거창군';
            break;
        case '38400':
            returnValue = '합천군';
            break;
        case '39':
            returnValue = '제주특별자치도';
            break;
        case '39010':
            returnValue = '제주시';
            break;
        case '39020':
            returnValue = '서귀포시';
            break;
        default:
            break;
    }

    return returnValue;
};