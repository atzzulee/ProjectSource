﻿// 쿠키값 가져오기
function getCookie(key) {
    var cook = document.cookie + ";";
    var idx = cook.indexOf(key, 0);
    var val = "";

    if (idx != -1) {
        cook = cook.substring(idx, cook.length);
        begin = cook.indexOf("=", 0) + 1;
        end = cook.indexOf(";", begin);
        val = unescape(cook.substring(begin, end));
    }

    return val;
}

// 쿠키값 설정
function setCookie(name, value, expiredays) {
    var today = new Date();
    today.setDate(today.getDate() + expiredays);
    document.cookie = name + "=" + escape(value) + "; path=/; expires=" + today.toGMTString() + ";";
}

function keyPressOnlyNumber() {
    if (event.keyCode < 48 || event.keyCode > 57) {
        event.returnValue = false;

        return false;
    }
    return true;
}

function openPopupFocus(popup_url, name, width, height, showScrollBar) {
    var left = (screen.width - Number(width)) / 2;
    var top = (screen.height - Number(height)) / 2;

    showScrollBar = showScrollBar == undefined || showScrollBar == null ? "no" : "yes";
    
    var obj = window.open(popup_url, name, "width=" + width + "px, height=" + height + "px, left=" + left + ", top=" + top + ", scrollbars=" + showScrollBar + ", menubar=no, resizable=no, titlebar=no, toolbar=no");

    // 팝업에 Focus 주기
    if (obj != null) {
        obj.focus();
    }
}

function valueCheck(arr) {
    for (var i = 0; i < arr.length - 1; i++) {
        for (var j = i + 1; j < arr.length; j++) {
            if (arr[i] == arr[j]) {
                return false;
            }
        }
    }
    
    return true;
}
	
function replaceAll(str, searchStr, replaceStr) {
    return str.split(searchStr).join(replaceStr);
}