var express = require('express'),
    authHelper = require('../common/authHelper'),
    common = require('../common/common'),
    router = express.Router();

router.get('/', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

router.get('/list', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

router.get('/list/:page', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

router.get('/list/:page/:pagesize', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

function list(req, res, next) {
    var page = 1;
    var pagesize = 15;

    if (req.params.page != null)
        page = req.params.page;

    if (req.params.pagesize != null)
        pagesize = req.params.pagesize;
        
    var promise = common.getRequest('/reviews/list/' + page + '/' + pagesize);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 조회 성공.');

            var data = {
                'title': 'Reviews 관리',
                'list': obj.list,
                'search': { 'expertsn': '', 'username': '' },
                'url': '/reviews/list/{{number}}/' + pagesize,
                'page': page,
                'pagesize': pagesize,
                'totalcount': obj.totalcount
            };
            res.render('reviews/list', data);
        }
        else {
            console.log('AdminAPI 조회 실패. ' + obj.message);
            common.registScript(res, '리스트 조회 실패했습니다. ' + obj.message);
		}
    }, function (err) {
        console.log('AdminAPI 조회 에러. ' + err.message);
        common.registScript(res, '리스트 조회 실패했습니다. ' + err.message);
    });
}

router.get('/search', [authHelper.requireAuthentication], function (req, res, next) {
    search(req, res, next);
});

router.get('/search/:page', [authHelper.requireAuthentication], function (req, res, next) {
    search(req, res, next);
});

router.get('/search/:page/:pagesize', [authHelper.requireAuthentication], function (req, res, next) {
    search(req, res, next);
});

function search(req, res, next) {
    var page = 1;
    var pagesize = 15;
    var expertsn = '';
    var username = '';

    if (req.params.page != null)
        page = req.params.page;

    if (req.params.pagesize != null)
        pagesize = req.params.pagesize;
    
    if (req.query.expertsn != null)
        expertsn = req.query.expertsn;

    if (req.query.username != null)
        username = req.query.username;

    var promise = common.getRequest('/reviews/search/' + page + '/' + pagesize + '/?expertsn=' + encodeURI(expertsn) + '&username=' + encodeURI(username));
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 조회 성공.');

            var data = {
                'title': 'Reviews 검색',
                'list': obj.list,
                'search': { 'expertsn': expertsn, 'username': username },
                'url': '/reviews/search/{{number}}/' + pagesize +  '/?expertsn=' + encodeURI(expertsn) + '&username=' + encodeURI(username),
                'page': page,
                'pagesize': pagesize,
                'totalcount': obj.totalcount
            };
            res.render('reviews/list', data);
        }
        else {
            console.log('AdminAPI 조회 실패. ' + obj.message);
            common.registScript(res, '리스트 조회 실패했습니다. ' + obj.message);
		}
    }, function (err) {
        console.log('AdminAPI 조회 에러. ' + err.message);
        common.registScript(res, '리스트 조회 실패했습니다. ' + err.message);
    });
}

router.post('/delete', [authHelper.requireAuthentication], function (req, res, next) {
    var data = { 'marketsn': req.body.marketsn };
    
    var promise = common.getRequest('/reviews/delete', 'POST', data);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 처리 성공.');
        }
        else {
            console.log('AdminAPI 처리 실패. ' + obj.message);
		}
        res.json(obj);
    }, function (err) {
        console.log('AdminAPI 처리 에러. ' + err.message);
        next(err);
    });
});

module.exports = router;