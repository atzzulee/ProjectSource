﻿var express = require('express'),
    multer = require('multer'),
    upload = multer({
        dest: './public/images'
    }),
    authHelper = require('../common/authHelper'),
    common = require('../common/common'),
    router = express.Router();

router.get('/', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

router.get('/list', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

router.get('/list/:page', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

router.get('/list/:page/:pagesize', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

function list(req, res, next) {
    var page = 1;
    var pagesize = 15;

    if (req.params.page != null)
        page = req.params.page;

    if (req.params.pagesize != null)
        pagesize = req.params.pagesize;
        
    var promise = common.getRequest('/experts/list/' + page + '/' + pagesize);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 조회 성공.');
            
            var data = {
                'title': 'Experts 관리',
                'list': obj.list,
                'search': { 'expertname': '' },
                'url': '/experts/list/{{number}}/' + pagesize,
                'page': page,
                'pagesize': pagesize,
                'totalcount': obj.totalcount
            };
            res.render('experts/list', data);
        }
        else {
            console.log('AdminAPI 조회 실패. ' + obj.message);
            common.registScript(res, '리스트 조회 실패했습니다. ' + obj.message);
		}
    }, function (err) {
        console.log('AdminAPI 조회 에러. ' + err.message);
        common.registScript(res, '리스트 조회 실패했습니다. ' + err.message);
    });
}

router.get('/search', [authHelper.requireAuthentication], function (req, res, next) {
    search(req, res, next);
});

router.get('/search/:page', [authHelper.requireAuthentication], function (req, res, next) {
    search(req, res, next);
});

router.get('/search/:page/:pagesize', [authHelper.requireAuthentication], function (req, res, next) {
    search(req, res, next);
});

function search(req, res, next) {
    var page = 1;
    var pagesize = 15;
    var expertname = '';

    if (req.params.page != null)
        page = req.params.page;

    if (req.params.pagesize != null)
        pagesize = req.params.pagesize;
    
    if (req.query.expertname != null)
        expertname = req.query.expertname;
    
    var promise = common.getRequest('/experts/search/' + page + '/' + pagesize + '/?expertname=' + encodeURI(expertname));
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 조회 성공.');
            
            var data = {
                'title': 'Experts 검색',
                'list': obj.list,
                'search': { 'expertname': expertname },
                'url': '/experts/search/{{number}}/' + pagesize + '?/expertname=' + encodeURI(expertname),
                'page': page,
                'pagesize': pagesize,
                'totalcount': obj.totalcount
            };
            res.render('experts/list', data);
        }
        else {
            console.log('AdminAPI 조회 실패. ' + obj.message);
            common.registScript(res, '리스트 조회 실패했습니다. ' + obj.message);
		}
    }, function (err) {
        console.log('AdminAPI 조회 에러. ' + err.message);
        common.registScript(res, '리스트 조회 실패했습니다. ' + err.message);
    });
}

router.get('/view/:expertsn', [authHelper.requireAuthentication], function (req, res, next) {
    var expertsn = null;

    if (req.params.expertsn != null)
        expertsn = req.params.expertsn;
        
    var promise = common.getRequest('/experts/info/' + expertsn, 'GET');
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 조회 성공.');
            
            var data = {
                'title': 'Experts 수정',
                'item': obj.item,
                'codelist': obj.codelist,
                'regionlist': obj.regionlist
            };
            res.render('experts/view', data);
        }
        else {
            console.log('AdminAPI 조회 실패. ' + obj.message);
            common.registScript(res, '상세 조회 실패했습니다. ' + obj.message);
		}
    }, function (err) {
        console.log('AdminAPI 조회 에러. ' + err.message);
        common.registScript(res, '상세 조회 실패했습니다. ' + err.message);
    });
});

var cpUpload = upload.fields([{ 'name': 'photo', 'maxCount': 1 }, { 'name': 'diploma', 'maxCount': 1 }, { 'name': 'certificate', 'maxCount': 1 }]);
router.post('/update', [authHelper.requireAuthentication], cpUpload, function (req, res, next) {
    var data = {
        'expertsn': req.body.expertsn, 'photo': '', 'diploma': '', 'certificate': '', 'mainintroduce': req.body.mainintroduce,
        'detailintroduce': req.body.detailintroduce, 'officename': req.body.officename, 'homepage': req.body.homepage,
        'tel': req.body.tel, 'address': req.body.address, 'latitude': req.body.latitude , 'longitude': req.body.longitude, 'regiontype': req.body.regiontype, 'regionsubtype': req.body.regionsubtype,
        'license': req.body.license, 'academic': '', 'sex': req.body.sex, 'belongto': req.body.belongto, 'record': '',
        'career': req.body.career, 'age': req.body.age, 'categorys': '', 'useyn': req.body.useyn
    };
    
    if (req.files['photo'] != undefined) {
        data.photo = common.getNewFileName(req.files['photo'][0]);
    }
    else {
        delete data['photo'];
    }
    
    if (req.files['diploma'] != undefined) {
        data.diploma = common.getNewFileName(req.files['diploma'][0]);
    }
    else {
        delete data['diploma'];
    }
    
    if (req.files['certificate'] != undefined) {
        data.certificate = common.getNewFileName(req.files['certificate'][0]);
    }
    else {
        delete data['certificate'];
    }

    for (var i = 1; i < req.body.academic_start.length; i++) {
        data.academic += ',{ "start": ' + req.body.academic_start[i] + ', "end": ' + req.body.academic_end[i] + ', "name": "' + req.body.academic_name[i] + '" }';
    }
    
    for (var i = 1; i < req.body.record_start.length; i++) {
        data.record += ',{ "start": ' + req.body.record_start[i] + ', "end": ' + req.body.record_end[i] + ', "name": "' + req.body.record_name[i] + '" }';
    }
    
    for (var i = 1; i < req.body.markettype.length; i++) {
        data.categorys += ',{ "markettype": "' + req.body.markettype[i] + '", "marketsubtype": "' + req.body.marketsubtype[i] + '" }';
    }
    
    var promise = common.getRequest('/experts/update', 'POST', data);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 처리 성공.');
            common.registScript(res, '저장 완료했습니다.', '/experts/view/' + req.body.expertsn);
        }
        else {
            console.log('AdminAPI 처리 실패. ' + obj.message);
            common.registScript(res, '저장 실패했습니다. ' + obj.message);
		}
    }, function (err) {
        console.log('AdminAPI 처리 에러. ' + err.message);
        common.registScript(res, '저장 실패했습니다. ' + err.message);
    });
});

router.post('/update/mileage', [authHelper.requireAuthentication], function (req, res, next) {
    var data = {
        'expertsn': req.body.expertsn, 'mileagetype': req.body.mileagetype, 'mileage': req.body.mileage
    };
    
    var promise = common.getRequest('/experts/update/mileage', 'POST', data);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 처리 성공.');
        }
        else {
            console.log('AdminAPI 처리 실패. ' + obj.message);
		}
        res.json(obj);
    }, function (err) {
        console.log('AdminAPI 처리 에러. ' + err.message);
        next(err);
    });
});

router.post('/delete', [authHelper.requireAuthentication], function (req, res, next) {
    var data = {
        'expertsn': req.body.expertsn,
        'usersn': req.body.usersn
    }
    
    var promise = common.getRequest('/experts/delete', 'POST', data);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 처리 성공.');
        }
        else {
            console.log('AdminAPI 처리 실패. ' + obj.message);
		}
        res.json(obj);
    }, function (err) {
        console.log('AdminAPI 처리 에러. ' + err.message);
        next(err);
    });
});


router.post('/resort', [authHelper.requireAuthentication], function (req, res, next) {
    var promise = common.getRequest('/experts/resort', 'POST');
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 처리 성공.');
        }
        else {
            console.log('AdminAPI 처리 실패. ' + obj.message);
		}
        res.json(obj);
    }, function (err) {
        console.log('AdminAPI 처리 에러. ' + err.message);
        next(err);
    });
});

module.exports = router;