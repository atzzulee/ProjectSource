﻿var express = require('express'),
    authHelper = require('../common/authHelper'),
    common = require('../common/common'),
    router = express.Router();

router.get('/', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

router.get('/list', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

router.get('/list/:page', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

router.get('/list/:page/:pagesize', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

function list(req, res, next) {
    var page = 1;
    var pagesize = 15;

    if (req.params.page != null)
        page = req.params.page;

    if (req.params.pagesize != null)
        pagesize = req.params.pagesize;
        
    var promise = common.getRequest('/markets/list/' + page + '/' + pagesize);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 조회 성공.');

            var data = {
                'title': 'Markets 관리',
                'list': obj.list,
                'search': { 'username': '' },
                'url': '/markets/list/{{number}}/' + pagesize,
                'page': page,
                'pagesize': pagesize,
                'totalcount': obj.totalcount
            };
            res.render('markets/list', data);
        }
        else {
            console.log('AdminAPI 조회 실패. ' + obj.message);
            common.registScript(res, '리스트 조회 실패했습니다. ' + obj.message);
		}
    }, function (err) {
        console.log('AdminAPI 조회 에러. ' + err.message);
        common.registScript(res, '리스트 조회 실패했습니다. ' + err.message);
    });
}

router.get('/search', [authHelper.requireAuthentication], function (req, res, next) {
    search(req, res, next);
});

router.get('/search/:page', [authHelper.requireAuthentication], function (req, res, next) {
    search(req, res, next);
});

router.get('/search/:page/:pagesize', [authHelper.requireAuthentication], function (req, res, next) {
    search(req, res, next);
});

function search(req, res, next) {
    var page = 1;
    var pagesize = 15;
    var username = '';

    if (req.params.page != null)
        page = req.params.page;

    if (req.params.pagesize != null)
        pagesize = req.params.pagesize;
    
    if (req.query.username != null)
        username = req.query.username;

    var promise = common.getRequest('/markets/search/' + page + '/' + pagesize + '/?username=' + encodeURI(username));
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 조회 성공.');
            
            var data = {
                'title': 'Markets 검색',
                'list': obj.list,
                'search': { 'username': username },
                'url': '/markets/search/{{number}}/' + pagesize + '?/username=' + encodeURI(username),
                'page': page,
                'pagesize': pagesize,
                'totalcount': obj.totalcount
            };
            res.render('markets/list', data);
        }
        else {
            console.log('AdminAPI 조회 실패. ' + obj.message);
            common.registScript(res, '리스트 조회 실패했습니다. ' + obj.message);
		}
    }, function (err) {
        console.log('AdminAPI 조회 에러. ' + err.message);
        common.registScript(res, '리스트 조회 실패했습니다. ' + err.message);
    });
}

router.get('/view/:marketsn', [authHelper.requireAuthentication], function (req, res, next) {
    var marketsn = null;

    if (req.params.marketsn != null)
        marketsn = req.params.marketsn;
            
    var promise = common.getRequest('/markets/info/' + marketsn, 'GET');
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 조회 성공.');
            
            var data = {
                'title': 'Markets 수정',
                'item': obj.item,
                'codelist': obj.codelist,
                'regionlist': obj.regionlist
            };
            res.render('markets/view', data);
        }
        else {
            console.log('AdminAPI 조회 실패. ' + obj.message);
            common.registScript(res, '상세 조회 실패했습니다. ' + obj.message);
		}
    }, function (err) {
        console.log('AdminAPI 조회 에러. ' + err.message);
        common.registScript(res, '상세 조회 실패했습니다. ' + err.message);
    });
});

router.post('/update', [authHelper.requireAuthentication], function (req, res, next) {
    var data = {
        'marketsn': req.body.marketsn, 'phone': req.body.phone, 'markettype': req.body.markettype, 'marketsubtype': req.body.marketsubtype, 'regiontype': req.body.regiontype, 'regionsubtype': req.body.regionsubtype,
        'markettype1_1': req.body.markettype1_1, 'markettype1_2': req.body.markettype1_2, 'markettype1_3': req.body.markettype1_3, 'markettype1_4': req.body.markettype1_4,
        'markettype2_1': req.body.markettype2_1, 'markettype2_2': req.body.markettype2_2, 'content': req.body.content, 'status': req.body.status, 'enddate': req.body.enddate, 'useyn': req.body.useyn
    };
    
    var promise = common.getRequest('/markets/update', 'POST', data);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 처리 성공.');
        }
        else {
            console.log('AdminAPI 처리 실패. ' + obj.message);
		}
        res.json(obj);
    }, function (err) {
        console.log('AdminAPI 처리 에러. ' + err.message);
        next(err);
    });
});

router.post('/delete', [authHelper.requireAuthentication], function (req, res, next) {
    var data = { 'marketsn': req.body.marketsn }
    
    var promise = common.getRequest('/markets/delete', 'POST', data);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 처리 성공.');
        }
        else {
            console.log('AdminAPI 처리 실패. ' + obj.message);
		}
        res.json(obj);
    }, function (err) {
        console.log('AdminAPI 처리 에러. ' + err.message);
        next(err);
    });
});

router.post('/bids/delete', [authHelper.requireAuthentication], function (req, res, next) {
    var data = { 'marketsn': req.body.marketsn, '_id': req.body._id }
    
    var promise = common.getRequest('/markets/bids/delete', 'POST', data);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 처리 성공.');
        }
        else {
            console.log('AdminAPI 처리 실패. ' + obj.message);
		}
        res.json(obj);
    }, function (err) {
        console.log('AdminAPI 처리 에러. ' + err.message);
        next(err);
    });
});

router.get('/finishlist', [authHelper.requireAuthentication], function (req, res, next) {
    finishlist(req, res, next);
});

router.get('/finishlist/:page', [authHelper.requireAuthentication], function (req, res, next) {
    finishlist(req, res, next);
});

router.get('/finishlist/:page/:pagesize', [authHelper.requireAuthentication], function (req, res, next) {
    finishlist(req, res, next);
});

function finishlist(req, res, next) {
    var page = 1;
    var pagesize = 15;

    if (req.params.page != null)
        page = req.params.page;

    if (req.params.pagesize != null)
        pagesize = req.params.pagesize;
        
    var promise = common.getRequest('/markets/finishlist/' + page + '/' + pagesize);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 조회 성공.');
            
            var data = {
                'title': 'Markets 완료',
                'list': obj.list,
                'search': { 'expertsn': '' },
                'url': '/markets/finishlist/{{number}}/' + pagesize,
                'page': page,
                'pagesize': pagesize,
                'totalcount': obj.totalcount
            };
            res.render('markets/finishlist', data);
        }
        else {
            console.log('AdminAPI 조회 실패. ' + obj.message);
            common.registScript(res, '리스트 조회 실패했습니다. ' + obj.message);
		}
    }, function (err) {
        console.log('AdminAPI 조회 에러. ' + err.message);
        common.registScript(res, '리스트 조회 실패했습니다. ' + err.message);
    });
}

router.get('/finishsearch', [authHelper.requireAuthentication], function (req, res, next) {
    finishsearch(req, res, next);
});

router.get('/finishsearch/:page', [authHelper.requireAuthentication], function (req, res, next) {
    finishsearch(req, res, next);
});

router.get('/finishsearch/:page/:pagesize', [authHelper.requireAuthentication], function (req, res, next) {
    finishsearch(req, res, next);
});

function finishsearch(req, res, next) {
    var page = 1;
    var pagesize = 15;
    var expertsn = '';

    if (req.params.page != null)
        page = req.params.page;

    if (req.params.pagesize != null)
        pagesize = req.params.pagesize;

    if (req.query.expertsn != null)
        expertsn = req.query.expertsn;
        
    var promise = common.getRequest('/markets/finishsearch/' + page + '/' + pagesize + '/?expertsn=' + encodeURI(expertsn));
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 조회 성공.');
            
            var data = {
                'title': 'Markets 완료',
                'list': obj.list,
                'search': { 'expertsn': expertsn },
                'url': '/markets/finishlist/{{number}}/' + pagesize + '?/expertsn=' + encodeURI(expertsn),
                'page': page,
                'pagesize': pagesize,
                'totalcount': obj.totalcount
            };
            res.render('markets/finishlist', data);
        }
        else {
            console.log('AdminAPI 조회 실패. ' + obj.message);
            common.registScript(res, '리스트 조회 실패했습니다. ' + obj.message);
		}
    }, function (err) {
        console.log('AdminAPI 조회 에러. ' + err.message);
        common.registScript(res, '리스트 조회 실패했습니다. ' + err.message);
    });
}

module.exports = router;