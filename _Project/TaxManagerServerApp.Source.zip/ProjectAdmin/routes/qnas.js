﻿var express = require('express'),
    authHelper = require('../common/authHelper'),
    common = require('../common/common'),
    router = express.Router();

router.get('/', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

router.get('/list', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

router.get('/list/:page', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

router.get('/list/:page/:pagesize', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

function list(req, res, next) {
    var page = 1;
    var pagesize = 15;

    if (req.params.page != null)
        page = req.params.page;

    if (req.params.pagesize != null)
        pagesize = req.params.pagesize;
        
    var promise = common.getRequest('/qnas/list/' + page + '/' + pagesize);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 조회 성공.');

            var data = {
                'title': 'QNAs 관리',
                'list': obj.list,
                'search': '',
                'url': '/qnas/list/{{number}}/' + pagesize,
                'page': page,
                'pagesize': pagesize,
                'totalcount': obj.totalcount
            };
            
            res.render('qnas/list', data);
        }
        else {
            console.log('AdminAPI 조회 실패. ' + obj.message);
            common.registScript(res, '리스트 조회 실패했습니다. ' + obj.message);
		}
    }, function (err) {
        console.log('AdminAPI 조회 에러. ' + err.message);
        common.registScript(res, '리스트 조회 실패했습니다. ' + err.message);
    });
}



router.get('/list', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

router.get('/list/:page', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

router.get('/list/:page/:pagesize', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

function list(req, res, next) {
    var page = 1;
    var pagesize = 15;

    if (req.params.page != null)
        page = req.params.page;

    if (req.params.pagesize != null)
        pagesize = req.params.pagesize;
        
    var promise = common.getRequest('/qnas/list/' + page + '/' + pagesize);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 조회 성공.');

            var data = {
                'title': 'QNAs 관리',
                'list': obj.list,
                'search': '',
                'url': '/qnas/list/{{number}}/' + pagesize,
                'page': page,
                'pagesize': pagesize,
                'totalcount': obj.totalcount
            };
            
            res.render('qnas/list', data);
        }
        else {
            console.log('AdminAPI 조회 실패. ' + obj.message);
            common.registScript(res, '리스트 조회 실패했습니다. ' + obj.message);
		}
    }, function (err) {
        console.log('AdminAPI 조회 에러. ' + err.message);
        common.registScript(res, '리스트 조회 실패했습니다. ' + err.message);
    });
}

router.get('/search', [authHelper.requireAuthentication], function (req, res, next) {
    search(req, res, next);
});

router.get('/search/:page', [authHelper.requireAuthentication], function (req, res, next) {
    search(req, res, next);
});

router.get('/search/:page/:pagesize', [authHelper.requireAuthentication], function (req, res, next) {
    search(req, res, next);
});

function search(req, res, next) {
    var page = 1;
    var pagesize = 15;
    var expertsn = '';
    var username = '';

    if (req.params.page != null)
        page = req.params.page;

    if (req.params.pagesize != null)
        pagesize = req.params.pagesize;
    
    if (req.query.expertsn != null)
        expertsn = req.query.expertsn;

    if (req.query.username != null)
        username = req.query.username;

    var promise = common.getRequest('/qnas/search/' + page + '/' + pagesize + '/?expertsn=' + encodeURI(expertsn) + '&username=' + encodeURI(username));
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 조회 성공.');

            var data = {
                'title': 'QNAs 검색',
                'list': obj.list,
                'search': { 'expertsn': expertsn, 'username': username },
                'url': '/qnas/search/{{number}}/' + pagesize +  '/?expertsn=' + encodeURI(expertsn) + '&username=' + encodeURI(username),
                'page': page,
                'pagesize': pagesize,
                'totalcount': obj.totalcount
            };
            res.render('qnas/list', data);
        }
        else {
            console.log('AdminAPI 조회 실패. ' + obj.message);
            common.registScript(res, '리스트 조회 실패했습니다. ' + obj.message);
		}
    }, function (err) {
        console.log('AdminAPI 조회 에러. ' + err.message);
        common.registScript(res, '리스트 조회 실패했습니다. ' + err.message);
    });
}

router.post('/delete', [authHelper.requireAuthentication], function (req, res, next) {
    var data = { 'qnasn': req.body.qnasn };
    
    var promise = common.getRequest('/qnas/delete', 'POST', data);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 처리 성공.');
        }
        else {
            console.log('AdminAPI 처리 실패. ' + obj.message);
		}
        res.json(obj);
    }, function (err) {
        console.log('AdminAPI 처리 에러. ' + err.message);
        next(err);
    });
});

// router.post('/comments/insert', [authHelper.requireAuthentication], function (req, res, next) {
//     var data = { 'qnasn': req.body.qnasn, 'expertname': req.session.username, 'content': req.body.content };
    
//     var promise = common.getRequest('/qnas/comments/insert', 'POST', data);
//     promise.then( function (result) {
//         var obj = JSON.parse(result);
//         if (obj.result == 0) {
//             console.log('AdminAPI 처리 성공.');
//         }
//         else {
//             console.log('AdminAPI 처리 실패. ' + obj.message);
// 		}
//         res.json(obj);
//     }, function (err) {
//         console.log('AdminAPI 처리 에러. ' + err.message);
//         next(err);
//     });
// });

router.post('/comments/delete', [authHelper.requireAuthentication], function (req, res, next) {
    var data = { 'qnasn': req.body.qnasn, '_id': req.body._id };
    
    var promise = common.getRequest('/qnas/comments/delete', 'POST', data);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 처리 성공.');
        }
        else {
            console.log('AdminAPI 처리 실패. ' + obj.message);
		}
        res.json(obj);
    }, function (err) {
        console.log('AdminAPI 처리 에러. ' + err.message);
        next(err);
    });
});

module.exports = router;