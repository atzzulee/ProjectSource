﻿var express = require('express'),
    authHelper = require('../common/authHelper'),
    common = require('../common/common'),
    router = express.Router();

router.get('/', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

router.get('/list', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

router.get('/list/:page', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

router.get('/list/:page/:pagesize', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

function list(req, res, next) {
    var page = 1;
    var pagesize = 15;

    if (req.params.page != null)
        page = req.params.page;

    if (req.params.pagesize != null)
        pagesize = req.params.pagesize;
        
    var promise = common.getRequest('/users/list/' + page + '/' + pagesize);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 조회 성공.');
            
            var data = {
                'title': 'Users 관리',
                'list': obj.list,
                'search': { 'username': '', 'phone': '', 'email': '' },
                'url': '/users/list/{{number}}/' + pagesize,
                'page': page,
                'pagesize': pagesize,
                'totalcount': obj.totalcount
            };
            res.render('users/list', data);
        }
        else {
            console.log('AdminAPI 조회 실패. ' + obj.message);
            common.registScript(res, '리스트 조회 실패했습니다. ' + obj.message);
		}
    }, function (err) {
        console.log('AdminAPI 조회 에러. ' + err.message);
        common.registScript(res, '리스트 조회 실패했습니다. ' + err.message);
    });
}

router.get('/search', [authHelper.requireAuthentication], function (req, res, next) {
    search(req, res, next);
});

router.get('/search/:page', [authHelper.requireAuthentication], function (req, res, next) {
    search(req, res, next);
});

router.get('/search/:page/:pagesize', [authHelper.requireAuthentication], function (req, res, next) {
    search(req, res, next);
});

function search(req, res, next) {
    var page = 1;
    var pagesize = 15;
    var username = '';
    var phone = '';
    var email = '';

    if (req.params.page != null)
        page = req.params.page;

    if (req.params.pagesize != null)
        pagesize = req.params.pagesize;
    
    if (req.query.username != null)
        username = req.query.username;
    
    if (req.query.phone != null)
        phone = req.query.phone;
    
    if (req.query.email != null)
        email = req.query.email;
    
    var promise = common.getRequest('/users/search/' + page + '/' + pagesize + '/?username=' + encodeURI(username) + '&phone=' + encodeURI(phone) + '&email=' + encodeURI(email));
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 조회 성공.');
            
            var data = {
                'title': 'Users 검색',
                'list': obj.list,
                'search': { 'username': username, 'phone': phone, 'email': email },
                'url': '/users/search/{{number}}/' + pagesize + '?/username=' + encodeURI(username) + '&phone=' + encodeURI(phone) + '&email=' + encodeURI(email),
                'page': page,
                'pagesize': pagesize,
                'totalcount': obj.totalcount
            };
            res.render('users/list', data);
        }
        else {
            console.log('AdminAPI 조회 실패. ' + obj.message);
            common.registScript(res, '리스트 조회 실패했습니다. ' + obj.message);
		}
    }, function (err) {
        console.log('AdminAPI 조회 에러. ' + err.message);
        common.registScript(res, '리스트 조회 실패했습니다. ' + err.message);
    });
}

router.get('/write', [authHelper.requireAuthentication], function (req, res, next) {
    var data = {
        'title': 'Users 등록',
        'item': {
            'usersn': 0, 'username': '', 'email': '', 'phone': '', 'pushkey': '', 'pushyn': '',
            'warning': 0, 'usertype1': '', 'usertype2': '', 'roles': '', 'status': '', 'regdate': '', 'useyn': ''
        }
    };
    res.render('users/view', data);
});

router.get('/view/:usersn', [authHelper.requireAuthentication], function (req, res, next) {
    var usersn = null;

    if (req.params.usersn != null)
        usersn = req.params.usersn;
        
    var promise = common.getRequest('/users/info/' + usersn, 'GET');
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 조회 성공.');
            
            var data = {
                'title': 'Users 수정',
                'item': obj.item
            };
            res.render('users/view', data);
        }
        else {
            console.log('AdminAPI 조회 실패. ' + obj.message);
            common.registScript(res, '상세 조회 실패했습니다. ' + obj.message);
		}
    }, function (err) {
        console.log('AdminAPI 조회 에러. ' + err.message);
        common.registScript(res, '상세 조회 실패했습니다. ' + err.message);
    });
});

router.post('/insert', [authHelper.requireAuthentication], function (req, res, next) {
    var data = {
         'username': req.body.username, 'email': req.body.email, 'password': req.body.password, 'phone': req.body.phone, 'pushkey': req.body.pushkey, 'pushyn': req.body.pushyn,
         'warning': req.body.warning, 'usertype1': req.body.usertype1, 'usertype2': req.body.usertype2, 'roles': req.body.roles, 'status': req.body.status, 'useyn': req.body.useyn
    };
    
    if (req.body.status != '100_001') {
        delete req.body['usertype1'];
        delete req.body['usertype2'];
    }
    
    var promise = common.getRequest('/users/insert', 'POST', data);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 처리 성공.');
        }
        else {
            console.log('AdminAPI 처리 실패. ' + obj.message);
		}
        res.json(obj);
    }, function (err) {
        console.log('AdminAPI 처리 에러. ' + err.message);
        next(err);
    });
});

router.post('/update', [authHelper.requireAuthentication], function (req, res, next) {
    var data = {
         'usersn': req.body.usersn, 'username': req.body.username, 'email': req.body.email, 'password': req.body.password, 'phone': req.body.phone, 'pushkey': req.body.pushkey, 'pushyn': req.body.pushyn,
         'warning': req.body.warning, 'usertype1': req.body.usertype1, 'usertype2': req.body.usertype2, 'roles': req.body.roles, 'status': req.body.status, 'useyn': req.body.useyn
    };
    if (req.body.password == '') {
        delete data['password'];
    }
    
    if (req.body.status != '100_001') {
        delete req.body['usertype1'];
        delete req.body['usertype2'];
    }
    
    var promise = common.getRequest('/users/update', 'POST', data);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 처리 성공.');
        }
        else {
            console.log('AdminAPI 처리 실패. ' + obj.message);
		}
        res.json(obj);
    }, function (err) {
        console.log('AdminAPI 처리 에러. ' + err.message);
        next(err);
    });
});

router.post('/delete', [authHelper.requireAuthentication], function (req, res, next) {
    var data = { 'usersn': req.body.usersn }
    
    var promise = common.getRequest('/users/delete', 'POST', data);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 처리 성공.');
        }
        else {
            console.log('AdminAPI 처리 실패. ' + obj.message);
		}
        res.json(obj);
    }, function (err) {
        console.log('AdminAPI 처리 에러. ' + err.message);
        next(err);
    });
});

module.exports = router;