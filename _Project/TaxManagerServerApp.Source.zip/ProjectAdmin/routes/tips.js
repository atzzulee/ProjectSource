﻿var express = require('express'),
    multer = require('multer'),
    upload = multer({
        dest: './public/images'
    }),
    authHelper = require('../common/authHelper'),
    common = require('../common/common'),
    router = express.Router();

router.get('/', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

router.get('/list', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

router.get('/list/:page', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

router.get('/list/:page/:pagesize', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

function list(req, res, next) {
    var page = 1;
    var pagesize = 15;

    if (req.params.page != null)
        page = req.params.page;

    if (req.params.pagesize != null)
        pagesize = req.params.pagesize;

    var promise = common.getRequest('/tips/list/' + page + '/' + pagesize);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 조회 성공.');

            var data = {
                'title': 'Tips 관리',
                'list': obj.list,
                'page': page,
                'pagesize': pagesize,
                'totalcount': obj.totalcount
            };
            res.render('tips/list', data);
        }
        else {
            console.log('AdminAPI 조회 실패. ' + obj.message);
            common.registScript(res, '리스트 조회 실패했습니다. ' + obj.message);
		}
    }, function (err) {
        console.log('AdminAPI 조회 에러. ' + err.message);
        common.registScript(res, '리스트 조회 실패했습니다. ' + err.message);
    });
};

router.get('/view/:tipsn', [authHelper.requireAuthentication], function (req, res, next) {
    var tipsn = null;

    if (req.params.tipsn != null)
        tipsn = req.params.tipsn;
        
    var promise = common.getRequest('/tips/info/' + tipsn, 'GET');
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 조회 성공.');
            
            var data = {
                'title': 'Tips 수정',
                'item': obj.item
            };
            res.render('tips/view', data);
        }
        else {
            console.log('AdminAPI 조회 실패. ' + obj.message);
            common.registScript(res, '상세 조회 실패했습니다. ' + obj.message);
		}
    }, function (err) {
        console.log('AdminAPI 조회 에러. ' + err.message);
        common.registScript(res, '상세 조회 실패했습니다. ' + err.message);
    });
});

router.get('/write', [authHelper.requireAuthentication], function (req, res, next) {
    var data = {
        'title': 'Tips 등록',
        'item': { 'tipsn': 0, 'title': '', 'linkurl': '', 'attachurl': '', 'regdate': '', 'useyn':'' }
    };
    res.render('tips/view', data);
});

router.post('/insert', [authHelper.requireAuthentication], upload.single('attachurl'), function (req, res, next) {
    var data = { 'title': req.body.title, 'linkurl': req.body.linkurl, 'attachurl': '', 'useyn': req.body.useyn };
    data.attachurl = common.getNewFileName(req.file);
    
    var promise = common.getRequest('/tips/insert', 'POST', data);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 처리 성공.');
            common.registScript(res, '저장 완료했습니다.', '/tips/list');
        }
        else {
            console.log('AdminAPI 처리 실패. ' + obj.message);
            common.registScript(res, '저장 실패했습니다. ' + obj.message);
        }
    }, function (err) {
        console.log('AdminAPI 처리 에러. ' + err.message);
        common.registScript(res, '저장 실패했습니다. ' + err.message);
    });
});

router.post('/update', [authHelper.requireAuthentication], upload.single('attachurl'), function (req, res, next) {
    var data = { 'tipsn': req.body.tipsn, 'title': req.body.title, 'linkurl': req.body.linkurl, 'attachurl': '', 'useyn': req.body.useyn };
    
    if (req.file != undefined) {
        data.attachurl = common.getNewFileName(req.file);
    }
    else {
        delete data['attachurl'];
    }
    
    var promise = common.getRequest('/tips/update', 'POST', data);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 처리 성공.');
            common.registScript(res, '저장 완료했습니다.', '/tips/list');
        }
        else {
            console.log('AdminAPI 처리 실패. ' + obj.message);
            common.registScript(res, '저장 실패했습니다. ' + obj.message);
        }
    }, function (err) {
        console.log('AdminAPI 처리 에러. ' + err.message);
        common.registScript(res, '저장 실패했습니다. ' + err.message);
    });
});

router.post('/delete', [authHelper.requireAuthentication], function (req, res, next) {
    var data = { 'tipsn': req.body.tipsn }
    
    var promise = common.getRequest('/tips/delete', 'POST', data);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 처리 성공.');
        }
        else {
            console.log('AdminAPI 처리 실패. ' + obj.message);
		}
        res.json(obj);
    }, function (err) {
        console.log('AdminAPI 처리 에러. ' + err.message);
        next(err);
    });
});

module.exports = router;