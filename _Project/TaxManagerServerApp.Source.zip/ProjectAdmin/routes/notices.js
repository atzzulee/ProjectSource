﻿var express = require('express'),
    multer = require('multer'),
    upload = multer({
        dest: './public/images'
    }),
    authHelper = require('../common/authHelper'),
    common = require('../common/common'),
    router = express.Router();

router.get('/', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

router.get('/list', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

router.get('/list/:page', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

router.get('/list/:page/:pagesize', [authHelper.requireAuthentication], function (req, res, next) {
    list(req, res, next);
});

function list(req, res, next) {
    var page = 1;
    var pagesize = 15;

    if (req.params.page != null)
        page = req.params.page;

    if (req.params.pagesize != null)
        pagesize = req.params.pagesize;

    var promise = common.getRequest('/notices/list/' + page + '/' + pagesize);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 조회 성공.');

            var data = {
                'title': 'Notices 관리',
                'list': obj.list,
                'page': page,
                'pagesize': pagesize,
                'totalcount': obj.totalcount
            };
            res.render('notices/list', data);
        }
        else {
            console.log('AdminAPI 조회 실패. ' + obj.message);
            common.registScript(res, '리스트 조회 실패했습니다. ' + obj.message);
		}
    }, function (err) {
        common.registScript(res, '리스트 조회 실패했습니다. ' + err.message);
    });
};

router.get('/view/:noticesn', [authHelper.requireAuthentication], function (req, res, next) {
    var noticesn = null;

    if (req.params.noticesn != null)
        noticesn = req.params.noticesn;
        
    var promise = common.getRequest('/notices/info/' + noticesn, 'GET');
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 조회 성공.');
            
            var data = {
                'title': 'Notices 수정',
                'item': obj.item
            };
            res.render('notices/view', data);
        }
        else {
            console.log('AdminAPI 조회 실패. ' + obj.message);
            common.registScript(res, '상세 조회 실패했습니다. ' + obj.message);
		}
    }, function (err) {
        console.log('AdminAPI 조회 에러. ' + err.message);
        common.registScript(res, '상세 조회 실패했습니다. ' + err.message);
    });
});

router.get('/write', [authHelper.requireAuthentication], function (req, res, next) {
    var data = {
        'title': 'Notices 등록',
        'item': { 'noticesn': 0, 'title': '', 'content': '', 'attachurl': '', 'detailattachurl': '', 'status': '', 'regdate': '', 'useyn':'' }
    };
    res.render('notices/view', data);
});

var cpUpload = upload.fields([{ 'name': 'attachurl', 'maxCount': 1 }, { 'name': 'detailattachurl', 'maxCount': 1 }]);
router.post('/insert', [authHelper.requireAuthentication], cpUpload, function (req, res, next) {
    var data = { 'title': req.body.title, 'content': req.body.content, 'attachurl':'', 'detailattachurl': '', 'status': req.body.status, 'useyn': req.body.useyn };
    
    if (req.body.status == '112_002') {
        if (req.files['attachurl'] != undefined) {
            data.attachurl = common.getNewFileName(req.files['attachurl'][0]);
        }
        else {
            delete data['attachurl'];
        }
        
        if (req.files['detailattachurl'] != undefined) {
            data.detailattachurl = common.getNewFileName(req.files['detailattachurl'][0]);
        }
        else {
            delete data['detailattachurl'];
        }
    }
    
    var promise = common.getRequest('/notices/insert', 'POST', data);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 처리 성공.');
            common.registScript(res, '저장 완료했습니다.', '/notices/list');
        }
        else {
            console.log('AdminAPI 처리 실패. ' + obj.message);
            common.registScript(res, '저장 실패했습니다. ' + obj.message);
		}
    }, function (err) {
        console.log('AdminAPI 처리 에러. ' + err.message);
        common.registScript(res, '저장 실패했습니다. ' + err.message);
    });
});

router.post('/update', [authHelper.requireAuthentication], cpUpload, function (req, res, next) {
    var data = { 'noticesn': req.body.noticesn, 'title': req.body.title, 'content': req.body.content, 'attachurl': '', 'detailattachurl': '', 'status': req.body.status, 'useyn': req.body.useyn };
    
    if (req.body.status == '112_002') {
        if (req.files['attachurl'] != undefined && req.files['detailattachurl'] != undefined) {
            data.attachurl = common.getNewFileName(req.files['attachurl'][0]);
            data.detailattachurl = common.getNewFileName(req.files['detailattachurl'][0]);
        }
        else if (req.files['attachurl'] != undefined) {
            delete data['detailattachurl'];
            data.attachurl = common.getNewFileName(req.files['attachurl'][0]);
        }
        else if (req.files['detailattachurl'] != undefined) {
            delete data['attachurl'];
            data.detailattachurl = common.getNewFileName(req.files['detailattachurl'][0]);
        }
        else {
            delete data['attachurl'];
            delete data['detailattachurl'];
        }
    }
    
    var promise = common.getRequest('/notices/update', 'POST', data);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 처리 성공.');
            common.registScript(res, '저장 완료했습니다.', '/notices/view/' + req.body.noticesn);
        }
        else {
            console.log('AdminAPI 처리 실패. ' + obj.message);
            common.registScript(res, '저장 실패했습니다. ' + obj.message);
		}
    }, function (err) {
        console.log('AdminAPI 처리 에러. ' + err.message);
        common.registScript(res, '저장 실패했습니다. ' + err.message);
    });
});

router.post('/delete', [authHelper.requireAuthentication], function (req, res, next) {
    var data = { 'noticesn': req.body.noticesn }
    
    var promise = common.getRequest('/notices/delete', 'POST', data);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            console.log('AdminAPI 처리 성공.');
        }
        else {
            console.log('AdminAPI 처리 실패. ' + obj.message);
		}
        res.json(obj);
    }, function (err) {
        console.log('AdminAPI 처리 에러. ' + err.message);
        next(err);
    });
});

module.exports = router;