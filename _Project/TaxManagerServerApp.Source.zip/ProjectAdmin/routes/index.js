var express = require('express'),
    async = require('async');
    fs = require('fs');
    request = require("request"),
    authHelper = require('../common/authHelper'),
    common = require('../common/common'),
	config = require('../config'),
    router = express.Router();

router.get('/', function (req, res, next) {
    if (req.session.isAuthenticated) {
        res.redirect('/main');
        return;
    }
    
    var data = {
        'title': '로그인',
        'message': ''
    };
    
    res.render('index', data);
});

router.get('/login', function (req, res, next) {
    if (req.session.isAuthenticated) {
        res.redirect('/main');
        return;
    }

    var data = {
        'title': '로그인',
        'message': '아이디 혹은 비밀번호가 틀렸습니다.'
    };
    
    res.render('index', data);
});

router.get('/logout', [authHelper.requireAuthentication], function (req, res) {
    authHelper.logOut(req, res);
    res.redirect('/');
});

router.get('/main', [authHelper.requireAuthentication], function (req, res, next) {
    var data = {
        'title': 'Main',
        'item': {
            'usersCount': 0,
            'expertsCount': 0,
            'marketsCount': 0,
            'qnasCount': 0
        },
        'alive': []
    }

    async.series([
        function (cb) {
            request({
                'uri': 'http://' + config.serviceIP + ':' + config.adminAPIServicePort + '/main',
                'headers': { 'Authorization': 'Bearer ' + config.token },
                'method': 'GET',
                'timeout': 1000,
                'followRedirect': true,
                'maxRedirects': 10
            }, function (err, res, result) {
                if (err) {
                    cb(null, null);
                }
                else {
                    if (res.statusCode == 200) {
                        cb(null, result);
                    }
                    else {
                        cb(null, null);
                    }
                }
            });
        },
        function (cb) {
            request({
                'uri': 'http://' + config.serviceIP + ':' + config.apiServicePort + '/',
                'method': 'GET',
                'timeout': 1000,
                'followRedirect': true,
                'maxRedirects': 10
            }, function (err, res, result) {
                if (err) {
                    cb(null, false);
                }
                else {
                    if (res.statusCode == 200) {
                        cb(null, true);
                    }
                    else {
                        cb(null, false);
                    }
                }
            });
        },
        function (cb) {
            request({
                'uri': 'http://' + config.serviceIP + ':' + config.adminAPIServicePort + '/',
                'headers': { 'Authorization': 'Bearer ' + config.token },
                'method': 'GET',
                'timeout': 1000,
                'followRedirect': true,
                'maxRedirects': 10
            }, function (err, res, result) {
                if (err) {
                    cb(null, false);
                }
                else {
                    if (res.statusCode == 200) {
                        cb(null, true);
                    }
                    else {
                        cb(null, false);
                    }
                }
            });
        },
        function (cb) {
            request({
                'uri': 'http://' + config.serviceIP + ':' + config.serviceServicePort + '/',
                'method': 'GET',
                'timeout': 1000,
                'followRedirect': true,
                'maxRedirects': 10
            }, function (err, res, result) {
                if (err) {
                    cb(null, false);
                }
                else {
                    if (res.statusCode == 200) {
                        cb(null, true);
                    }
                    else {
                        cb(null, false);
                    }
                }
            });
        },
        function (cb) {
            request({
                'uri': 'http://' + config.serviceIP + ':' + config.mongoDBServicePort + '/',
                'method': 'GET',
                'timeout': 1000,
                'followRedirect': true,
                'maxRedirects': 10
            }, function (err, res, result) {
                if (err) {
                    cb(null, false);
                }
                else {
                    if (res.statusCode == 200) {
                        cb(null, true);
                    }
                    else {
                        cb(null, false);
                    }
                }
            });
        },
    ], function (err, results) {
        if (results != null) {
            if (results[0] != null) {
                var obj = JSON.parse(results[0]);
                if (obj.result == 0) {
                    data.item = obj.item;
                }
            }

            for (var i = 1; i < results.length; i++) {
                data.alive.push(results[i]);
            }
        }

	    res.render('main', data);
    });
});

router.get('/privacyAgreement', function (req, res, next) {
    var data = {
        'title': '개인정보 취급방침'
    };
    res.render('privacyAgreement', data);
});

router.get('/serviceAgreement', function (req, res, next) {
    var data = {
        'title': '이용약관'
    };
    res.render('serviceAgreement', data);
});

router.post('/loginProcess', function (req, res, next) {
    if (req.session.isAuthenticated) {
        res.redirect('/main');
        return;
    }
    
    var data = { 'email': req.body.email, 'password': req.body.password };
    
    var promise = common.getRequest('/users/checkAdmin', 'POST', data);
    promise.then( function (result) {
        var obj = JSON.parse(result);
        if (obj.result == 0) {
            req.session.isAuthenticated = true;
            req.session.usersn = obj.item.usersn;
            req.session.username = obj.item.username;
		    res.redirect('/main');
        }
        else {
            res.redirect('/login');
        }
    }, function (err) {
        res.redirect('/login');
    });
});

module.exports = router;