var config = {
    name: 'TaxAccountingAdmin',
	serviceIP: 'localhost',
	secret: 'TAM_Admin_Secret',
	redisUrl: 'redis://localhost',
	apiServicePort: 3000,
	adminAPIServicePort: 3001,
    servicePort: 3002,
	serviceServicePort: 3003,
	mongoDBServicePort: 27017,
	token: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoiUHJvamVjdEFkbWluQVBJIiwiaWF0IjoxNDY3MTczMDgyLCJleHAiOjE0OTg3MDkwODJ9.detAgdjq54WM8Y1ZJwodjtT3EoWe5z53vXkj14AHhbI'
};

module.exports = config;