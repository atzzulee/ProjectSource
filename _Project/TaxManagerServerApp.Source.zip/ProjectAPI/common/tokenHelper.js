var expressJwt = require('express-jwt'),
    jwt = require('jsonwebtoken'),
    redisHelper = require("./redisHelper"),
    config = require('../config')

var SECRET = config.token.secret;
var redisKey = 'ExpireTokenList';

function getToken(req) {
    if (req.headers.authorization && req.headers.authorization.split(' ')[0] === 'Bearer') {
        return req.headers.authorization.split(' ')[1];
    } else if (req.query && req.query.token) {
        return req.query.token;
    }
    return null;
}

function getProfile(token) {
    return jwt.verify(token, SECRET);
}

function setToken(profile) {
    return jwt.sign(profile, SECRET, { expiresIn: config.token.timeout });
}

exports.getToken = getToken;
exports.getProfile = getProfile;
exports.setToken = setToken;
exports.authMethod = expressJwt({
    secret: SECRET,
    getToken: getToken
});

exports.isExpireCheck = function (req, res, next) {
    if (req.headers.authorization == undefined) {
        next(new Error('토큰이 존재하지 않습니다.'));
        return;
    }
    else {
        var token = getToken(req);
        var profile = getProfile(token);
        
        if (profile != null) {
            redisHelper.select(redisKey + '|' + profile.usersn, function (result, arr) {
                if (result) {
                    var flag = true;
                    for (var item in arr) {
                        if (token == arr[item]) {
                            flag = false;
                            break;
                        }
                    }
                    
                    if (flag) {
                        next();
                    }
                    else {
                        next(new Error('파기된 토큰입니다.'));
                    }
                }
                else {
                    next();
                }
            });
        }
        else {
            next(new Error('토큰이 존재하지 않습니다.'));
        }
    }
}

exports.expireToken = function (token, callback) {
    var profile = getProfile(token);
    
    redisHelper.add(redisKey + '|' + profile.usersn, token, function (result) {
        if (!result) {
            callback(false);
        }
        else {
            callback(true);
        }
    });
}

exports.refreshToken = function (token, newProfile, callback) {
    var profile = getProfile(token);
    
    redisHelper.add(redisKey + '|' + profile.usersn, token, function (result) {
        if (!result) {
            callback(false, '');
        }
        else {
            if (newProfile != null) {
                profile = newProfile;
            }
            var newToken = setToken(profile);
            callback(true, newToken);
        }
    });
}