// mysqlHelper.js
var mysql = require('mysql');
var pool  = mysql.createPool({
  connectionLimit : 20, // default: 250
  host            : 'localhost',
  user            : 'root',
  password        : '1234',
  database        : 'test'
});

module.exports = pool;