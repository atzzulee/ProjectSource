exports.isNotNullCheck = function (p) {
    if (typeof p == undefined || p == null)
        return false;
    else
        return true;
}

exports.isStringCheck = function (p) {
    if (typeof p == undefined || p == null || p == '')
        return false;
    else
        return true;
}

exports.isNumberCheck = function (p) {
    if (typeof p == undefined || p == null || p == '' || isNaN(p))
        return false;
    else
        return true;
}






