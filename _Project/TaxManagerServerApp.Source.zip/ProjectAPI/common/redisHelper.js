var config = require('../config');

var poolRedis = require('pool-redis')({
  'host': config.redis.host,
  'port': config.redis.port,
  'maxConnections': config.redis.maxConnections
});

exports.add = function add(key, value, cb) {
    poolRedis.getClient( function (client, done) {
        client.rpush(key, value, function (err, result) {
            if (err || !result) {
                poolRedis.release(client);
                cb(false);
            }
            else {
                client.expire(key, config.token.timeout, function (err, result) {
                    if (err || !result) {
                        poolRedis.release(client);
                        cb(false);
                    }
                    else {
                        poolRedis.release(client);
                        cb(true);
                    }
                });
            }
        });
     });
};

exports.remove = function remove(key, value, cb) {
    poolRedis.getClient( function (client, done) {
        client.lrem(key, 0, value, function (err, result) {
            if (err) {
                cb(false);
            }
            else {
                cb(true);
            }
            
            poolRedis.release(client);
       });
    });
};
            
exports.select = function select(key, cb) {
    poolRedis.getClient( function (client, done) {
        client.lrange(key, 0, -1, function (err, result) {
            if (err) {
                cb(false);
            }
            else {
                if (result != null) {
                    cb(true, result);
                }
                else {
                    cb(false);
                }
            }
            
            poolRedis.release(client);
        });
    });
};