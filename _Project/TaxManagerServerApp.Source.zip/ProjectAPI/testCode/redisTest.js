var express = require('express'),
	app = express(),
	bodyParser = require('body-parser');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));

var redis = require("redis");
var port = 6379;
var host = '127.0.0.1'

//routes
app.get('/a', function (req, res) {
    var client = redis.createClient(port, host);
    client.set("a", "hello1", function (err, res) {
        if (err) {
            console.log(err);
        }
        else {
            client.expire("a", 10, function (err, res) {
                if (err) {
                    console.log(err);
                }
                else {
                    console.log(res);
                }
            });
        }
    });
});
app.get('/b', function (req, res) {
    var client = redis.createClient(port, host);
    client.expire("a", 10);
    client.quit();
    
    res.send("ok");
});
app.get('/c', function (req, res) {
    var client = redis.createClient(port, host);
    client.get("a", function (err, res) {
        if(err) {
            console.log(err);
        }
        else {
            console.log(res);
        }
    });
    client.quit();
    
    res.send("ok");
});
app.get('/d', function (req, res) {
    var client = redis.createClient(port, host);
    client.del("a", function (err, res) {
        if(err) {
            console.log(err);
        }
        else {
            console.log(res);
        }
    });
    client.quit();
    
    res.send("ok");
});

app.listen(3000, function () {
    console.log("port 3000");
});
