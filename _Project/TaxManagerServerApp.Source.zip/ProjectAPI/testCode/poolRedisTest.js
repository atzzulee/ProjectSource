var poolRedis = require('pool-redis')({
  'host': 'localhost',
  'port': 6379,
  'maxConnections': 10
});

poolRedis.getClient(function(client, done) {
  client.setex('key', 10, 'a', function(err, value) {
    console.log('value from redis is:', value);
    done();
  });
});
