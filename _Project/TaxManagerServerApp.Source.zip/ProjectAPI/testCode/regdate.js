var date = new Date('2016-01-31 01:00:00');
var date2 = new Date();
console.log(date);
console.log(date2);
console.log(new Date(date.setDate(date.getDate() + 3)));