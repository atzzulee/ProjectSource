var mongoose = require('mongoose'),
    autoIncrement = require('mongoose-auto-increment'),
    db = require('../common/mongooseHelper'),
    loggerHelper = require('../common/loggerHelper'),
	successfulbidSchema = new mongoose.Schema({
        successfulbidsn: Number, // 입찰완료일련번호
        marketsn: Number, // 경매일련번호
        expertsn: Number, // 관리자일련번호
        regdate: String, // 등록일
        useyn: {type: Boolean, default: true} // 사용여부
	});

var model = db.model('Successfulbid', successfulbidSchema);

exports.insert = function (data, callback) {
    autoIncrement.initialize(db);
    successfulbidSchema.plugin(autoIncrement.plugin, { 'model': 'Successfulbid', 'field': 'successfulbidsn', 'startAt': 1, 'incrementBy': 1 });
    data.regdate = new Date().format('yyyy-MM-dd HH:mm:ss');

    model(data).save().then( function (doc) {
        if (doc == null) {
            callback(false);
        } else {
            callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false);
    });
}