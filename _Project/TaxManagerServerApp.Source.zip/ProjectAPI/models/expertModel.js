var mongoose = require('mongoose'),
    autoIncrement = require('mongoose-auto-increment'),
    db = require('../common/mongooseHelper'),
    loggerHelper = require('../common/loggerHelper'),
    expertSchema = new mongoose.Schema({
        expertsn: Number, // 전문가일련번호
        usersn: Number, // 유저일련번호,
        expertname: String, // 이름
        photo: String, // 이미지경로
        diploma: String, // 대학 졸업 증명서
        certificate: String, // 건강보험자격득실확인서
        mainintroduce: String, // 메인소개글
        detailintroduce: String, // 상세소개글
        officename: String, //사무실명
        tel: String, // 전화번호
        address: String, // 번지주소
        latitude: String, // 위도
        longitude: String, // 경도
        regiontype: String, // 지역타입1
        regionsubtype: String, // 지역타입2
        license: String, // 자격증
        academic: [{
            start: Number, // 시작
            end: Number, // 끝
            name: String // 이름
        }], // 학력
        sex: String, // 성별 
        belongto: String, // 소속
        record: [{
            start: Number, // 시작
            end: Number, // 끝
            name: String // 이름
        }], // 이력
        career: Number, //경력
        age: Number, // 나이
        categorys: [{
            markettype: String, // 메인코드
            marketsubtype: String // 서브코드
        }], // 전문분야 카테고리 리스트
        dishs: [], // 찜 리스트,
        mileage: {type: Number, default: 50000}, // 마일리지
        regdate: String, // 등록일
        useyn: {type: Boolean, default: false}, // 사용여부
        email: String // 이메일
    });
    
var model = db.model('Expert', expertSchema);

exports.infoByUser = function (usersn, callback) {
    var where = { 'usersn': usersn, 'useyn': true };
    var field = { 'expertsn': 1, 'expertname': 1 };
    
    // 상세조회 프로세스
    model.findOne(where, field).then( function (doc) {
        if (doc == null) {
		    callback(false, null);
        }
        else {
		    callback(true, doc);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}

exports.insertByUser = function (data, callback) {
    // 등록 프로세스
    autoIncrement.initialize(db);
    expertSchema.plugin(autoIncrement.plugin, { 'model': 'Expert', 'field': 'expertsn', 'startAt': 1, 'incrementBy': 1 });
    data.regdate = new Date().format('yyyy-MM-dd HH:mm:ss');

    model(data).save().then( function (doc) {
        if (doc == null) {
		    callback(false, null);
        }
        else {
		    callback(true, doc);
        }
    }, function (err) {
        loggerHelper.error(err);
		callback(false, null);
    });
}

exports.updateByUser = function (expertsn, data, callback) {
    var where = { 'expertsn': expertsn };
    var set = { '$set': data };
    
    // 수정 프로세스
    model.update(where, set).then( function (dbresult) {
        if (dbresult.nModified == 0) {
		    callback(false);
        }
        else {
		    callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
		callback(false);
    });
}

exports.search = function (last_expertsn, markettype, marketsubtype, regiontype, regionsubtype, pagesize, callback) {
    var where = { 'useyn': true };
    
    if (markettype != '' && marketsubtype != '') {
        where.categorys = { $elemMatch: { 'markettype': markettype, 'marketsubtype': marketsubtype } };
    }
    else if (markettype != '') {
        where.categorys = { $elemMatch: { 'markettype': markettype } };
    }
    else if (marketsubtype != '') {
        where.categorys = { $elemMatch: { 'marketsubtype': marketsubtype } };
    }
    
    if (regiontype != '') {
        where.regiontype = regiontype;
    }
    
    if (regionsubtype != '') {
        where.regionsubtype = regionsubtype;
    }
    
    if (last_expertsn == 0)
        last_expertsn = 999999999;
        
    model.count(where).then( function (totalCount) {
        where.expertsn = { '$lt': last_expertsn };
        var field = { 'expertsn': 1, 'expertname': 1, 'officename': 1, 'career': 1, 'age': 1, 'mainintroduce': 1, 'sex': 1, 'photo': 1 };
        var sort = { 'expertsn': -1 };
        
        // 리스트 조회 프로세스
        model.find(where, field).sort(sort).limit(pagesize).then( function (docs) {
            callback(true, docs, totalCount);
        }, function (err) {
            loggerHelper.error(err);
            callback(false, null, 0);
        });
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null, 0);
    });
}

exports.info = function (expertsn, callback) {
    var where = { 'expertsn': expertsn, 'useyn': true };

    // 상세조회 프로세스
    model.findOne(where).then( function (doc) {
        if (doc == null) {
            callback(false, null);
        }
        else {
            callback(true, doc);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}

exports.dishPush = function (expertsn, marketsn, callback) {
    var where = { 'expertsn': expertsn, 'useyn': true };
    var pushdata = { '$push': { 'dishs': marketsn } };
    
    // 수정 프로세스
    model.update(where, pushdata, { upsert: true }).then( function (dbresult) {
        if (dbresult.nModified == 0) {
            callback(false);
        }
        else {
            callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false);
    });
}

exports.dishPull = function (expertsn, marketsn, callback) {
    var where = { 'expertsn': expertsn, 'useyn': true };
    var pulldata = { '$pull': { 'dishs': marketsn } };
    
    // 수정 프로세스
    model.update(where, pulldata, { upsert: true }).then( function (dbresult) {
        if (dbresult.nModified == 0) {
            callback(false);
        }
        else {
            callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false);
    });
}

exports.update = function (expertsn, data, callback) {
    var where = { 'expertsn': expertsn, 'useyn': true };
    var set = { '$set': data };
    
    // 수정 프로세스
    model.update(where, set).then( function (dbresult) {
        if (dbresult.nModified == 0) {
            callback(false);
        }
        else {
            callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false);
    });
}