var mongoose = require('mongoose'),
    db = require('../common/mongooseHelper'),
    loggerHelper = require('../common/loggerHelper'),
    marketModel = require('./marketModel'),
    reviewSchema = new mongoose.Schema({
        marketsn: Number, // 경매일련번호
        expertsn: Number, // 전문가일련번호
        usersn: Number, // 유저일련번호
        username: String, // 유저명
        score: Number, // 점수
        content: String, // 내용
        regdate: String, // 등록일
        useyn: {type: Boolean, default: true} // 사용여부
    });

var model = db.model('Review', reviewSchema);

exports.list = function (last_marketsn, expertsn, pagesize, callback) {
    var where = { 'useyn': true, 'expertsn': expertsn };
    
    if (last_marketsn == 0)
        last_marketsn = 999999999;
        
    model.count(where).then( function (totalCount) {
        where.marketsn = { '$lt': last_marketsn };
        var field = { 'marketsn': 1, 'expertsn': 1, 'usersn': 1, 'username': 1, 'score': 1, 'content': 1, 'regdate': 1 };
        var sort = { 'marketsn': -1 };
        
        // 리스트 조회 프로세스
        model.find(where, field).sort(sort).limit(pagesize).then( function (docs) {
            callback(true, docs, totalCount);
        }, function (err) {
            loggerHelper.error(err);
            callback(false, null, 0);
        });
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null, 0);
    });
}

exports.info = function (marketsn, callback) {
    var where = { 'marketsn': marketsn };

    // 상세조회 프로세스
    model.findOne(where).then( function (doc) {
        if (doc == null) {
            callback(false, null);
        }
        else {
            callback(true, doc);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}

exports.insert = function (data, callback) {
    data.regdate = new Date().format('yyyy-MM-dd HH:mm:ss');
    model(data).save().then( function (doc) {
        if (doc == null) {
            callback(false, null);
        }
        else {
            callback(true, doc);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}

exports.update = function (marketsn, data, callback) {
    var where = { 'marketsn': marketsn, 'useyn': true  };
    var set = { '$set': data };
    
    // 수정 프로세스
    model.update(where, set).then( function (dbresult) {
        if (dbresult.nModified == 0) {
            callback(false);
        }
        else {
            callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false);
    });
}

exports.delete = function (marketsn, callback) {
    var where = { 'marketsn': marketsn, 'useyn': true  };
    var set = { '$set': { 'useyn': false } };
    
    // 삭제 프로세스
    model.update(where, set).then( function (dbresult) {
        if (dbresult.nModified == 0) {
            callback(false);
        }
        else {
            callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false);
    });
}