var mongoose = require('mongoose'),
    db = require('../common/mongooseHelper'),
    loggerHelper = require('../common/loggerHelper'),
	tipSchema = new mongoose.Schema({
        tipsn: Number, // 팁일련번호
        title: String, // 제목
        linkurl: String, // 링크경로
        attachurl: String, // 이미지경로
        regdate: String, // 등록일
        upddate: String, // 수정일
        useyn: {type: Boolean, default: true} // 사용여부
	});

var model = db.model('Tip', tipSchema);

exports.listByMain = function (callback) {
    var pagesize = 5;
    var where = { 'useyn': true };
    var field = { 'tipsn': 1, 'linkurl': 1, 'attachurl': 1 };
    var sort = { 'upddate': -1 };
    
    // 리스트 조회 프로세스
    model.find(where, field).sort(sort).limit(pagesize).then( function (docs) {
        callback(true, docs);
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}