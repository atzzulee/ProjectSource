var mongoose = require('mongoose'),
    autoIncrement = require('mongoose-auto-increment'),
    db = require('../common/mongooseHelper'),
    loggerHelper = require('../common/loggerHelper'),
    marketSchema = new mongoose.Schema({
        marketsn: Number, // 경매일련번호
        usersn: Number, // 유저일련번호 
        username: String, // 유저명
        phone: String, // 전화번호
        markettype: String, // 경매타입1
        marketsubtype: String, // 경매타입2
        regiontype: String, // 지역타입1
        regionsubtype: String, // 지역타입2
        markettype1_1: String, // 경매타입1의1
        markettype1_2: Number, // 경매타입1의2 (매출규모) 
        markettype1_3: String, // 경매타입1의3 (사업종류)
        markettype1_4: Number, // 경매타입1의4 (종업원수)
        markettype2_1: [], // 경매타입2의1 (재산대상)
        markettype2_2: [], // 경매타입2의2 (재산대상 시가)
        bids: [{ 
            expertsn: Number, // 관리자일련번호
            expertname: String, // 관리자이름
            usersn: Number, // 유저일련번호
            mainintroduce: String, // 메인소개글
            photo: String, // 이미지
            sex: String, // 성별
            comment: String, // 코멘트
            price1: Number, // 기장료
            price2: Number, // 조정료
            regdate: String, // 등록일
            useyn: {type: Boolean, default: true} // 사용여부
        }], // 입찰리스트
        content : String, // 내용
        success_expertsn: Number, // 낙찰전문가일련번호
        status: String, // 경매상태
        regdate: String, // 등록일
        enddate: Number, // 마감일
        useyn: {type: Boolean, default: true}, // 사용여부
        bidscount: Number, // 입찰카운트
        price1: Number, // 가격1
        price2: Number, // 가격2
        reviewyn: Boolean // 리뷰여부
    }),
    bidsSchema = new mongoose.Schema({
        expertsn: Number, // 관리자일련번호
        expertname: String, // 관리자이름
        usersn: Number, // 유저일련번호
        mainintroduce: String, // 메인소개글
        photo: String, // 이미지
        sex: String, // 성별
        comment: String, // 코멘트
        price1: Number, // 기장료
        price2: Number, // 조정료
        regdate: String, // 등록일
        useyn: {type: Boolean, default: true} // 사용여부
    });

var model = db.model('Market', marketSchema);
var bidModel = db.model('Bid', bidsSchema);

exports.bidcount = function (status, callback) {
    var where = { 'status': status, 'useyn': true };
    
    model.count(where).then( function (totalCount) {
        callback(true, totalCount);
    }, function (err) {
        loggerHelper.error(err);
        callback(false, result);
    });
}

exports.mybidcount = function (expertsn, callback) {
    var where = { 'bids.expertsn': expertsn, 'status': '110_002', 'useyn': true };
    
    model.count(where).then( function (totalCount) {
        callback(true, totalCount);
    }, function (err) {
        loggerHelper.error(err);
        callback(false, result);
    });
}

exports.mysuccessbidcount = function (expertsn, callback) {
    var where = { 'bids.expertsn': expertsn, 'status': '110_004', 'useyn': true };
    
    model.count(where).then( function (totalCount) {
        callback(true, totalCount);
    }, function (err) {
        loggerHelper.error(err);
        callback(false, result);
    });
}

exports.mynotsuccessbidcount = function (expertsn, callback) {
    var where = { '$or': [ { 'bids.expertsn': expertsn, 'status': { '$in': ['110_003', '110_005'] }, 'useyn': true }, {'bids.expertsn': expertsn, 'success_expertsn': { '$nin': [expertsn] }, 'status': '110_004', 'useyn': true } ] };
    
    model.count(where).then( function (totalCount) {
        callback(true, totalCount);
    }, function (err) {
        loggerHelper.error(err);
        callback(false, result);
    });
}

//81. 전문가 입찰, 낙찰, 마감 리스트 조회
exports.mylist = function (pagesize, last_marketsn, expertsn, status, callback) {
    var where = null;
    var arrstatus = [];

    if (status != '110_003') {
        where = { 'bids.expertsn': expertsn, 'status': status, 'useyn': true };
    }
    else {
        where = { '$or': [ { 'bids.expertsn': expertsn, 'status': { '$in': ['110_003', '110_005'] }, 'useyn': true }, {'bids.expertsn': expertsn, 'success_expertsn': { '$nin': [expertsn] }, 'status': '110_004', 'useyn': true } ] };
    }

    if (last_marketsn == 0)
        last_marketsn = 999999999;
    
    model.count(where).then( function (totalcount) {
        where.marketsn = { '$lt': last_marketsn };
        
        var field = { 'marketsn': 1, 'usersn': 1, 'username': 1, 'phone': 1, 'markettype': 1, 'marketsubtype': 1, 'markettype1_1': 1, 'markettype1_2': 1, 'markettype1_3': 1, 'markettype1_4': 1, 'markettype2_1': 1, 'markettype2_2': 1, 'bids':1, 'bidscount': 1, 'success_expertsn': 1, 'status': 1, 'regdate': 1, 'enddate': 1, 'price1': 1, 'price2': 1 };
        var sort = { 'marketsn': -1 };
        
        model.find(where, field).sort(sort).limit(pagesize).then( function (docs) {
            callback(true, docs, totalcount);
        }, function (err) {
            loggerHelper.error(err);
            callback(false, null, 0);
        });
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null, 0);
    });
}

//16.견적 리스트
exports.list = function (pagesize, last_marketsn, callback) {
    var where = { 'status': '110_002', 'useyn': true };
    
    if (last_marketsn == 0)
        last_marketsn = 999999999;
    
    model.count(where).then( function (totalcount) {
        where.marketsn = { '$lt': last_marketsn }; 
        var field = { 'marketsn': 1, 'usersn': 1, 'username': 1, 'markettype': 1, 'marketsubtype': 1, 'markettype1_1': 1, 'markettype1_2': 1, 'markettype1_3': 1, 'markettype1_4': 1, 'markettype2_1': 1, 'markettype2_2': 1, 'bids':1, 'status':1, 'regdate':1, 'enddate':1 };
        var sort = { 'marketsn': -1 };
        
        model.find(where, field).sort(sort).limit(pagesize).then( function (docs) {
            callback(true, docs, totalcount);
        }, function (err) {
            loggerHelper.error(err);
            callback(false, null, 0);
        });
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null, 0);
    });
}

//17.개별 견적 정보
exports.info = function (marketsn, callback) {
    var where = { 'marketsn': marketsn, 'useyn': true };
    
    model.findOne(where).then( function (doc) {
        if (doc == null){
            callback(false, null);
        }
        else {
            callback(true, doc);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}

//18.견적 조회
exports.searchlist = function (pagesize, last_marketsn, markettype, marketsubtype, regiontype, regionsubtype, callback) {
    var where = { 'status': '110_002', 'useyn': true };
    
    if (markettype != '' && marketsubtype != '') {
        where.markettype = markettype;
        where.marketsubtype = marketsubtype;
    }
    else if (markettype != '') {
        where.markettype = markettype;
    }
    else if (marketsubtype != '') {
        where.marketsubtype = marketsubtype;
    }
    
    if (regiontype != '') {
        where.regiontype = regiontype;
    }
    
    if (regionsubtype != '') {
        where.regionsubtype = regionsubtype;
    }
    
    if (last_marketsn == 0)
        last_marketsn = 999999999;
    
    model.count(where).then( function (totalcount) {
        where.marketsn = { '$lt': last_marketsn };
        var field = { 'marketsn': 1, 'usersn': 1, 'username': 1, 'markettype': 1, 'marketsubtype': 1, 'markettype1_1': 1, 'markettype1_2': 1, 'markettype1_3': 1, 'markettype1_4': 1, 'markettype2_1': 1, 'markettype2_2': 1, 'bidscount':1, 'status':1, 'regdate':1, 'enddate':1, 'bids': 1 };
        var sort = { 'marketsn': -1 };
        
        model.find(where, field).sort(sort).limit(pagesize).then( function (docs) {
            callback(true, docs, totalcount);
        }, function (err) {
            loggerHelper.error(err);
            callback(false, null, 0);
        });
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null, 0);
    });
}

//23.견적작성
exports.insert = function (data, callback) {
    autoIncrement.initialize(db);
    marketSchema.plugin(autoIncrement.plugin, { 'model': 'Market', 'field': 'marketsn', 'startAt': 1, 'incrementBy': 1 });
    data.regdate = new Date().format('yyyy-MM-dd HH:mm:ss');
    
    model(data).save().then( function (doc) {
        if (doc == null) {
            callback(false);
        } else {
            callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false);
    });
}

//24.견적 수정
exports.update = function (marketsn, data, callback) {
    var marketsn = { 'marketsn': marketsn, 'useyn': true };
    var set = { '$set': data };
    
    model.update(marketsn, set).then( function (dbresult) {
        if (dbresult.nModified == 0) {
            callback(false);
         } else {
            callback(true);
        }
    }, function(err) {
        loggerHelper.error(err);
        callback(false);
    });
}

// //25.견적 삭제
// exports.delete = function (marketsn, callback){
//     var marketsn = { 'marketsn': marketsn, 'useyn': true };
//     var set = { '$set': { 'useyn': false } };
    
//     model.update(marketsn, set).then( function(doc) {
//         if (doc.nModified == 0){
//             callback(-1);
//         } else {
//             callback(0);
//         }
//     }, function(err){
//         loggerHelper.error(err);
//         callback(-1);
//     });
// }

// 26. 입찰하기
exports.bidPush = function (marketsn, data, callback) {
    var where = { 'marketsn': marketsn };
    var obj = new bidModel(data);
    data.regdate = new Date().format('yyyy-MM-dd HH:mm:ss');
    var pushdata = { '$push': { 'bids': obj } };
    
    model.update(where, pushdata, { upsert: true }).then( function (dbresult) {
        if (dbresult.nModified == 0) {
            callback(false, null);
        } else {
            callback(true, obj);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
};

// // 입찰조회
// exports.bidInfo = function (marketsn, expertsn, callback) {
//     var where = { 'marketsn': marketsn , 'bids.expertsn': expertsn };
    
//     model.findOne(where).then( function (doc) {
//         if (doc == null) {
//             callback(false, null);
//         }
//         else {
//             callback(true, doc);
//         }
//     }, function (err) {
//         callback(false, null);
//     });
// };

// 27. 입찰취소
exports.bidPull = function (marketsn, _id, expertsn, callback) {
    var where = { 'marketsn': marketsn, 'useyn': true };
    var pulldata = { '$pull': { 'bids': { '_id': ObjectID(_id), 'expertsn': expertsn } } };
    
    // 수정 프로세스
    model.update(where, pulldata).then( function (dbresult) {
        if (dbresult.nModified == 0) {
            callback(false);
        }
        else {
            callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false);
    });
};

exports.marketslist = function (pagesize, usersn, last_marketsn, callback) {
    var where = { 'usersn': usersn, 'useyn': true };
    
    if (last_marketsn == 0)
        last_marketsn = 999999999;
    
    model.count(where).then( function (totalcount) {
        where = { 'usersn': usersn, 'marketsn': { '$lt': last_marketsn }, 'useyn': true };
        var field = { 'marketsn': 1, 'usersn': 1, 'username': 1, 'markettype': 1, 'marketsubtype': 1, 'markettype1_1': 1, 'markettype1_2': 1, 'markettype1_3': 1, 'markettype1_4': 1, 'markettype2_1': 1, 'markettype2_2': 1, 'bidscount': 1, 'status': 1, 'regdate': 1, 'enddate': 1, 'bids': 1 };
        var sort = { 'marketsn': -1 };
        
        model.find(where, field).sort(sort).limit(pagesize).then( function (docs) {
            callback(true, docs, totalcount);
        }, function(err){
            loggerHelper.error(err);
            callback(false, null, 0);
        });
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null, 0);
    });
}

exports.marketszzimlist = function (arrdish, callback) {
    var where = { 'marketsn': { '$in': arrdish }, 'useyn': true };
    var field = {
        'usersn': 1, 'username': 1, 'marketsn': 1, 'markettype': 1, 'marketsubtype': 1, 'markettype1_1': 1, 'markettype1_2': 1,
        'markettype1_3': 1, 'markettype1_4': 1, 'markettype2_1': 1, 'markettype2_2': 1, 'bidscount': 1, 'regdate': 1
    };
    
    marketModel.find(where, field).then( function (docs) {
        callback(true, docs);
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}