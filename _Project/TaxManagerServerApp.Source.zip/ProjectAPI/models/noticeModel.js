var mongoose = require('mongoose'),
    db = require('../common/mongooseHelper'),
    loggerHelper = require('../common/loggerHelper'),
	noticeSchema = new mongoose.Schema({
        noticesn: Number, // 공지일련번호
        title: String, // 제목
        content: String, // 내용
        attachurl: String, // 이미지경로
        detailattachurl: String, // 이미지경로
        status : String, // 공지여부
        regdate: String, // 등록일
        upddate: String, // 수정일
        useyn: {type: Boolean, default: true} // 사용여부
	});

var model = db.model('Notice', noticeSchema);

exports.list = function (last_noticesn, status, pagesize, callback) {
    var where = { 'status': status, 'useyn': true };
    
    if (last_noticesn == 0)
        last_noticesn = 999999999;
    
    model.count(where).then( function (totalCount) {
        where.noticesn = { '$lt': last_noticesn };
        var field = { 'noticesn': 1, 'title': 1, 'content': 1, 'attachurl': 1, 'detailattachurl': 1, 'regdate': 1 };
        var sort = { 'noticesn': -1 };
        
        // 리스트 조회 프로세스
        model.find(where, field).sort(sort).limit(pagesize).then( function (docs) {
            callback(true, docs, totalCount);
        }, function (err) {
            loggerHelper.error(err);
            callback(false, null, 0);
        });
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null, 0);
    });
}

exports.listByMain = function (callback) {
    var pagesize = 5;
    var where = { 'status': '112_002', 'useyn': true };
    var field = { 'noticesn': 1, 'title': 1, 'content': 1, 'attachurl': 1, 'detailattachurl': 1, 'regdate': 1, 'upddate': 1 };
    var sort = { 'upddate': -1 };
    
    // 리스트 조회 프로세스
    model.find(where, field).sort(sort).limit(pagesize).then( function (docs) {
        callback(true, docs);
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}