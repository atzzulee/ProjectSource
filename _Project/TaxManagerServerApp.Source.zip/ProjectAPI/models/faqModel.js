var mongoose = require('mongoose'),
    db = require('../common/mongooseHelper'),
    loggerHelper = require('../common/loggerHelper'),
	faqSchema = new mongoose.Schema({
        faqsn: Number, // FAQ일련번호
        title: String, // 제목
        content: String, // 내용
        regdate: String, // 등록일
        useyn: {type: Boolean, default: true} // 사용여부
	});

var model = db.model('Faq', faqSchema);

exports.list = function (last_faqsn, pagesize, callback) {
    var where = { 'useyn': true };
    
    if (last_faqsn == 0)
        last_faqsn = 999999999;
    
    model.count(where).then( function (totalCount) {
        where.faqsn = { '$lt': last_faqsn };
        var field = { 'faqsn': 1, 'title': 1, 'content': 1, 'regdate': 1 };
        var sort = { 'faqsn': -1 };
        
        // 리스트 조회 프로세스
        model.find(where, field).sort(sort).limit(pagesize).then( function (docs) {
            callback(true, docs, totalCount);
        }, function (err) {
            loggerHelper.error(err);
            callback(false, null, 0);
        });
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null, 0);
    });
}