var mongoose = require('mongoose'),
    autoIncrement = require('mongoose-auto-increment'),
    db = require('../common/mongooseHelper');
    loggerHelper = require('../common/loggerHelper'),
    qnaSchema = new mongoose.Schema({
        qnasn: Number, // qna일련번호
        usersn: Number, // 유저일련번호
        username: String, // 유저명
        title: String, // 제목
        content: String, // 내용
        comments: [{
            _id: String, // 답글일련번호
            expertsn: String, // 전문가일련번호
            expertname: String, // 전문가이름
            sex: String, // 성별
            photo: String, // 이미지경로
            license: String, // 자격증
            mainintroduce: String, // 메인소개글
            officename: String, //사무실명
            career: Number, //경력
            age: Number, // 나이
            content: String, // 전문가내용
            likeusers: [], // 좋아요
            regdate: String, // 등록일
            useyn: {type: Boolean, default: true}, // 사용여부
            likecount: Number, // 좋아요카운트
            likeyn: Boolean // 유저의 좋아요여부
        }], // 답글리스트
        secretyn: Boolean, // 비밀글여부
        regdate: String, // 등록일
        useyn: {type: Boolean, default: true}, // 사용여부
        commentcount: Number, // 답글카운트
        readyn: Boolean // 읽기여부
    }),
    commentSchema = new mongoose.Schema({
        expertsn: String, // 전문가일련번호
        expertname: String, // 전문가이름
        sex: String, // 성별
        photo: String, // 이미지경로
        license: String, // 자격증
        mainintroduce: String, // 메인소개글
        officename: String, //사무실명
        career: Number, //경력
        age: Number, // 나이
        content: String, // 전문가내용
        likeusers: [], // 좋아요
        regdate: String, // 등록일
        useyn: {type: Boolean, default: true} // 사용여부
    });

var model = db.model('Qna', qnaSchema);
var commentModel = db.model('Comment', commentSchema);

exports.info = function (qnasn, callback) {
    var where = { 'qnasn': qnasn, 'useyn': true };

    // 상세조회 프로세스
    model.findOne(where).then( function (doc) {
        if (doc == null) {
            callback(false, null);
        }
        else {
            callback(true, doc);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}

exports.list = function (last_qnasn, pagesize, callback) {
    var where = { 'useyn': true };
    
    if (last_qnasn == 0)
        last_qnasn = 999999999;
    
    model.count(where).then( function (totalCount) {
        where.qnasn = { '$lt': last_qnasn };
        var field = { 'qnasn': 1, 'usersn': 1, 'username': 1, 'title': 1, 'content': 1, 'comments': 1, 'commentcount': 1, 'secretyn': 1, 'regdate': 1 };
        var sort = { 'qnasn': -1 };
        
        // 리스트 조회 프로세스
        model.find(where, field).sort(sort).limit(pagesize).then( function (docs) {
            callback(true, docs, totalCount);
        }, function (err) {
            loggerHelper.error(err);
            callback(false, null, 0);
        });
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null, 0);
    });
}

exports.search = function (last_qnasn, pagesize, keyword, callback) {
    var where = { 'useyn': true, '$or': [ {'title': { '$regex': keyword } }, {'content': { '$regex': keyword } }, {'comments.content': { '$regex': keyword } } ] };
    
    if (last_qnasn == 0)
        last_qnasn = 999999999;
    
    model.count(where).then( function (totalCount) {
        where.qnasn = { '$lt': last_qnasn };
        var field = { 'qnasn': 1, 'usersn': 1, 'username': 1, 'title': 1, 'content': 1, 'comments': 1, 'commentcount': 1, 'secretyn': 1, 'regdate': 1 };
        var sort = { 'qnasn': -1 };
        
        // 리스트 조회 프로세스
        model.find(where, field).sort(sort).limit(pagesize).then( function (docs) {
            callback(true, docs, totalCount);
        }, function (err) {
            loggerHelper.error(err);
            callback(false, null, 0);
        });
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null, 0);
    });
}

exports.mylist = function (last_qnasn, usersn, pagesize, callback) {
    var where = { 'usersn': usersn, 'useyn': true };
    
    if (last_qnasn == 0)
        last_qnasn = 999999999;
    
    model.count(usersn).then( function (totalCount) {
        where.qnasn = { '$lt': last_qnasn };
        var field = { 'qnasn': 1, 'usersn': 1, 'username': 1, 'title': 1, 'content': 1, 'comments': 1, 'commentcount': 1, 'secretyn': 1, 'regdate': 1 };
        var sort = { 'qnasn': -1 };
        
        // 리스트 조회 프로세스
        model.find(where, field).sort(sort).limit(pagesize).then( function (docs) {
            callback(true, docs, totalCount);
        }, function (err) {
            loggerHelper.error(err);
            callback(false, null, 0);
        });
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null, 0);
    });
}

exports.insert = function (data, callback) {
    // 등록 프로세스
    autoIncrement.initialize(db);
    qnaSchema.plugin(autoIncrement.plugin, { 'model': 'Qna', 'field': 'qnasn', 'startAt': 1, 'incrementBy': 1 });
    data.regdate = new Date().format('yyyy-MM-dd HH:mm:ss');
    
    model(data).save().then( function (doc) {
        if (doc == null) {
            callback(false);
        }
        else {
            callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false);
    });
}

exports.update = function (qnasn, data, callback) {
    var where = { 'qnasn': qnasn, 'useyn': true };
    var set = { '$set': data };

    // 수정 프로세스
    model.update(where, set).then( function (dbresult) {
        if (dbresult.nModified == 0) {
            callback(false);
        }
        else {
            callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false);
    });
}

exports.delete = function (qnasn, callback) {
    var where = { 'qnasn': qnasn, 'useyn': true };
    var set = { '$set': { 'useyn': false } };

    // 삭제 프로세스
    model.update(where, set).then( function (dbresult) {
        if (dbresult.nModified == 0) {
            callback(false);
        }
        else {
            callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false);
    });
}

exports.commentPush = function (qnasn, data, callback) {
    var where = { 'qnasn': qnasn, 'useyn': true };
    var obj = new commentModel(data);
    obj.regdate = new Date().format('yyyy-MM-dd HH:mm:ss');
    var pushdata = { '$push': { 'comments': obj } };
    
    // 수정 프로세스
    model.update(where, pushdata, { upsert: true }).then( function (dbresult) {
        if (dbresult.nModified == 0) {
            callback(false);
        }
        else {
            callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false);
    });
}

exports.commentPull = function (qnasn, _id, callback) {
    var where = { 'qnasn': qnasn, 'comments._id': _id, 'useyn': true };
    var set = { '$set': { 'comments.$.useyn': false } };
    
    // 수정 프로세스
    model.update(where, set).then( function (dbresult) {
        if (dbresult.nModified == 0) {
            callback(false);
        }
        else {
            callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false);
    });
}

exports.likePush = function (qnasn, _id, usersn, callback) {
    var where = { 'qnasn': qnasn, 'comments._id': _id, 'useyn': true };
    var pushdata = { '$push': { 'comments.$.likeusers': usersn } };
    var upsert = { upsert: true };

    // 수정 프로세스
    model.update(where, pushdata, upsert).then( function (dbresult) {
        if (dbresult.nModified == 0) {
            callback(false);
        }
        else {
            callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false);
    });
}

exports.likePull = function (qnasn, _id, usersn, callback) {
    var where = { 'qnasn': qnasn, 'comments._id': _id, 'useyn': true };
    var pulldata = { '$pull': { 'comments.$.likeusers': usersn } };

    // 수정 프로세스
    model.update(where, pulldata).then( function (dbresult) {
        if (dbresult.nModified == 0) {
            callback(false);
        }
        else {
            callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false);
    });
}