var mongoose = require('mongoose'),
    autoIncrement = require('mongoose-auto-increment'),
    db = require('../common/mongooseHelper'),
    loggerHelper = require('../common/loggerHelper'),
	userSchema = new mongoose.Schema({
		usersn: Number,
		username: String,
		email: String,
		password: String,
		salt: String,
		phone: String,
		pushkey: String,
		pushyn: {type: Boolean, default: true},
        usertype1: String,
        usertype2: String,
		roles: String,
        warning: {type: Number, default: 0},
		regdate: String,
		status: String,
		useyn: {type: Boolean, default: true}
	});
    
var model = db.model('User', userSchema);
    
exports.info = function (usersn, callback) {
    var where = { 'usersn': usersn, 'useyn': true };
    var field = { 'usersn': 1, 'username': 1, 'email': 1, 'phone': 1, 'pushyn': 1, 'pushkey': 1, 'usertype1': 1, 'usertype2': 1, 'roles': 1, 'status': 1 };

    // 상세조회 프로세스
    model.findOne(where, field).then( function (doc) {
        if (doc == null) {
            callback(false, null);
        }
        else {
            callback(true, doc);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}

exports.checkEmail = function (email, callback) {
    var where = { 'email': email, 'useyn': true };

    // 상세조회 프로세스
    model.findOne(where).then( function (doc) {
        if (doc == null) {
            callback(false);
        }
        else {
            callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false);
    });
};

exports.checkUser = function (email, callback) {
    var where = { 'email': email, 'useyn': true };
    
    // 상세조회 프로세스
    model.findOne(where).then( function (doc) {
        if (doc == null) {
            callback(-1, null);
        }
        else {
            if (doc.status == '101_004' || doc.status == '101_005') {
                callback(-2, null);
            }
            else {
                callback(0, doc);
            }
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(-1, null);
    });
}

exports.insert = function (data, callback) {
    // 등록 프로세스
    autoIncrement.initialize(db);
    userSchema.plugin(autoIncrement.plugin, { 'model': 'User', 'field': 'usersn', 'startAt': 1, 'incrementBy': 1 });
    data.regdate = new Date().format('yyyy-MM-dd HH:mm:ss');
    
    model(data).save().then( function (doc) {
        if (doc == null) {
            callback(false, null);
        }
        else {
            callback(true, doc);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}

exports.update = function (usersn, data, callback) {
    var where = { 'usersn': usersn, 'useyn': true };
    var set = { '$set': data };

    // 수정 프로세스
    model.update(where, set).then( function (dbresult) {
        if (dbresult.n == 0) {
            callback(false);
        } else {
            callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false);
    });
}

exports.delete = function (usersn, callback) {
    var where = { 'usersn': usersn, 'useyn': true };
    var set = { '$set': { 'useyn': false } };
    
    // 삭제 프로세스
    model.update(where, set).then( function (dbresult) {
        if (dbresult.nModified == 0) {
            callback(false);
        }
        else {
            callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false);
    });
}

exports.pushlist = function (arruser, callback) {
    var where = { 'usersn': { '$in': arruser }, 'pushyn': true, 'useyn': true };
    var field = { '_id': 0, 'usersn': 1, 'pushkey': 1 };
    
    // 리스트 조회 프로세스
    model.find(where, field).then( function (docs) {
        callback(true, docs);
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}