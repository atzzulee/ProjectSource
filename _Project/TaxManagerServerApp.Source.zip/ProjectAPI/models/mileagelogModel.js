var mongoose = require('mongoose'),
    autoIncrement = require('mongoose-auto-increment'),
    db = require('../common/mongooseHelper'),
    loggerHelper = require('../common/loggerHelper'),
    mileageslogSchema = new mongoose.Schema({
        mileagelogsn: Number, // 마일리지로그일련번호
        expertsn: Number, // 관리자일련번호
        expertname: String, // 관리자이름
        mileagetype: String, // 마일리지타입
        mileage: Number, // 마일리지,
        remainmileage: Number, // 남은 마일리지
        regdate: String // 등록일
    });
    
var model = db.model('Mileagelog', mileageslogSchema);

exports.list = function (pagesize, last_mileagelogsn, expertsn, callback) {
    var where = { 'expertsn': expertsn };
    
    if (last_mileagelogsn == 0)
        last_mileagelogsn = 999999999;
    
    model.count(where).then( function (totalCount) {
        where.mileagelogsn = { '$lt': last_mileagelogsn };
        var field = { 'mileagelogsn': 1, 'mileagetype': 1, 'mileage': 1, 'remainmileage': 1, 'regdate': 1 };
        var sort = { 'mileagelogsn': -1 };
        
        // 리스트 조회 프로세스
        model.find(where, field).sort(sort).limit(pagesize).then( function (docs) {
            callback(true, docs, totalCount);
        }, function (err) {
            loggerHelper.error(err);
            callback(false, null, 0);
        });
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null, 0);
    });
}

exports.info = function (expertsn, callback) {
    var where = { 'expertsn': expertsn };

    // 상세조회 프로세스
    model.findOne(where).then( function (doc) {
        if (doc == null) {
		    callback(true, 0);
        }
        else {
		    callback(true, doc.amount);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false, 0);
    });
}

exports.insert = function (data, callback) {
    // 등록 프로세스
    autoIncrement.initialize(db);
    mileageslogSchema.plugin(autoIncrement.plugin, { 'model': 'Mileagelog', 'field': 'mileagelogsn', 'startAt': 1, 'incrementBy': 1 });
    data.regdate = new Date().format('yyyy-MM-dd HH:mm:ss');

    model(data).save().then( function (doc) {
        if (doc == null) {
            callback(false, null);
        }
        else {
            callback(true, doc);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}

exports.delete = function (mileagelogsn, callback) {
    var where = { 'mileagelogsn': mileagelogsn }; 
    
    // 삭제 프로세스
    model.remove(where).then( function (dbresult) {
        if (dbresult.result.n == 0) {
            callback(false);
        }
        else {
            callback(true);
        }
    }, function (err) {
        loggerHelper.error(err);
        callback(false);
    });
}