var mongoose = require('mongoose'),
    db = require('../common/mongooseHelper'),
    loggerHelper = require('../common/loggerHelper'),
	codeSchema = new mongoose.Schema({
		codesn: Number,
		code: String,
		value: String,
		regdate: String
	});

var model = db.model('Code', codeSchema);

exports.list = function (callback) {
    // 리스트 조회 프로세스
    var field = { 'code': 1, 'value': 1 };
    var sort = { 'code': 1 };
    
    model.find({}, field).sort(sort).then( function (docs) {
        callback(true, docs);
    }, function (err) {
        loggerHelper.error(err);
        callback(false, null);
    });
}