var express = require('express'),
    async = require('async'),
    common = require('../common/common'),
	config = require('../config'),
    gcmHelper = require('../common/gcmHelper'),
    tokenHelper = require('../common/tokenHelper'),
    expertModel = require('../models/expertModel'),
    marketModel = require('../models/marketModel'),
    mileagelogModel = require('../models/mileagelogModel'),
    successfulbidModel = require('../models/successfulbidModel'),
    userModel = require('../models/userModel'),
    reviewModel = require('../models/reviewModel'),
    router = express.Router();

// 16.견적 리스트
router.post('/list', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next) {
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
	var result = {
		'result': 0,
		'message': '',
		'list': null,
		'totalcount': 0
	};
    
    if (!common.isNumberCheck(req.body.pagesize)) {
        result.result = -1;
        result.message = 'pagesize 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNumberCheck(req.body.last_marketsn)) {
        result.result = -1;
        result.message = 'last_marketsn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }

    if (profile.roles != '100_002') {
        result.result = -1;
        result.message = '전문가만 견적 조회가 가능합니다.';
		res.json(result);
    }
    
    var pagesize = eval(req.body.pagesize);
    var last_marketsn = eval(req.body.last_marketsn);
	
	marketModel.list(pagesize, last_marketsn, function (dbresult, docs, totalcount) {
		if (!dbresult) {
			result.result = -1;
			result.message = '데이터 요청 오류';
		} else {
            docs.forEach(function (item) {
                item.markettype = item.markettype.codeFormat(this);
                item.marketsubtype = item.marketsubtype.codeFormat(this);
                
                if (common.isNotNullCheck(item.markettype1_1)) {
                    item.markettype1_1 = item.markettype1_1.codeFormat(this);
                }
                
                if (common.isNotNullCheck(item.markettype1_3)) {
                    item.markettype1_3 = item.markettype1_3.codeFormat(this);
                }
                
                if (common.isNotNullCheck(item.markettype2_1)) {
                    for (var subitem in item.markettype2_1) {
                        item.markettype2_1[subitem] = item.markettype2_1[subitem].codeFormat(this);
                    }
                }
                
                item.bidscount = item.bids.length;
                item.status = item.status.codeFormat(this);
            });
			result.list = docs;
            result.totalcount = totalcount;
		}
		res.json(result);
	});
});

// 17.개별 견적 정보
router.post('/info/:marketsn', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next){
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
    
    var usersn = profile.usersn;
    var expertsn = profile.expertsn;
	var result = {
		'result': 0,
		'message': '',
		'item': null
	};
    
    if (!common.isNumberCheck(req.params.marketsn)) {
        result.result = -1;
        result.message = 'marketsn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    var marketsn = eval(req.params.marketsn);
    
    async.waterfall([
        function (cb) {
            // 상세조회 프로세스
            marketModel.info(marketsn, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '존재하지 않는 견적입니다.';
		            cb(true);
                }
                else {
                    if (doc.usersn != usersn && profile.roles != '100_002') {
                        result.result = -1;
                        result.message = '작성자 또는 전문가만 견적 조회가 가능합니다.';
		                cb(true);
                    }
                    else {
                        cb(null, doc);
                    }
                    cb(null, doc);
                }
            });
        },
        function (doc, cb) {
            reviewModel.info(doc.marketsn, function (dbresult, reviewdoc) {
                doc.markettype = doc.markettype.codeFormat(this);
                doc.marketsubtype = doc.marketsubtype.codeFormat(this);
                doc.regiontype = doc.regiontype.codeFormat(this);
                doc.regionsubtype = doc.regionsubtype.codeFormat(this);
                
                if (common.isNotNullCheck(doc.markettype1_1)) {
                    doc.markettype1_1 = doc.markettype1_1.codeFormat(this);
                }
                
                if (common.isNotNullCheck(doc.markettype1_3)) {
                    doc.markettype1_3 = doc.markettype1_3.codeFormat(this);
                }
                
                if (common.isNotNullCheck(doc.markettype2_1)) {
                    for (var subitem in doc.markettype2_1) {
                        doc.markettype2_1[subitem] = doc.markettype2_1[subitem].codeFormat(this);
                    }
                }
                
                if (usersn != doc.usersn) {
                    var bids;
                    doc.bids.forEach( function (item) {
                        if (expertsn == item.expertsn) {
                            bids = item;
                        }
                    });
                    
                    doc.bids = [];
                    if (bids != undefined) {
                        doc.bids.push(bids)
                    }
                }

                doc.bids.forEach( function (item) {
                    item.photo = (item.photo != undefined ? config.imageServer + item.photo : '');
                    item.sex = item.sex.codeFormat(this);
                });
                doc.status = doc.status.codeFormat(this);
                result.item = doc;

                if (reviewdoc != null)
                    result.item.reviewyn = true;
                else
                    result.item.reviewyn = false;
                
                cb(null);
            });
        }
    ], function (err, results) {
        res.json(result);
    });
});

// 18.견적 조회
router.post('/search/list', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next){
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
	var pagesize = 0;
	var last_marketsn = 0;
    var markettype = req.body.markettype;
    var marketsubtype = req.body.marketsubtype;
    var regiontype = req.body.regiontype;
    var regionsubtype = req.body.regionsubtype;
	var result = {
		'result': 0,
		'message': '',
		'list': null,
		'totalcount': 0
	};
    
    if (!common.isNumberCheck(req.body.pagesize)) {
        result.result = -1;
        result.message = 'pagesize 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNumberCheck(req.body.last_marketsn)) {
        result.result = -1;
        result.message = 'last_marketsn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNotNullCheck(req.body.markettype)) {
        result.result = -1;
        result.message = 'markettype 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNotNullCheck(req.body.marketsubtype)) {
        result.result = -1;
        result.message = 'marketsubtype 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNotNullCheck(req.body.regiontype)) {
        result.result = -1;
        result.message = 'regiontype 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNotNullCheck(req.body.regionsubtype)) {
        result.result = -1;
        result.message = 'regionsubtype 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (profile.roles != '100_002') {
        result.result = -1;
        result.message = '전문가만 견적 조회가 가능합니다.';
		res.json(result);
        return;
    }
    
    var pagesize = eval(req.body.pagesize);
    var last_marketsn = eval(req.body.last_marketsn);
    
	marketModel.searchlist(pagesize, last_marketsn, markettype, marketsubtype, regiontype, regionsubtype, function (dbresult, docs, totalcount) {
        if (!dbresult) {
            result.result = -1;
            result.message = '데이터 요청 오류';
        } else {
            docs.forEach( function (item) {
                item.markettype = item.markettype.codeFormat(this);
                item.marketsubtype = item.marketsubtype.codeFormat(this);
                
                if (common.isNotNullCheck(item.markettype1_1)) {
                    item.markettype1_1 = item.markettype1_1.codeFormat(this);
                }
                
                if (common.isNotNullCheck(item.markettype1_3)) {
                    item.markettype1_3 = item.markettype1_3.codeFormat(this);
                }
                
                if (common.isNotNullCheck(item.markettype2_1)) {
                    for (var subitem in item.markettype2_1) {
                        item.markettype2_1[subitem] = item.markettype2_1[subitem].codeFormat(this);
                    }
                }
                
                item.bidscount = item.bids.length;
                item.status = item.status.codeFormat(this);
            });
            result.list = docs;
            result.totalcount = totalcount;
        }
        res.json(result);
	});
});

// 23.견적 작성
router.post('/insert', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next){
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
	var result = {
        'result': 0,
        'message': ''
    };
    
    if (!common.isStringCheck(req.body.phone)) {
        result.result = -1;
        result.message = 'phone 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isStringCheck(req.body.markettype)) {
        result.result = -1;
        result.message = 'markettype 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (req.body.markettype != '003' && !common.isStringCheck(req.body.marketsubtype)) {
        result.result = -1;
        result.message = 'marketsubtype 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isStringCheck(req.body.regiontype)) {
        result.result = -1;
        result.message = 'regiontype 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isStringCheck(req.body.regionsubtype)) {
        result.result = -1;
        result.message = 'regionsubtype 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
	if (req.body.markettype == '001') { //기장
        if (!common.isStringCheck(req.body.markettype1_1)) {
            result.result = -1;
            result.message = 'markettype1_1 입력 받아야 합니다.';
            res.json(result);
            return;
        }
        
        if (!common.isNumberCheck(req.body.markettype1_2)) {
            result.result = -1;
            result.message = 'markettype1_2 숫자로 입력 받아야 합니다.';
            res.json(result);
            return;
        }
        
        if (!common.isStringCheck(req.body.markettype1_3)) {
            result.result = -1;
            result.message = 'markettype1_3 입력 받아야 합니다.';
            res.json(result);
            return;
        }
    
        if (!common.isNumberCheck(req.body.markettype1_4)) {
            result.result = -1;
            result.message = 'markettype1_4 숫자로 입력 받아야 합니다.';
            res.json(result);
            return;
        }
	} else if (req.body.markettype == '002') { //TEX
        if (!common.isStringCheck(req.body.markettype2_1)) {
            result.result = -1;
            result.message = 'markettype2_1 입력 받아야 합니다.';
            res.json(result);
            return;
        }
        
        if (!common.isStringCheck(req.body.markettype2_2)) {
            result.result = -1;
            result.message = 'markettype2_2 입력 받아야 합니다.';
            res.json(result);
            return;
        }
	}
    
    if (!common.isStringCheck(req.body.content)) {
        result.result = -1;
        result.message = 'content 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNumberCheck(req.body.enddate)) {
        result.result = -1;
        result.message = 'enddate 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (profile.roles != '100_001') {
        result.result = -1;
        result.message = '유저만 견적 등록이 가능합니다.';
		res.json(result);
    }

	var marketsn = eval(req.params.marketsn);
    var data = {
        'usersn': profile.usersn, // 유저일련번호
        'username': profile.username, // 유저명
        'phone': req.body.phone, // 전화번호
        'markettype': req.body.markettype, // 견적타입1
        'marketsubtype': req.body.marketsubtype, // 견적타입2
        'regiontype': req.body.regiontype, // 지역타입1
        'regionsubtype': req.body.regionsubtype, // 지역타입2
        'content': req.body.content, // 내용
        'status': '110_001', // 견적상태
        'enddate': eval(req.body.enddate) // 마감일
    };
    
	if (req.body.markettype == '001') { //기장
        data.markettype1_1 = req.body.markettype1_1, // 견적타입1의1
        data.markettype1_2 = eval(req.body.markettype1_2), // 견적타입1의2 (매출규모)
        data.markettype1_3 = req.body.markettype1_3, // 견적타입1의3 (사업종류)
        data.markettype1_4 = eval(req.body.markettype1_4) // 견적타입1의4 (종업원수)
    }
    else if (req.body.markettype == '002') {
        data.markettype2_1 = req.body.markettype2_1; // 견적타입2의1 (재산대상)
        data.markettype2_2 = req.body.markettype2_2; // 견적타입2의2 (재산대상 시가)
        
        var arr2_1 = [];
        var arr2_2 = [];
        if (Array.isArray(data.markettype2_1)) {
            for (var item in data.markettype2_1) {
                arr2_1.push(data.markettype2_1[item]);
            }

            for (var item in data.markettype2_2) {
                arr2_2.push(data.markettype2_2[item]);
            }
        } else {
            arr2_1.push(data.markettype2_1);
            arr2_2.push(data.markettype2_2);
        }

        data.markettype2_1 = arr2_1; // 견적타입2의1 (재산대상)
        data.markettype2_2 = arr2_2; // 견적타입2의2 (재산대상 시가)
    }
    
    userModel.info(profile.usersn, function (dbresult, doc) {
        if (!dbresult) {
			result.result = -1;
			result.message = '등록 실패';
            res.json(result);
        }
        else {
            marketModel.insert(data, function (dbresult) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '등록 실패';
                }
                res.json(result);
            });
        }
    });
});

// 24.견적 수정
router.post('/info/:marketsn/update', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next){
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
    var result = {
        'result': 0,
        'message': ''
    };
    
    if (!common.isStringCheck(req.params.marketsn)) {
        result.result = -1;
        result.message = 'marketsn 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isStringCheck(req.body.phone)) {
        result.result = -1;
        result.message = 'phone 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isStringCheck(req.body.markettype)) {
        result.result = -1;
        result.message = 'markettype 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (req.body.markettype != '003' && !common.isStringCheck(req.body.marketsubtype)) {
        result.result = -1;
        result.message = 'marketsubtype 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isStringCheck(req.body.regiontype)) {
        result.result = -1;
        result.message = 'regiontype 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isStringCheck(req.body.regionsubtype)) {
        result.result = -1;
        result.message = 'regionsubtype 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
	if (req.body.markettype == '001') { //기장
        if (!common.isStringCheck(req.body.markettype1_1)) {
            result.result = -1;
            result.message = 'markettype1_1 입력 받아야 합니다.';
            res.json(result);
            return;
        }
        
        if (!common.isNumberCheck(req.body.markettype1_2)) {
            result.result = -1;
            result.message = 'markettype1_2 숫자로 입력 받아야 합니다.';
            res.json(result);
            return;
        }
        
        if (!common.isStringCheck(req.body.markettype1_3)) {
            result.result = -1;
            result.message = 'markettype1_3 입력 받아야 합니다.';
            res.json(result);
            return;
        }
    
        if (!common.isNumberCheck(req.body.markettype1_4)) {
            result.result = -1;
            result.message = 'markettype1_4 숫자로 입력 받아야 합니다.';
            res.json(result);
            return;
        }
	} else if (req.body.markettype == '002') { //TEX
        if (!common.isStringCheck(req.body.markettype2_1)) {
            result.result = -1;
            result.message = 'markettype2_1 입력 받아야 합니다.';
            res.json(result);
            return;
        }
        
        if (!common.isStringCheck(req.body.markettype2_2)) {
            result.result = -1;
            result.message = 'markettype2_2 입력 받아야 합니다.';
            res.json(result);
            return;
        }
	}
    
    if (!common.isStringCheck(req.body.content)) {
        result.result = -1;
        result.message = 'content 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNumberCheck(req.body.enddate)) {
        result.result = -1;
        result.message = 'enddate 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }

	var marketsn = eval(req.params.marketsn);
    var data = {
        'usersn': profile.usersn, // 유저일련번호
        'username': profile.username, // 유저명
        'phone': req.body.phone, // 전화번호
        'markettype': req.body.markettype, // 견적타입1
        'marketsubtype': req.body.marketsubtype, // 견적타입2
        'regiontype': req.body.regiontype, // 지역타입1
        'regionsubtype': req.body.regionsubtype, // 지역타입2
        'content': req.body.content, // 내용
        'enddate': eval(req.body.enddate) // 마감일
    };
    
	if (req.body.markettype == '001') { //기장
        data.markettype1_1 = req.body.markettype1_1, // 견적타입1의1
        data.markettype1_2 = eval(req.body.markettype1_2), // 견적타입1의2 (매출규모)
        data.markettype1_3 = req.body.markettype1_3, // 견적타입1의3 (사업종류)
        data.markettype1_4 = eval(req.body.markettype1_4) // 견적타입1의4 (종업원수)
    }
    else if (req.body.markettype == '002') {
        data.markettype2_1 = req.body.markettype2_1; // 견적타입2의1 (재산대상)
        data.markettype2_2 = req.body.markettype2_2; // 견적타입2의2 (재산대상 시가)
        
        var arr2_1 = [];
        var arr2_2 = [];
        if (Array.isArray(data.markettype2_1)) {
            for (var item in data.markettype2_1) {
                arr2_1.push(data.markettype2_1[item]);
            }

            for (var item in data.markettype2_2) {
                arr2_2.push(data.markettype2_2[item]);
            }
        } else {
            arr2_1.push(data.markettype2_1);
            arr2_2.push(data.markettype2_2);
        }

        data.markettype2_1 = arr2_1; // 견적타입2의1 (재산대상)
        data.markettype2_2 = arr2_2; // 견적타입2의2 (재산대상 시가)
    }
    
    async.waterfall([
        function (cb) {
            // 상세조회 프로세스
            marketModel.info(marketsn, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '존재하지 않은 견적입니다.';
		            cb(true);
                }
                else {
                    if (doc.usersn != profile.usersn) {
                        result.result = -1;
                        result.message = '견적 올린 유저만 수정할 수 있습니다.';
                        cb(true);
                    }
                    else if (doc.status != '110_001') {
                        result.result = -1;
                        result.message = '입찰전 상태의 견적에 대해서만 수정할 수 있습니다.';
                        cb(true);
                    }
                    else {
                        cb(null);
                    }
                }
            });
        },
        function (cb) {
            // 수정 프로세스
            marketModel.update(marketsn, data, function (dbresult) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '견적 수정 시 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    cb(null);
                }
            });
        }
    ], function (err, results) {
        res.json(result);
    });
});

// // 25.견적 삭제
// router.post('/info/:marketsn/delete', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next){
// 	var version = req.headers.version;
// var token = tokenHelper.getToken(req);
// var profile = tokenHelper.getProfile(token);
// 	var marketsn = 0;
//     var result = {
//         'result': 0,
//         'message': ''
//     };
	
//     if (isNaN(req.params.marketsn) || req.params.marketsn == '') {
//         result.result = -1;
//         result.message = 'marketsn 숫자로 입력 받아야 합니다.';
//         res.json(result);
//         return;
//     }
//     else {
//         marketsn = eval(req.params.marketsn);
//     }
	
// 	marketModel.delete(marketsn, function (dbresult) {
// 		if (dbresult < 0) {
// 			result.result = -1;
// 			result.message = '삭제 실패';
// 		}
//         res.json(result);
//     });
// });

// 26.입찰하기
router.post('/info/:marketsn/insert', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next){
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
    var result = {
        'result': 0,
        'message': ''
    };
    
    if (!common.isNumberCheck(req.params.marketsn)) {
        result.result = -1;
        result.message = 'marketsn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }

    if (!common.isStringCheck(req.body.comment)) {
        result.result = -1;
        result.message = 'comment 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNumberCheck(req.body.price1)) {
        result.result = -1;
        result.message = 'price1 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNumberCheck(req.body.price2)) {
        result.result = -1;
        result.message = 'price2 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (profile.roles != '100_002') {
        result.result = -1;
        result.message = '전문가만 입찰 등록이 가능합니다.';
		res.json(result);
        return;
    }
    
    var marketsn = eval(req.params.marketsn);
    var expertsn = profile.expertsn;
    var usersn = profile.usersn;
    var marketusersn = 0;
    var expertname = profile.username;
    var comment = req.body.comment;
    var price1 = eval(req.body.price1);
    var price2 = eval(req.body.price2);
    var mainintroduce = '';
    var photo = '';
    var sex = '';
    var _id = '';
    var mileage = 0;
    var mileagelogsn = 0;
    var addmileage = -5000;
    var arruser = [];
    var arrPushKey = [];
    var errcode = 0;
        
    async.waterfall([
        function (cb) {
            // 상세조회 프로세스
            expertModel.info(expertsn, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '전문가가 존재하지 않습니다.';
                    cb(true);
                }
                else {
                    mainintroduce = doc.mainintroduce;
                    photo = doc.photo;
                    sex = doc.sex;
                    mileage = doc.mileage;
                    
                    if (mileage + addmileage < 0) {
                        result.result = -1;
                        result.message = '마일리지가 부족합니다.';
                        cb(true);
                    }
                    else {
                        cb(null);
                    }
                }
            });
        },
        function (cb) {
            // 상세조회 프로세스
            marketModel.info(marketsn, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '존재하지 않는 견적입니다.';
                    cb(true);
                }
                else {
                    var flag = true;
                    doc.bids.forEach(function (item) {
                        if (item.expertsn == expertsn) {
                            flag = false;
                        }
                    });

                    if (!flag) {
                        result.result = -1;
                        result.message = '이미 입찰내역이 존재합니다.';
                        cb(true);
                    }
                    else {
                        var date = new Date(this.regdate);
                        if (new Date() > new Date(date.setDate(date.getDate() + this.enddate))) {
                            result.result = -1;
                            result.message = '입찰 유효시간이 지난 내역입니다.';
                            cb(true);
                        }
                        else {
                            arruser.push(doc.usersn);
                            marketusersn = doc.usersn;
                            cb(null);
                        }
                    }
                }
            });
        },
        function (cb) {
            // 상세조회 프로세스
            userModel.info(marketusersn, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '견적을 올린 유저가 존재하지 않습니다.';
		            cb(true);
                }
                else {
                    cb(null);
                }
            });
        },
        // function (cb) {
        //     // 상세조회 프로세스
        //     marketModel.bidInfo(marketsn, expertsn, function (dbresult, doc) {
        //         if (dbresult) {
        //             result.result = -1;
        //             result.message = '이미 입찰내역이 존재합니다.';
        //             cb(true);
        //         }
        //         else {
        //             cb(null);
        //         }
        //     });
        // },
        function (cb) {
            // 상세조회 프로세스
            userModel.pushlist(arruser, function (dbresult, docs) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '존재하지 않는 전문가 입니다.';
                    cb(true);
                }
                else {
                    docs.forEach( function (item) {
                        arrPushKey.push(item.pushkey);
                    });
                    cb(null);
                }
            });
        },
        function (cb) {
            var data = {
                'expertsn': expertsn, 'expertname': expertname, 'usersn': usersn, 'mainintroduce': mainintroduce, 'photo': photo, 'sex': sex, 'comment': comment, 'price1': price1, 'price2': price2
            };
            
            // 입찰하기
            marketModel.bidPush(marketsn, data, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '입찰하기 시 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    _id = doc._id;
                    cb(null);
                }
            });
        },
        function (cb) {
            errcode = -1;
            var data = {
                'expertsn': expertsn, 'expertname': expertname, 'mileagetype': '111_002', 'mileage': addmileage, 'remainmileage': mileage + addmileage
            }
            
            mileagelogModel.insert(data, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '마일리지 지급 시 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    mileagelogsn = doc.mileagelogsn;
                    cb(null);
                }
            });
        },
        function (cb) {
            errcode = -2;
            var data = { 'mileage': mileage + addmileage };
            
            expertModel.update(expertsn, data, function (dbresult) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '마일리지 차감 시 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    errcode = 0;
                    cb(null);
                }
            });
        },
    ], function (err, results) {
        switch (errcode) {
            case -1:
                // 삭제 프로세스
                marketModel.bidPull(marketsn, _id, expertsn, function (dbresult) {
                    result.result = -1;
                    result.message = '시스템에 에러가 발생했습니다.';
                    res.json(result);
                });
                break;
            case -2:
                var where = { 'marketsn': marketsn, 'useyn': true };

                // 삭제 프로세스
                mileageModel.delete(mileagelogsn, function (dbresult) {
                    marketModel.bidPull(marketsn, _id, expertsn, function (dbresult) {
                        result.result = -1;
                        result.message = '시스템에 에러가 발생했습니다.';
                        res.json(result);
                    });
                });
                break;
            default:
                if (result.result == 0 && arrPushKey.length > 0) {
                    gcmHelper.send(4, marketsn, arrPushKey);
                }
                res.json(result);
                break;
        }
    });
});

// router.post('/info/:marketsn/update', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next){
// 	var version = req.headers.version;
// var token = tokenHelper.getToken(req);
// var profile = tokenHelper.getProfile(token);
// 	var marketsn = 0;
// 	var price = 0;
// 	var price2 = 0;
// 	var data = {
// 		'result': 0,
// 		'message': ''
// 	};
	
//     if (isNaN(req.params.marketsn) || req.params.marketsn == '') {
//         result.result = -1;
//         result.message = 'marketsn 숫자로 입력 받아야 합니다.';
//         res.json(result);
//         return;
//     }
//     else {
//         marketsn = eval(req.params.marketsn);
//     }
    
//     if (isNaN(req.body.price1) || req.body.price1 == '') {
//         result.result = -1;
//         result.message = 'price1 숫자로 입력 받아야 합니다.';
//         res.json(result);
//         return;
//     }
//     else {
//         price1 = eval(req.body.price1);
//     }
    
//     if (isNaN(req.body.price2) || req.body.price2 == '') {
//         result.result = -1;
//         result.message = 'price2 숫자로 입력 받아야 합니다.';
//         res.json(result);
//         return;
//     }
//     else {
//         price2 = eval(req.body.price2);
//     }
	
// 	res.json(data);
// });

// // 입찰삭제
// router.post('/info/:marketsn/delete', function (req, res, next){
// 	var version = req.headers.version;
// 	var marketsn = 0;
// 	var result = {
// 		'result': 0,
// 		'message': ''
// 	};
	
//     if (isNaN(req.params.marketsn) || req.params.marketsn == '') {
//         result.result = -1;
//         result.message = 'marketsn 숫자로 입력 받아야 합니다.';
//         res.json(result);
//         return;
//     }
//     else {
//         marketsn = eval(req.params.marketsn);
//     }
    
// 	marketModel.bidPull(marketsn, _id, profile.expertsn, function (dbresult) {
//         if (dbresult < 0) {
//             result.result = dbresult;
//             result.message = "삭제 실패"
//         }
//         res.json(result);
// 	});
// });

// 30.낙찰
router.post('/info/:marketsn/success', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next){
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
	var marketsn = 0;
    var expertsn = 0;
	var result = {
		'result': 0,
		'message': ''
	};
	
    if (!common.isNumberCheck(req.params.marketsn)) {
        result.result = -1;
        result.message = 'marketsn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNumberCheck(req.body.expertsn)) {
        result.result = -1;
        result.message = 'expertsn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }

    var marketsn = eval(req.params.marketsn);
    var expertsn = eval(req.body.expertsn);
    var usersn = eval(profile.usersn);
    var successusersn = 0;
    var status = '';
    var errcode = 0;
    var arruser = [];
    var arrSuccessPushKey = [];
    var arrFailPushKey = [];
    
    async.waterfall([
        function (cb) {
            // 상세조회 프로세스
            marketModel.info(marketsn, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '존재하지 않은 견적입니다.';
		            cb(true);
                }
                else {
                    if (doc.usersn != usersn) {
                        result.result = -1;
                        result.message = '견적 올린 유저만 낙찰할 수 있습니다.';
                        cb(true);
                    }
                    else if (doc.status != '110_002' && doc.status != '110_003') {
                        result.result = -1;
                        result.message = '입찰 중 혹은 입찰마감인 견적에 대해서만 낙찰할 수 있습니다.';
                        cb(true);
                    }
                    else {
                        var date = new Date(this.regdate);
                        if (new Date() > new Date(date.setDate(date.getDate() + this.enddate + 7))) {
                            result.result = -1;
                            result.message = '낙찰 유효시간이 지났습니다.';
                            cb(true);
                        }
                        else {
                            status = doc.status;
                            doc.bids.forEach(function (item) {
                                arruser.push(item.usersn);
                                if (item.expertsn == expertsn) {
                                    successusersn = item.usersn;
                                }
                            });
                            cb(null);
                        }
                    }
                }
            });
        },
        function (cb) {
            // 상세조회 프로세스
            userModel.pushlist(arruser, function (dbresult, docs) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '존재하지 않는 전문가 입니다.';
                    cb(true);
                }
                else {
                    docs.forEach( function (item) {
                        if (item.usersn == successusersn) {
                            arrSuccessPushKey.push(item.pushkey);
                        } else {
                            arrFailPushKey.push(item.pushkey);
                        }
                    });
                    cb(null);
                }
            });
        },
        function (cb) {
            var data = { 'success_expertsn': expertsn, 'status': '110_004' };

            marketModel.update(marketsn, data, function (dbresult) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = "낙찰이 실패됐습니다.";
                    cb(true);
                }
                else {
                    cb(null);
                }
            });
        },
        function (cb) {
            errcode = -1;
            var data = { 'marketsn': marketsn, 'expertsn': expertsn };

            successfulbidModel.insert(data, function (dbresult) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = "입찰완료 저장 시 에러가 발생했습니다.";
                    cb(true);
                }
                else {
                    errcode = 0;
                    cb(null);
                }
            });
        }
    ], function (err, results) {
        switch (errcode) {
            case -1:
                var data = { 'success_expertsn': null, 'status': status };

                marketModel.update(marketsn, data, function (dbresult) {
                    result.result = -1;
                    result.message = '시스템에 에러가 발생했습니다.';
                    res.json(result);
                });
                break;
            default:
                if (result.result == 0 && arrSuccessPushKey.length > 0) {
                    gcmHelper.send(7, '110_004', arrSuccessPushKey);
                }
                if (result.result == 0 && arrFailPushKey.lenght > 0) {
                    gcmHelper.send(8, '110_006', arrFailPushKey);
                }
                res.json(result);
                break;
        }
    });
});

// 29.찜하기
router.post('/info/:marketsn/dishinsert', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next){
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
	var marketsn = 0;
	var data = {
	  'result': 0,
	  'message': ''
	};
	
    if (!common.isNumberCheck(req.params.marketsn)) {
        result.result = -1;
        result.message = 'marketsn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }

    if (profile.roles != '100_002') {
        result.result = -1;
        result.message = '전문가만 찜할 수 있습니다.';
		res.json(result);
        return;
    }
    
    var marketsn = eval(req.params.marketsn);

    async.waterfall([
        function (cb) {
            // 상세조회 프로세스
            marketModel.info(marketsn, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '존재하지 않은 견적입니다.';
		            cb(true);
                }
            });
        },
        function (cb) {
            // 상세조회 프로세스
            expertModel.info(expertsn, function (dbresut, doc) {
                if (!dbresut) {
                    result.result = -1;
                    result.message = '전문가 정보조회 중 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    var flag = true;
                    
                    if (doc.dishs.length >= 20) {
                        result.result = -1;
                        result.message = '최대20개까지 찜하기가 가능합니다.';
                        cb(true);
                    }
                    else {
                        var arrDish = doc.dishs.filter(function (item) { return item == marketsn });
                        
                        if (arrDish.length != 0) {
                            result.result = -1;
                            result.message = '이미 찜한 경매입니다.';
                            cb(true);
                        }
                        else {
                            cb(null);
                        }
                    }
                }
            });
        },
        function (cb) {
            expertModel.dishPush(profile.expertsn, marketsn, function (dbresult) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '찜 등록 시 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    cb(null);
                }
            });
        }
    ], function (err, results) {
	    res.json(result);
    });
});

// 87.찜삭제
router.post('/info/:marketsn/dishdelete', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next){
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
	var marketsn = 0;
	var data = {
	  'result': 0,
	  'message': ''
	};
	
    if (!common.isNumberCheck(req.params.marketsn)) {
        result.result = -1;
        result.message = 'marketsn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }

    if (profile.roles != '100_002') {
        result.result = -1;
        result.message = '전문가만 찜삭제할 수 있습니다.';
		res.json(result);
        return;
    }
    
    var expertsn = profile.expertsn;
    var marketsn = eval(req.params.marketsn);

    async.waterfall([
        function (cb) {
            // 상세조회 프로세스
            marketModel.info(marketsn, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '존재하지 않은 견적입니다.';
		            cb(true);
                }
            });
        },
        function (cb) {
            // 상세조회 프로세스
            expertModel.info(expertsn, function (dbresut, doc) {
                if (!dbresut) {
                    result.result = -1;
                    result.message = '전문가 정보조회 중 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    var arrDish = doc.dishs.filter(function (item) { return item == marketsn });
                    
                    if (arrDish.length == 0) {
                        result.result = -1;
                        result.message = '찜한 경매가 아닙니다.';
    		            cb(true);
                    }
                    else {
                        cb(null);
                    }
                }
            });
        },
        function (cb) {
            expertModel.dishPull(expertsn, marketsn, function (dbresult) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = "찜하기 실패했습니다.";
                    cb(true);
                }
                else {
                    cb(null);
                }
            });
        }
    ], function (err, results) {
	    res.json(result);
    });
});

// 88.리뷰추가
router.post('/info/:marketsn/:expertsn/insert', function (req, res, next) {
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
	var result = {
	    'result': 0,
	    'message': ''
	};
	
    if (!common.isNumberCheck(req.params.marketsn)) {
        result.result = -1;
        result.message = 'marketsn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNumberCheck(req.params.expertsn)) {
        result.result = -1;
        result.message = 'expertsn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNumberCheck(req.body.score)) {
        result.result = -1;
        result.message = 'score 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isStringCheck(req.body.content)) {
        result.result = -1;
        result.message = 'content 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    var marketsn = eval(req.params.marketsn);
    var expertsn = eval(req.params.expertsn);
	var score = eval(req.body.score);
    var content = req.body.content;
	var usersn = profile.usersn;
    var username = profile.username;
    var addmileage = 1000;
    var mileage;
    var expertname;
    var mileagelogsn;
    var arruser = [];
    var arrPushkey = [];
    var errcode = 0;
    
    async.waterfall([
        function (cb) {
            // 상세조회 프로세스
            marketModel.info(marketsn, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '존재하지 않은 견적입니다.';
		            cb(true);
                }
                else {
                    if (doc.usersn != usersn) {
                        result.result = -1;
                        result.message = '견적 올린 유저만 리뷰를 등록할 수 있습니다.';
                        cb(true);
                    }
                    else if (doc.status != '110_004') {
                        result.result = -1;
                        result.message = '낙찰완료된 견적에 대해서만 리뷰를 등록할 수 있습니다.';
                        cb(true);
                    }
                    else if (doc.success_expertsn != expertsn) {
                        result.result = -1;
                        result.message = '낙찰된 전문가가 아닙니다.';
                        cb(true);
                    }
                    else {
                        doc.bids.forEach( function (item) {
                            if (item.expertsn == expertsn) {
                                expertname = item.expertname;
                            }
                        });
                        cb(null);
                    }
                }
            });
        },
        function (cb) {
            // 상세조회 프로세스
            expertModel.info(expertsn, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '전문가가 존재하지 않습니다.';
                    cb(true);
                }
                else {
                    arruser.push(doc.usersn);
                    mileage = doc.mileage;
                    cb(null);
                }
            });
        },
        function (cb) {
            // 상세조회 프로세스
            userModel.pushlist(arruser, function (dbresult, docs) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '유저가 존재하지 않습니다.';
                    cb(true);
                }
                else {
                    docs.forEach( function (item) {
                        arrPushkey.push(item.pushkey);
                    });
                    cb(null);
                }
            });
        },
        function (cb) {
            // 상세조회 프로세스
            reviewModel.info(marketsn, function (dbresult, doc) {
                if (dbresult) {
                    result.result = -1;
                    result.message = '리뷰를 등록할 수 없습니다.';
                    cb(true);
                }
                else {
                    cb(null);
                }
            });
        },
        function (cb) {
            var where = { 'marketsn': marketsn, 'useyn': true };
            var data = { 'marketsn': marketsn, 'expertsn': expertsn, 'usersn': usersn, 'username': username, 'score': score, 'content': content };
            
            // 리뷰 입력
            reviewModel.insert(data, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '리뷰 등록할 수 없습니다.';
                    cb(true);
                }
                else {
                    cb(null);
                }
            });
        },
        function (cb) {
            errcode = -1;
            var data = {
                'expertsn': expertsn, 'expertname': expertname, 'mileagetype': '111_006', 'mileage': addmileage, 'remainmileage': mileage + addmileage
            }
            
            mileagelogModel.insert(data, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '마일리지 지급 시 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    mileagelogsn = doc.mileagelogsn;
                    cb(null);
                }
            });
        },
        function (cb) {
            errcode = -2;
            var data = { 'mileage': mileage + addmileage };
            
            expertModel.update(expertsn, data, function (dbresult) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '마일리지 지급 시 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    errcode = 0;
                    cb(null);
                }
            });
        }
    ], function (err, results) {
        switch (errcode) {
            case -1:
                var where = { 'marketsn': marketsn, 'useyn': true };
                
                // 삭제 프로세스
                reviewModel.delete(where, function (dbresult) {
                    result.result = -1;
                    result.message = '시스템에 에러가 발생했습니다.';
                    res.json(result);
                });
                break;
            case -2:
                var where = { 'marketsn': marketsn, 'useyn': true };

                // 삭제 프로세스
                mileageModel.delete(mileagelogsn, function (dbresult) {
                    reviewModel.delete(where, function (dbresult) {
                        result.result = -1;
                        result.message = '시스템에 에러가 발생했습니다.';
                        res.json(result);
                    });
                });
                break;
            default:
                if (result.result == 0 && arrPushkey.length > 0) {
                    gcmHelper.send(9, expertsn, arrPushkey);
                }
                res.json(result);
                break;
        }
    });
});

// 89.리뷰수정
router.post('/info/:marketsn/:expertsn/update', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next) {
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
	var result = {
	    'result': 0,
	    'message': ''
	};
	
    if (!common.isNumberCheck(req.params.marketsn)) {
        result.result = -1;
        result.message = 'marketsn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNumberCheck(req.params.expertsn)) {
        result.result = -1;
        result.message = 'expertsn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNumberCheck(req.body.score)) {
        result.result = -1;
        result.message = 'expertsn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isStringCheck(req.body.content)) {
        result.result = -1;
        result.message = 'content 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    var marketsn = eval(req.params.marketsn);
    var expertsn = eval(req.params.expertsn);
	var usersn = profile.usersn;
    var username = profile.username;
	var score = eval(req.body.score);
    var content = req.body.content;
    
    async.waterfall([
        function (cb) {
            // 상세조회 프로세스
            marketModel.info(marketsn, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '존재하지 않은 견적입니다.';
		            cb(true);
                }
                else {
                    if (doc.usersn != usersn) {
                        result.result = -1;
                        result.message = '견적 올린 유저만 리뷰를 수정할 수 있습니다.';
                        cb(true);
                    }
                    else if (doc.status != '110_004') {
                        result.result = -1;
                        result.message = '낙찰완료된 견적에 대해서만 리뷰를 수정할 수 있습니다.';
                        cb(true);
                    }
                    else if (doc.success_expertsn != expertsn) {
                        result.result = -1;
                        result.message = '낙찰된 전문가가 아닙니다.';
                        cb(true);
                    }
                    else {
                        cb(null);
                    }
                }
            });
        },
        function (cb) {
            var data = { 'expertsn': expertsn, 'usersn': usersn, 'username': username, 'score': score, 'content': content };
            
            // 수정 프로세스
            reviewModel.update(marketsn, data, function (dbresult) {
                if (dbresult.nModified == 0) {
                    result.result = -1;
                    result.message = '리뷰수정 시 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    cb(null);
                }
            });
        }
    ], function (err, results) {
        res.json(result);
    });
});

// 90.리뷰삭제
router.post('/info/:marketsn/:expertsn/delete', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next) {
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
	var result = {
	    'result': 0,
	    'message': ''
	};
	
    if (!common.isNumberCheck(req.params.marketsn)) {
        result.result = -1;
        result.message = 'marketsn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNumberCheck(req.params.expertsn)) {
        result.result = -1;
        result.message = 'expertsn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    var marketsn = eval(req.params.marketsn);
    var expertsn = eval(req.params.expertsn);
	var usersn = profile.usersn;
	
    async.waterfall([
        function (cb) {
            // 상세조회 프로세스
            marketModel.info(marketsn, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '존재하지 않은 견적입니다.';
		            cb(true);
                }
                else {
                    if (doc.usersn != usersn) {
                        result.result = -1;
                        result.message = '견적 올린 유저만 리뷰를 삭제할 수 있습니다.';
                        cb(true);
                    }
                    else if (doc.status != '110_004') {
                        result.result = -1;
                        result.message = '낙찰완료된 견적에 대해서만 리뷰를 삭제할 수 있습니다.';
                        cb(true);
                    }
                    else if (doc.success_expertsn != expertsn) {
                        result.result = -1;
                        result.message = '낙찰된 전문가가 아닙니다.';
                        cb(true);
                    }
                    else {
                        cb(null);
                    }
                }
            });
        },
        function (cb) {
            var data = { 'useyn': false };
            
            // 삭제 프로세스
            reviewModel.update(marketsn, data, function (dbresult) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '리뷰삭제 시 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    cb(null);
                }
            }, function (err) {
                result.result = -1;
                result.message = '리뷰삭제 시 에러가 발생했습니다.';
                cb(true);
            });
        }
    ], function (err, results) {
        res.json(result);
    });
});

module.exports = router;