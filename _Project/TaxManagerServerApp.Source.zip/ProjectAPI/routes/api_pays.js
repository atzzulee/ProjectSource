var express = require('express'),
    async = require('async'),
    common = require('../common/common'),
	config = require('../config'),
    //mysqlHelper = require('../common/mysqlHelper'),
    tokenHelper = require('../common/tokenHelper'),
    //expertModel = require('../models/expertModel'),
    router = express.Router();

// 99. 결제요청
router.get('/insert', function (req, res, next) {
    var Iamport = require('iamport');
    var iamport = new Iamport({
        impKey: '0741005028817796',
        impSecret: 'HUxSjYflHFuLJ0OXPH9Bt6gPOUd0o8n53VYmTdIBTcnCcbz2SIEmPUbDOoEdx2jAXiWRwFspSP150B7T'
    });

// 아임포트 고유 아이디로 결제 정보를 조회
iamport.payment.getByImpUid({
  imp_uid: '0741005028817796'  
}).then(function(result){
  console.log(result);
}).catch(function(error){
  console.log(error);
});

    // iamport.subscribe.onetime({
    //     'merchant_uid': 'merchant_' + new Date().getTime(),
    //     'amount': 100,
    //     'card_number': '4364-2006-6315-6816',
    //     'expiry': '2019-10',
    //     'birth': '810128',
    //     'pwd_2digit': '19'
    // }).then( function (result) {
    //     console.log(result);
    // }).catch( function (err) {
    //     console.log(err);
    // });


// iamport.payment.getByImpUid({
//   imp_uid: 'your imp_uid'  
// }).then(function(result){
//   console.log(result);
// }).catch(function(error){
//   console.log(error);
// });




    res.json('');




	// var version = req.headers.version;
    // var result = {
    //     'result': 0,
    //     'message': ''
    // };
    
    // if (!common.isNumberCheck(req.body.amount)) {
    //     result.result = -1;
    //     result.message = 'amount 숫자로 입력 받아야 합니다.';
    //     res.json(result);
    //     return;
    // }

    // var amoeunt = eval(req.body.amount);

	// mysqlHelper.getConnection( function (err, connection) {
	// 	if (err) { next(err); return; }
        
    //     connection.beginTransaction(function(err) {
    //         if (err) {
    //             next(err);
    //             connection.release();
    //             result.result = -1;
    //             result.message = '결제요청 시 에러가 발생했습니다.';
    //             res.json(result);
    //         } 
    //         else {
    //             connection.query('INSERT INTO pays (amount, regdate) VALUES (?, now())', [amount], function (err, result) {
    //                 if (err) {
    //                     connection.rollback( function () {
    //                         next(err);
    //                         connection.release();
    //                         result.result = -1;
    //                         result.message = '결제요청 시 에러가 발생했습니다.';
    //                         res.json(result);
    //                     });
    //                 }
    //                 else {
    //                     if (result.affectedRows == 0) {
    //                         connection.release();
    //                         result.result = -1;
    //                         result.message = '결제 요청시 에러가 발생했습니다.';
    //                         res.json(result);
    //                     }
    //                     else {
    //                         connection.commit( function (err) {
    //                             if (err) {
    //                                 next(err);
    //                                 result.result = -1;
    //                                 result.message = '결제요청 시 에러가 발생했습니다.';
    //                             }
    //                             connection.release();
    //                             res.json(result);
    //                         });
    //                     }
    //                 }
    //             });
    //         }
    //     });
    //});
});

module.exports = router;