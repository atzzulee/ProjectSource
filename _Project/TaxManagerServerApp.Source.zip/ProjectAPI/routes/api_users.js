var express = require('express'),
    async = require('async'),
    common = require('../common/common'),
	config = require('../config'),
    tokenHelper = require('../common/tokenHelper'),
    expertModel = require('../models/expertModel'),
    marketModel = require('../models/marketModel'),
    userModel = require('../models/userModel'),
    qnaModel = require('../models/qnaModel'),
    router = express.Router();

// router.post('/mymain', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next) {
//     var version = req.headers.version;
//     var token = tokenHelper.getToken(req);
//     var profile = tokenHelper.getProfile(token);
//     var result = {
//         'result': 0,
//         'message': '',
//         'item': {
//             'username': profile.username,
//             'email': profile.email
//         }
//     };

//     res.json(result);
// });

router.post('/myprofile', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next) {
    var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
    var result = {
        'result': 0,
        'message': '',
        'item': profile
    };

    res.json(result);
});

router.post('/logout', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next) {
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var result = {
        result: 0,
        message: ''
    };

    tokenHelper.expireToken(token, function (dbresult) {
        if (!dbresult) {
            result.result = -1;
            result.message = '로그아웃 중 에러가 발생했습니다.';
        }
        res.json(result);
    });
});

router.post('/refreshtoken', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next) {
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
    var result = {
        'result': 0,
        'message': '',
        'token': '',
        'roles': ''
    };
    
    userModel.info(profile.usersn, function (dbresult, doc) {
        profile.username = doc.username;
        profile.pushyn = doc.pushyn;
        profile.roles = doc.roles;
        profile.status = doc.status;

        tokenHelper.refreshToken(token, profile, function (dbresult, newToken) {
            if (!dbresult) {
                result.result = -1;
                result.message = '토큰 갱신 중 에러가 발생했습니다.';
            }
            else {
                result.token = 'Bearer ' + newToken;
                result.roles = profile.roles.codeFormat(this);
            }
            res.json(result);
        });
    });
});

router.post('/setting', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next) {
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
    var result = {
        'result': 0,
        'message': '',
        'token': ''
    };
    
    if (!common.isStringCheck(req.body.pushyn)) {
        result.result = -1;
        result.message = 'pushyn를 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    var data = { 'pushyn': Boolean(req.body.pushyn === 'true') };
    
    userModel.update(profile.usersn, data, function (dbresult, newProfile) {
        if (dbresult < 0) {
            result.result = -1;
            result.message = '회원 정보수정 중 에러가 발생했습니다.';
            res.json(result);
        }
        else {
            tokenHelper.refreshToken(token, newProfile, function (dbresult, newToken) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '토큰 갱신 중 에러가 발생했습니다.';
                }
                else {
                    result.token = 'Bearer ' + newToken;
                }
                res.json(result);
            });
        }
    });
});

router.post('/info', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next) {
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
    var result = {
        'result': 0,
        'message': '',
        'item': ''
    };

    userModel.info(profile.usersn, function (dbresult, doc) {
        if (!dbresult) {
            result.result = -1;
            result.message = '회원 정보조회 중 에러가 발생했습니다.';
        }
        else {
            doc.usertype1 = (doc.usertype1 != undefined ? doc.usertype1.codeFormat(this) : '');
            doc.usertype2 = (doc.usertype2 != undefined ? doc.usertype2.codeFormat(this) : '');
            doc.roles = doc.roles.codeFormat(this);
            doc.status = doc.status.codeFormat(this);
            result.item = doc;
        }
        res.json(result);
    });
});

router.post('/update', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next) {
	var version = req.headers.version;

    if (!common.isStringCheck(req.body.username)) {
        result.result = -1;
        result.message = 'username 입력 받아야 합니다.';
        res.json(result);
        return;
    }

    if (!common.isStringCheck(req.body.phone)) {
        result.result = -1;
        result.message = 'phone 입력 받아야 합니다.';
        res.json(result);
        return;
    }

    var data = {
        'username': req.body.username, 'phone': req.body.phone, 'usertype1': req.body.usertype1, 'usertype2': req.body.usertype2
    };
    
    if (req.body.usertype1 == undefined)
        delete data['usertype1'];
    
    if (req.body.usertype2 == undefined)
        delete data['usertype2'];

    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
    var usersn = profile.usersn; 
    var expertsn = profile.expertsn; 
    var result = {
        'result': 0,
        'message': '',
        'token': ''
    };
    console.log(profile);
    async.waterfall([
        function (cb) {
            // 수정 프로세스
            userModel.update(usersn, data, function (dbresult) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '회원 정보수정 중 에러가 발생했습니다.';
                    cb(true);
                } else {
                    cb(null);
                }
            });
        },
        function (cb) {
            userModel.info(usersn, function (dbresut, doc) {
                if (!dbresut) {
                    result.result = -1;
                    result.message = '변경정보 조회 중 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    cb(null, doc);
                }
            });
        },
        function (doc, cb) {
            if (expertsn == undefined) {
                var profile = {
                    'usersn': doc.usersn,
                    'username': doc.username,
                    'email': doc.email,
                    'pushyn': doc.pushyn,
                    'roles': doc.roles,
                    'status': doc.status
                };
                cb(null, profile);
            }
            else {
                // 전문가 수정
                var expertname = { 'expertname': doc.username };
                expertModel.updateByUser(expertsn, expertname, function (dbresult) {
                    if (!dbresult) {
                        result.result = -1;
                        result.message = '전문가 정보수정 중 에러가 발생했습니다.';
                        cb(true);
                    }
                    else {
                        var profile = {
                            'usersn': doc.usersn,
                            'username': doc.username,
                            'email': doc.email,
                            'expertsn': expertsn,
                            'pushyn': doc.pushyn,
                            'roles': doc.roles,
                            'status': doc.status
                        };
                        cb(null, profile);
                    }
                });
            }
        },
        function (profile, cb) {
            tokenHelper.refreshToken(token, profile, function (dbresult, newToken) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '토큰 갱신 중 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    result.token = 'Bearer ' + newToken;
                    cb(null);
                }
            });
        }
    ], function (err, results) {
        res.json(result);
    });
});

router.post('/delete', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next) {
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
    var usersn = profile.usersn;
    var expertsn = profile.expertsn;
    var result = {
        'result': 0,
        'message': ''
    };
    
    async.waterfall([
        function (cb) {
            userModel.delete(usersn, function (dbresult) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '회원 탈퇴 중 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    cb(null);
                }
            });
        },
        function (cb) {
            if (expertsn == undefined) {
                cb(null);
            }
            else {
                var where = { 'expertsn': expertsn, 'useyn': true };
                
                // 전문가 탈퇴
                expertModel.updateByUser(where, data, function (dbresult) {
                    if (!dbresult) {
                        result.result = -1;
                        result.message = '전문가 탈퇴 중 에러가 발생했습니다.';
                        cb(true);
                    }
                    else {
                        cb(null);
                    }
                });
            }
        },
        function (cb) {
            tokenHelper.expireToken(token, function (dbresult) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '토큰 삭제 중 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    cb(null);
                }
            });
        }
    ], function (err, results) {
        res.json(result);
    });
});

router.post('/qnaslist', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next) {
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
    var usersn = profile.usersn;
    var result = {
        'result': 0,
        'message': '',
        'list': null
    };
    
    if (!common.isNumberCheck(req.body.pagesize)) {
        result.result = -1;
        result.message = 'pagesize 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNumberCheck(req.body.last_qnasn)) {
        result.result = -1;
        result.message = 'last_qnasn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    var pagesize = parseInt(req.body.pagesize);
    var last_qnasn = parseInt(req.body.last_qnasn);
    
	qnaModel.mylist(last_qnasn, usersn, pagesize, function (dbresult, list, totalcount) {
		if (!dbresult) {
			result.result = -1;
			result.message = 'QNA 리스트 조회 중 에러가 발생했습니다.';
		}
		else {
            list.forEach( function (item) {
                var arrComment = item.comments.filter(function(subitem) { return subitem.useyn == true });
                item.commentcount = arrComment.length;
                item.comments = [];
            });
			result.list = list;
			result.totalcount = totalcount;
		}
        res.json(result);
    });
});

router.post('/marketslist', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next) {
    var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
    var usersn = profile.usersn;
    var result = {
        'result': 0,
        'message': 0,
        'list': null,
        'totalcount': 0
    }
    
    if (!common.isNumberCheck(req.body.pagesize)) {
        result.result = -1;
        result.message = 'pagesize 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNumberCheck(req.body.last_marketsn)) {
        result.result = -1;
        result.message = 'last_marketsn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    var pagesize = parseInt(req.body.pagesize);
    var last_marketsn = parseInt(req.body.last_marketsn);
    
    marketModel.marketslist(pagesize, usersn, last_marketsn, function (dbresult, list, totalcount) {
        if (!dbresult) {
            result.result = -1;
            result.message = '나의 매물리스트 조회 중 에러가 발생했습니다.';
        } else {
            list.forEach(function (item) {
               item.markettype = item.markettype.codeFormat(this);
               item.marketsubtype = item.marketsubtype.codeFormat(this);
               
               if (item.markettype1_1 != undefined) {
                   item.markettype1_1 = item.markettype1_1.codeFormat(this);
               }
               
               if (item.markettype1_3 != undefined) {
                   item.markettype1_3 = item.markettype1_3.codeFormat(this);
               }
               
               for (var i = 0; i < item.markettype2_1.length; i++) {
                   item.markettype2_1[i] = item.markettype2_1[i].codeFormat(this);
               }
               
               item.status = item.status.codeFormat(this);
               item.bidscount = item.bids.length;
            });
            
            result.list = list;
            result.totalcount = totalcount;
        }
        res.json(result);
    });
});

module.exports = router;