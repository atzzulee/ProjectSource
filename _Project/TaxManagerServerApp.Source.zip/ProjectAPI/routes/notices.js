var express = require('express'),
    common = require('../common/common'),
	config = require('../config'),
    noticeModel = require('../models/noticeModel'),
    router = express.Router();

router.post('/list', function (req, res, next) {
	var version = req.headers.version;
    var result = {
        'result': 0,
        'message': '',
        'list': null,
		'totalcount': 0
    };
    
    if (!common.isNumberCheck(req.body.pagesize)) {
        result.result = -1;
        result.message = 'pagesize 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNumberCheck(req.body.last_noticesn)) {
        result.result = -1;
        result.message = 'last_noticesn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isStringCheck(req.body.status)) {
        result.result = -1;
        result.message = 'status 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
	var pagesize = eval(req.body.pagesize);
	var last_noticesn = eval(req.body.last_noticesn);
	var status = req.body.status;
    
	noticeModel.list(last_noticesn, status, pagesize, function (dbresult, list, totalcount) {
		if (!dbresult) {
			result.result = -1;
			result.message = '공지 리스트 조회 중 에러가 발생했습니다.';
		}
		else {
            list.forEach(function (item) {
                item.attachurl = config.imageServer + item.attachurl;
                item.detailattachurl = config.imageServer + item.detailattachurl;
            });
			result.list = list;
			result.totalcount = totalcount;
		}
        res.json(result);
    });
});

// router.post('/info/:noticesn', function(req, res, next){
// 	var version = req.headers.version;
// 	var noticesn = { 'noticesn': eval(req.params.last_noticesn), 'useyn': true };
// 	var result = {
// 		'result': 0,
// 		'message': '',
// 		'item': null
// 	};

// 	noticeModel.info(usersn, function (dbresult, item) {
// 		if (!dbresult) {
// 			result.result = -1;
// 			result.message = '공지 상세 조회 중 에러가 발생했습니다.';
// 		}
// 		else {
// 			result.item = item;
// 		}
//         res.json(result);
//     });
// });

module.exports = router;