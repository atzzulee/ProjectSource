var express = require('express'),
    async = require('async'),
    crypto = require('crypto'),
    common = require('../common/common'),
    tokenHelper = require('../common/tokenHelper'),
    userModel = require('../models/userModel'),
    expertModel = require('../models/expertModel'),
    router = express.Router();

router.post('/loginProcess', function (req, res, next) {
	var version = req.headers.version;
    var result = {
        'result': 0,
        'message': 0,
        'token': '',
        'roles': ''
    }
    
    if (!common.isStringCheck(req.body.email)) {
        result.result = -1;
        result.message = 'email 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isStringCheck(req.body.password)) {
        result.result = -1;
        result.message = 'password 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isStringCheck(req.body.pushkey)) {
        result.result = -1;
        result.message = 'pushkey 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    var email = req.body.email;
    var password = req.body.password;
    var pushkey = req.body.pushkey;

    async.waterfall([
        function (cb) {
            userModel.checkUser(email, function (dbresult, doc) {
                if (dbresult < 0) {
                    result.result = -1;
                    switch (dbresult) {
                        case -1:
                            result.message = '회원 정보조회 중 에러가 발생했습니다.';
                            cb(true);
                            break;
                        case -2:
                            result.message = '사용정지된 이용자입니다.';
                            cb(true);
                            break;
                        default:
                            break;
                    }
                }
                else {
                    cb(null, doc);
                }
            });
        },
        function (doc, cb) {
            var sha1 = crypto.createHash('sha1');
            sha1.update(password + doc.salt);
            
            if (doc.password != sha1.digest('hex')) {
                result.result = -1;
                result.message = '아이디 혹은 비밀번호가 틀렸습니다.';
                cb(true);
            }
            else {
                var data = { 'pushkey': pushkey };
                
                userModel.update(doc.usersn, data, function (dbresult) {
                    if (!dbresult) {
                        result.result = -1;
                        result.message = '푸시키 저장 중 에러가 발생했습니다.';
                        cb(true);
                    }
                    else {
                        if (doc.roles != '100_002') {
                            var profile = {
                                'usersn': doc.usersn,
                                'username': doc.username,
                                'email': doc.email,
                                'pushyn': doc.pushyn,
                                'roles': doc.roles,
                                'status': doc.status
                            };
                            
                            result.token = 'Bearer ' + tokenHelper.setToken(profile);
                            result.roles = doc.roles.codeFormat(this);
                            cb(null);
                        }
                        else {
                            // usersn 유저로 조회
                            expertModel.infoByUser(doc.usersn, function (dbresult, expertdoc) {
                                if (!dbresult) {
                                    result.result = -1;
                                    result.message = '전문가 정보조회 중 에러가 발생했습니다.';
                                    cb(true);
                                }
                                else {
                                    var profile = {
                                        'usersn': doc.usersn,
                                        'username': doc.username,
                                        'email': doc.email,
                                        'expertsn': expertdoc.expertsn,
                                        'pushyn': doc.pushyn,
                                        'roles': doc.roles,
                                        'status': doc.status
                                    };
                                    
                                    result.token = 'Bearer ' + tokenHelper.setToken(profile);
                                    result.roles = doc.roles.codeFormat(this);
                                    cb(null);
                                }
                            });
                        }
                    }
                });
            }
        }
    ], function (err, results) {
        res.json(result);
    });
});

router.post('/insert', function (req, res, next) {
	var version = req.headers.version;
    var result = {
        'result': 0,
        'message': '',
        'token': ''
    };
    
    if (!common.isStringCheck(req.body.username)) {
        result.result = -1;
        result.message = 'username 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isStringCheck(req.body.email)) {
        result.result = -1;
        result.message = 'email 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isStringCheck(req.body.password)) {
        result.result = -1;
        result.message = 'password 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isStringCheck(req.body.phone)) {
        result.result = -1;
        result.message = 'phone 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isStringCheck(req.body.pushkey)) {
        result.result = -1;
        result.message = 'pushkey 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isStringCheck(req.body.roles)) {
        result.result = -1;
        result.message = 'roles 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    var data = {
        'username': req.body.username, 'email': req.body.email, 'password': req.body.password, 'salt': '', 'phone': req.body.phone,
        'pushkey': req.body.pushkey, 'usertype1': req.body.usertype1, 'usertype2': req.body.usertype2, 'roles': req.body.roles, 'status': '' 
    };
    
    if (req.body.usertype1 == undefined)
        delete data['usertype1'];
    
    if (req.body.usertype2 == undefined)
        delete data['usertype2'];

    async.waterfall([
        function (cb) {
            userModel.checkEmail(data.email, function (dbresult) {
                if (dbresult) {
                    result.result = -1;
                    result.message = '사용 중인 메일입니다.';
                    cb(true);
                }
                else {
                    cb(null);
                }
            });
        },
        function (cb) {
            var salt = crypto.randomBytes(5).toString('hex');
            var sha1 = crypto.createHash('sha1');
            sha1.update(data.password + salt);
            data.salt = salt;
            data.password = sha1.digest('hex');
            
            if (data.roles != '100_002') {
                data.status = '101_001';
            } else {
                data.status = '101_003';
                delete data['usertype1'];
                delete data['usertype2'];
            }
            
            userModel.insert(data, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '회원 정보등록 중 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    if (doc.roles != '100_002') {
                        var profile = {
                            'usersn': doc.usersn,
                            'username': doc.username,
                            'email': doc.email,
                            'pushyn': doc.pushyn,
                            'roles': doc.roles,
                            'status': doc.status
                        };
                        
                        result.token = 'Bearer ' + tokenHelper.setToken(profile);
                        cb(true);
                    }
                    else {
                        cb(null, doc);
                    }
                }
            });
        },
        function (doc, cb) {
            // 전문가 등록
            var data = { 'usersn': doc.usersn, 'expertname': doc.username };
            
            expertModel.insertByUser(data, function (dbresult, expertdoc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '전문가 정보등록 중 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    var profile = {
                        'usersn': doc.usersn,
                        'username': doc.username,
                        'email': doc.email,
                        'expertsn': expertdoc.expertsn,
                        'pushyn': doc.pushyn,
                        'roles': doc.roles,
                        'status': doc.status
                    };
                    
                    result.token = 'Bearer ' + tokenHelper.setToken(profile);
                    cb(null);
                }
            });
        }
    ], function (err, results) {
        res.json(result);
    });
});

module.exports = router;