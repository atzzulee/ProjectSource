var express = require('express'),
    async = require('async'),
    common = require('../common/common'),
	config = require('../config'),
    tokenHelper = require('../common/tokenHelper'),
    expertModel = require('../models/expertModel'),
    marketModel = require('../models/marketModel'),
    mileagelogModel = require('../models/mileagelogModel'),
    router = express.Router();

router.post('/mymain', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next) {
    var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
    var result = {
        'result': 0,
        'message': '',
        'item': {
            'expertsn': profile.expertsn,
            'username': profile.username,
            'email': profile.email,
            'license': '',
            'photo': '',
            'mileage': 0,
            'bidcount': 0,
            'successbidcount': 0,
            'bidendcount': 0
        }
    };
    
    var asyncTasks = [];
    var task1 = function (callback) {
        expertModel.info(profile.expertsn, function (dbresult, doc) {
            if (!dbresult) {
                callback (null, null);
            }
            else {
                callback (null, doc);
            }
        });
    }
    asyncTasks.push(task1);
    
    var task2 = function (callback) {
        marketModel.mybidcount(profile.expertsn, function (dbresult, totalcount) {
            if (!dbresult) {
                callback (null, null);
            }
            else {
                callback (null, totalcount);
            }
        });
    }
    asyncTasks.push(task2);
    
    var task3 = function (callback) {
        marketModel.mysuccessbidcount(profile.expertsn, function (dbresult, totalcount) {
            if (!dbresult) {
                callback (null, null);
            }
            else {
                callback (null, totalcount);
            }
        });
    }
    asyncTasks.push(task3);
    
    var task4 = function (callback) {
        marketModel.mynotsuccessbidcount(profile.expertsn, function (dbresult, totalcount) {
            if (!dbresult) {
                callback (null, null);
            }
            else {
                callback (null, totalcount);
            }
        });
    }
    asyncTasks.push(task4);
    
    async.series(asyncTasks, function (err, results) {
        if (err) {
            result.result = -1;
            result.message = '전문가 기본 정보조회 중 에러가 발생했습니다.';
        }
        else {
            if (results[0] != null) {
                result.item.license = (results[0].license != undefined ? results[0].license.codeFormat(this) : '');
                result.item.photo = (results[0].photo != undefined ? config.imageServer + results[0].photo : '');
                result.item.sex = (results[0].sex != undefined ? results[0].sex.codeFormat(this) : '');
                result.item.mileage = results[0].mileage;
            }
            result.item.bidcount = results[1];
            result.item.successbidcount = results[2];
            result.item.bidendcount = results[3];
        }
        res.json(result);
    });
});

// 81.전문가 입찰, 낙찰, 마감 리스트 조회
router.post('/list', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next) {
    var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
    var expertsn = profile.expertsn;
    var result = {
        'result': 0,
        'message': '',
        'totalcount': 0,
        'list': null
    };
    
    if (!common.isNumberCheck(req.body.pagesize)) {
        result.result = -1;
        result.message = 'pagesize 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNumberCheck(req.body.last_marketsn)) {
        result.result = -1;
        result.message = 'last_marketsn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isStringCheck(req.body.status)) {
        result.result = -1;
        result.message = 'status 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    var pagesize = eval(req.body.pagesize);
    var last_marketsn = eval(req.body.last_marketsn);
    var status = req.body.status;
    
	marketModel.mylist(pagesize, last_marketsn, expertsn, status, function (dbresult, docs, totalcount) {
        if (!dbresult) {
            result.result = -1;
            result.message = '조회 시 에러가 발생했습니다.';
        } else {
            docs.forEach( function (item) {
                item.markettype = item.markettype.codeFormat(this);
                item.marketsubtype = item.marketsubtype.codeFormat(this);
                
                if (common.isNotNullCheck(item.markettype1_1)) {
                    item.markettype1_1 = item.markettype1_1.codeFormat(this);
                }
                
                if (common.isNotNullCheck(item.markettype1_3)) {
                    item.markettype1_3 = item.markettype1_3.codeFormat(this);
                }
                
                if (common.isNotNullCheck(item.markettype2_1)) {
                    for (var subitem in item.markettype2_1) {
                        item.markettype2_1[subitem] = item.markettype2_1[subitem].codeFormat(this);
                    }
                }

                if (item.status == '110_004' && item.success_expertsn == expertsn) {
                    item.bids.forEach ( function (subitem) {
                        if (item.success_expertsn == subitem.expertsn) {
                            item.price1 = subitem.price1;
                            item.price2 = subitem.price2;
                        }
                    });
                }
                else if (item.status == '110_004') {
                    item.status = '110_006';
                }
                
                item.status = item.status.codeFormat(this);
                item.bidscount = item.bids.length;
                item.bids = [];
            });
            result.list = docs;
            result.totalcount = totalcount;
        }
        res.json(result);
	});
});

router.post('/check', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next) {
    var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
    var result = {
        'result': 0,
        'message': '',
        'check': false
    };
    
    if (profile.status == '101_002')
        result.check = true;
    
    res.json(result);
});

router.post('/marketslist', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next) {
    var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
    var result = {
        'result': 0,
        'message': '',
        'list': null
    };
    
    var expertsn = profile.expertsn;
    var arrdish;
    
    async.waterfall([
        function (cb) {
            // 상세조회 프로세스
            expertModel.info(expertsn, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '전문가 정보조회 중 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    arrdish = doc.dishs;
                    cb(null);
                }
            });
        },
        function (cb) {
            marketModel.marketszzimlist(arrdish, function (dbresult, list) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '찜한 내역 조회 중 에러가 발생했습니다.';
                }
                else {
                    list.forEach( function (item) {
                        item.markettype = item.markettype.codeFormat(this);
                        item.marketsubtype = item.marketsubtype.codeFormat(this);
                        
                        if (common.isNotNullCheck(item.markettype1_1)) {
                            item.markettype1_1 = item.markettype1_1.codeFormat(this);
                        }
                        
                        if (common.isNotNullCheck(item.markettype1_3)) {
                            item.markettype1_3 = item.markettype1_3.codeFormat(this);
                        }
                        
                        if (common.isNotNullCheck(item.markettype2_1)) {
                            for (var subitem in item.markettype2_1) {
                                item.markettype2_1[subitem] = item.markettype2_1[subitem].codeFormat(this);
                            }
                        }
                        
                        item.status = item.status.codeFormat(this);
                        item.bidscount = item.bids.length;
                        item.bids = [];
                    });
                    
                    result.list = list;
                }
            });
        }
    ], function (err, results) {
        res.json(result);
    });
});

router.post('/mileagelog', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next) {
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
    var result = {
        'result': 0,
        'message': '',
        'list': null,
        'totalcount': 0,
        'remainmileage': 0
    };
    
    if (!common.isNumberCheck(req.body.pagesize)) {
        result.result = -1;
        result.message = 'pagesize 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNumberCheck(req.body.last_mileagelogsn)) {
        result.result = -1;
        result.message = 'last_mileagelogsn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    var pagesize = eval(req.body.pagesize);
    var last_mileagelogsn = eval(req.body.last_mileagelogsn);
    
    async.waterfall([
        function (cb) {
            expertModel.info(profile.expertsn, function (dbresult, doc) {
                if (doc == null) {
                    result.result = -1;
                    result.message = '전문가를 찾을 수 없습니다.';
                    cb(true);
                } else {
                    cb(null);
                }
            });
        },
        function (cb) {
            mileagelogModel.list(pagesize, last_mileagelogsn, profile.expertsn, function (dbresult, list, totalcount) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '마일리지 내역조회 시 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    if (list.length > 0) {
                        result.remainmileage = list[0].remainmileage;
                    }
                    
                    list.forEach( function (item) {
                        item.mileagetype = item.mileagetype.codeFormat(this);
                    });

                    result.list = list;
                    result.totalcount = totalcount;
                    cb(null);
                }
            });
        },
    ], function (err, results) {
        res.json(result);
    });
});

module.exports = router;