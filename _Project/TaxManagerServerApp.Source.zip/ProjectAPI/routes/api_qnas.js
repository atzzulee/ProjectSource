var express = require('express'),
    async = require('async'),
    common = require('../common/common'),
	config = require('../config'),
    gcmHelper = require('../common/gcmHelper'),
    tokenHelper = require('../common/tokenHelper'),
    expertModel = require('../models/expertModel'),
    qnaModel = require('../models/qnaModel'),
    userModel = require('../models/userModel'),
    router = express.Router();

// 8. QNA 리스트
router.post('/list', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next) {
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
    var result = {
        'result': 0,
        'message': '',
        'list': null,
		'totalcount': 0
    };
    
    if (!common.isNumberCheck(req.body.pagesize)) {
        result.result = -1;
        result.message = 'pagesize 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNumberCheck(req.body.last_qnasn)) {
        result.result = -1;
        result.message = 'last_qnasn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
	var pagesize = eval(req.body.pagesize);
	var last_qnasn = eval(req.body.last_qnasn);
	
	qnaModel.list(last_qnasn, pagesize, function (dbresult, list, totalcount) {
		if (!dbresult) {
			result.result = -1;
			result.message = 'QNA 리스트 조회 중 에러가 발생했습니다.';
		}
		else {
            list.forEach( function (item) {
                var arrComment = item.comments.filter(function(subitem) { return subitem.useyn == true });
                item.commentcount = arrComment.length;
                item.comments = [];

                if (item.usersn == profile.usersn || profile.roles == '100_002') {
                    item.readyn = true;
                } else {
                    item.readyn = false;
                }
            });
			result.list = list;
			result.totalcount = totalcount;
		}
        res.json(result);
    });
});

// 97. QNA 키워드 조회
router.post('/search', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next) {
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
    var result = {
        'result': 0,
        'message': '',
        'list': null,
		'totalcount': 0
    };
    
    if (!common.isNumberCheck(req.body.pagesize)) {
        result.result = -1;
        result.message = 'pagesize 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNumberCheck(req.body.last_qnasn)) {
        result.result = -1;
        result.message = 'last_qnasn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isStringCheck(req.body.keyword)) {
        result.result = -1;
        result.message = 'keyword 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
	var pagesize = eval(req.body.pagesize);
	var last_qnasn = eval(req.body.last_qnasn);
	var keyword = req.body.keyword;
    
	qnaModel.search(last_qnasn, pagesize, keyword, function (dbresult, list, totalcount) {
		if (!dbresult) {
			result.result = -1;
			result.message = 'QNA 리스트 조회 중 에러가 발생했습니다.';
		}
		else {
            list.forEach( function (item) {
                var arrComment = item.comments.filter(function(subitem) { return subitem.useyn == true });
                item.commentcount = arrComment.length;
                item.comments = [];

                if (item.usersn == profile.usersn || profile.roles == '100_002') {
                    item.readyn = true;
                } else {
                    item.readyn = false;
                }
            });
			result.list = list;
			result.totalcount = totalcount;
		}
        res.json(result);
    });
});

// 9. QNA 개별 정보
router.post('/info/:qnasn', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next) {
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
    var result = {
        'result': 0,
        'message': '',
        'item': null
    };
    
    if (!common.isNumberCheck(req.params.qnasn)) {
        result.result = -1;
        result.message = 'qnasn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
	var qnasn = eval(req.params.qnasn);
    var usersn = profile.usersn;
    var roles = profile.roles;
    
    qnaModel.info(qnasn, function (dbresult, doc) {
        if (!dbresult) {
            result.result = -1;
            result.message = 'QNA 정보조회 중 에러가 발생했습니다.';
        }
        else {
            if (doc.secretyn && !(roles == '100_002' || doc.usersn == usersn)) {
                result.result = -1;
                result.message = '비밀글은 작성자 또는 전문가만 조회가 가능합니다.';
            } else {
                doc.comments = doc.comments.filter(function(item) { return item.useyn == true });

                doc.comments.forEach( function (item) {
                    item.license = (item.license != undefined ? item.license.codeFormat(this) : '');
                    item.photo = (item.photo != undefined ? config.imageServer + item.photo : '');
                    item.sex = (item.sex != undefined ? item.sex.codeFormat(this) : '');
                    
                    var arrLike = item.likeusers.filter(function(subitem) { return subitem == usersn });
                    if (arrLike.length == 0) {
                        item.likeyn = false;
                    } else {
                        item.likeyn = true;
                    }
                    item.likecount = item.likeusers.length;
                    item.likeusers = [];
                });

                result.item = doc;
            }
        }
        res.json(result);
    });
});

// 98. QNA 댓글 좋아요
router.post('/info/:qnasn/like', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function (req, res, next) {
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
    var result = {
        'result': 0,
        'message': ''
    };
    
    if (!common.isStringCheck(req.body._id)) {
        result.result = -1;
        result.message = '_id 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    var usersn = profile.usersn;
    var roles = profile.roles;
	var qnasn = eval(req.params.qnasn);
    var _id = req.body._id;

    // 상세조회 프로세스
    qnaModel.info(qnasn, function (dbresult, doc) {
        if (!dbresult) {
            result.result = -1;
            result.message = 'QNA 정보조회 중 에러가 발생했습니다.';
            res.json(result);
        }
        else {
            var arrComment = doc.comments.filter(function(item) { return item._id == _id && item.useyn == true });
            
            if (arrComment.length == 0) {
                result.result = -1;
                result.message = 'QNA 답글조회 중 에러가 발생했습니다.';
                res.json(result);
            }
            else {
                var like = arrComment[0].likeusers.filter(function (item) { return item == usersn });
                if (like.length == 0) {
                    qnaModel.likePush(qnasn, _id, usersn, function (dbresult) {
                        if (!dbresult) {
                            result.result = -1;
                            result.message = 'QNA 좋아요 처리 시 에러가 발생했습니다.';
                        }
                        res.json(result);
                    });
                }
                else {
                    qnaModel.likePull(qnasn, _id, usersn, function (dbresult) {
                        if (!dbresult) {
                            result.result = -1;
                            result.message = 'QNA 좋아요 해제 시 에러가 발생했습니다.';
                        }
                        res.json(result);
                    });
                }
            }
        }
    });
});

// 31. QNA 개별 추가
router.post('/insert', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function(req, res, next) {
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
	var result = {
	    'result': 0,
	    'message': ''
	};

    if (!common.isStringCheck(req.body.title)) {
        result.result = -1;
        result.message = 'title 입력 받아야 합니다.';
        res.json(result);
        return;
    }

    if (!common.isStringCheck(req.body.content)) {
        result.result = -1;
        result.message = 'content 입력 받아야 합니다.';
        res.json(result);
        return;
    }

    if (!common.isStringCheck(req.body.secretyn)) {
        result.result = -1;
        result.message = 'secretyn 입력 받아야 합니다.';
        res.json(result);
        return;
    }

    if (profile.roles != '100_001') {
        result.result = -1;
        result.message = '유저만 Qna를 작성할 수 있습니다.';
        res.json(result);
        return;
    }
    
	var data = {
		'usersn': profile.usersn,
		'username': profile.username,
		'title': req.body.title,
        'content': req.body.content,
		'secretyn': Boolean(req.body.secretyn === 'true')
	};
	
    qnaModel.insert(data, function (dbresult) {
        if (!dbresult) {
            result.result = -1;
            result.message = 'QNA 추가 중 에러가 발생했습니다.';
        }
        res.json(result);
    });
});

// 32. QNA 개별 수정
router.post('/info/:qnasn/update', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function(req, res, next) {
    var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
	var result = {
	    'result': 0,
	    'message': ''
	};
    
    if (!common.isNumberCheck(req.params.qnasn)) {
        result.result = -1;
        result.message = 'qnasn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }

    if (!common.isStringCheck(req.body.title)) {
        result.result = -1;
        result.message = 'title 입력 받아야 합니다.';
        res.json(result);
        return;
    }

    if (!common.isStringCheck(req.body.content)) {
        result.result = -1;
        result.message = 'content 입력 받아야 합니다.';
        res.json(result);
        return;
    }

    if (!common.isStringCheck(req.body.secretyn)) {
        result.result = -1;
        result.message = 'secretyn 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
	var qnasn = eval(req.params.qnasn);
    var usersn = profile.usersn;
    var data = {
        'usersn': profile.usersn,
        'username': profile.username,
        'title': req.body.title,
        'content': req.body.content,
        'secretyn': Boolean(req.body.secretyn === 'true')
    };

    async.waterfall([
        function (cb) {
            // 상세조회 프로세스
            qnaModel.info(qnasn, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = 'QNA 조회 중 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    if (doc.usersn != usersn) {
                        result.result = -1;
                        result.message = '작성자만 수정이 가능합니다.';
                        cb(true);
                    } else {
                        cb(null);
                    }
                }
            });
        },
        function (cb) {
            qnaModel.update(qnasn, data, function (dbresult) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = 'QNA 수정 중 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    cb(null);
                }
            });
        }
    ], function (err, results) {
        res.json(result);
    });
});

// 33. QNA 개별 삭제
router.post('/info/:qnasn/delete', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function(req, res, next) {
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
	var result = {
	    'result': 0,
	    'message': ''
	};
    
    if (!common.isNumberCheck(req.params.qnasn)) {
        result.result = -1;
        result.message = 'qnasn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
	var qnasn = eval(req.params.qnasn);
    var usersn = profile.usersn;

    async.waterfall([
        function (cb) {
            // 상세조회 프로세스
            qnaModel.info(qnasn, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = 'QNA 조회 중 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    if (doc.usersn != usersn) {
                        result.result = -1;
                        result.message = '작성자만 삭제가 가능합니다.';
                        cb(true);
                    } else {
                        cb(null);
                    }
                }
            });
        },
        function (cb) {
            qnaModel.delete(qnasn, function (dbresult) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = 'QNA 삭제 중 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    cb(null);
                }
            });
        }
    ], function (err, results) {
        res.json(result);
    });
});

// 34. QNA 답글 추가
router.post('/info/:qnasn/reply/insert', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function(req, res, next) {
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
	var result = {
	    'result': 0,
	    'message': ''
	};
    
    if (!common.isNumberCheck(req.params.qnasn)) {
        result.result = -1;
        result.message = 'qnasn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isStringCheck(req.body.content)) {
        result.result = -1;
        result.message = 'content 입력 받아야 합니다.';
        res.json(result);
        return;
    }

    if (profile.roles != '100_002') {
        result.result = -1;
        result.message = '전문가만 Qna를 작성할 수 있습니다.';
        res.json(result);
        return;
    }
    
	var qnasn = eval(req.params.qnasn);
	var expertsn = profile.expertsn;
    var roles = profile.roles;
	var data = {
		'expertsn': profile.expertsn,
		'expertname': profile.username,
        'sex': '',
        'photo': '',
        'license': '',
        'mainintroduce': '',
        'officename': '',
		'career': 0,
		'age': 0,
        'content': req.body.content,
        'likeusers': []
	};
    var usersn;
    var arrPushKey = [];

    async.waterfall([
        function (cb) {
            // 상세조회 프로세스
            qnaModel.info(qnasn, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = 'QNA 조회 중 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    userModel.info(doc.usersn, function (dbresult, doc) {
                        if (dbresult) {
                            arrPushKey.push(doc.pushkey);
                        }
                        cb(null);
                    });
                }
            });
        },
        function (cb) {
            // 상세조회 프로세스
            expertModel.info(expertsn, function (dbresult, doc) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '전문가 조회 중 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    cb(null, doc);
                }
            });
        },
        function (doc, cb) {
            data.sex = doc.sex;
            data.photo = doc.photo;
            data.license = doc.license;
            data.mainintroduce = doc.mainintroduce;
            data.officename = doc.officename;
            data.career = doc.career;
            data.age = doc.age;

            qnaModel.commentPush(qnasn, data, function (dbresult) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = 'QNA 저장 중 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    cb(null);
                }
            });
        }
    ], function (err, results) {
        if (result.result == 0 && arrPushKey.length > 0) {
            gcmHelper.send(10, qnasn, arrPushKey);
        }

        res.json(result);
    });
});

// 36. QNA 답글 삭제
router.post('/info/:qnasn/reply/delete', [tokenHelper.isExpireCheck, tokenHelper.authMethod], function(req, res, next) {
	var version = req.headers.version;
    var token = tokenHelper.getToken(req);
    var profile = tokenHelper.getProfile(token);
	var result = {
	    'result': 0,
	    'message': ''
	};
    
    if (!common.isNumberCheck(req.params.qnasn)) {
        result.result = -1;
        result.message = 'qnasn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isStringCheck(req.body._id)) {
        result.result = -1;
        result.message = 'content 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
	var qnasn = eval(req.params.qnasn);
    var expertsn = profile.expertsn;
	var _id = req.body._id;
    
    async.waterfall([
        function (cb) {
            // 상세조회 프로세스
            qnaModel.info(qnasn, function (dbresult, doc) {
                if (!dbresult) {
		            result.result = -1;
                    result.message = 'QNA 조회 중 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    var arrComment = doc.comments.filter(function(item) { return item._id == _id && item.useyn == true });
            
                    if (arrComment.length == 0) {
                        result.result = -1;
                        result.message = 'QNA 답글 조회 중 에러가 발생했습니다.';
                        cb(true);
                    }
                    else if(arrComment[0].expertsn != expertsn) {
                        result.result = -1;
                        result.message = '작성자만 삭제가 가능합니다.';
                        cb(true);
                    }
                    else {
                        cb(null);
                    }
                }
            });
        },
        function (cb) {
            qnaModel.commentPull(qnasn, _id, function (dbresult) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = 'QNA 삭제 중 에러가 발생했습니다.';
                    cb(true);
                }
                else {
                    cb(null);
                }
            });
        },
    ], function (err, results) {
        res.json(result);
    });
});

module.exports = router;