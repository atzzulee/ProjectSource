var express = require('express'),
    common = require('../common/common'),
	config = require('../config'),
    expertModel = require('../models/expertModel'),
    mileagelogModel = require('../models/mileagelogModel'),
    reviewModel = require('../models/reviewModel'),
    userModel = require('../models/userModel'),
    router = express.Router();

router.post('/search', function (req, res, next) {
	var version = req.headers.version;
    var result = {
        'result': 0,
        'message': '',
        'list': null,
		'totalcount': 0
    };

    if (!common.isNumberCheck(req.body.pagesize)) {
        result.result = -1;
        result.message = 'pagesize 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNumberCheck(req.body.last_expertsn)) {
        result.result = -1;
        result.message = 'last_expertsn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNotNullCheck(req.body.markettype)) {
        result.result = -1;
        result.message = 'markettype 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNotNullCheck(req.body.marketsubtype)) {
        result.result = -1;
        result.message = 'marketsubtype 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNotNullCheck(req.body.regiontype)) {
        result.result = -1;
        result.message = 'regiontype 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNotNullCheck(req.body.regionsubtype)) {
        result.result = -1;
        result.message = 'regionsubtype 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    var pagesize = eval(req.body.pagesize);
    var last_expertsn = eval(req.body.last_expertsn);
	var markettype = req.body.markettype;
	var marketsubtype = req.body.marketsubtype;
	var regiontype = req.body.regiontype;
	var regionsubtype = req.body.regionsubtype;
    
	expertModel.search(last_expertsn, markettype, marketsubtype, regiontype, regionsubtype, pagesize, function (dbresult, list, totalcount) {
		if (!dbresult) {
			result.result = -1;
			result.message = '전문가 리스트 조회 중 에러가 발생했습니다.';
		}
		else {
            list.forEach(function (item) {
                item.sex =  (item.sex != undefined ? item.sex.codeFormat(this) : '');
                item.photo = (item.photo != undefined ? config.imageServer + item.photo : '');
            });
            
			result.list = list;
			result.totalcount = totalcount;
		}
        res.json(result);
    });
});

router.post('/info/:expertsn', function(req, res, next){
	var version = req.headers.version;
    var result = {
        'result': 0,
        'message': '',
        'item': null
    };
    
    if (!common.isNumberCheck(req.params.expertsn)) {
        result.result = -1;
        result.message = 'expertsn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
	var expertsn = eval(req.params.expertsn);
    
    expertModel.info(expertsn, function (dbresult, doc) {
        if (!dbresult) {
            result.result = -1;
            result.message = '전문가 정보조회 중 에러가 발생했습니다.';
            res.json(result);
        }
        else {
            userModel.info(doc.usersn, function (dbresult, doc2) {
                if (!dbresult) {
                    result.result = -1;
                    result.message = '전문가 정보조회 중 에러가 발생했습니다.';
                }
                else {
                    doc.sex = (doc.sex != undefined ? doc.sex.codeFormat(this) : '');
                    doc.belongto = (doc.belongto != undefined ? doc.belongto.codeFormat(this) : '');
                    doc.photo = (doc.photo != undefined ? config.imageServer + doc.photo : '');
                    doc.license = (doc.license != undefined ? doc.license.codeFormat(this) : '');
                    doc.categorys.forEach(function (item) {
                        item.markettype = item.markettype.codeFormat(this);
                        item.marketsubtype = item.marketsubtype.codeFormat(this);
                    });
                    doc.email = doc2.email;
                    result.item = doc;
                }
                res.json(result);
            });
        }
    });
});

router.post('/info/:expertsn/review', function(req, res, next){
	var version = req.headers.version;
	var pagesize = 0;
	var expertsn = 0;
	var last_marketsn = 0;
    var result = {
        'result': 0,
        'message': '',
        'list': null,
        'totalcount': 0
    };
    
    if (!common.isNumberCheck(req.params.expertsn)) {
        result.result = -1;
        result.message = 'expertsn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNumberCheck(req.body.pagesize)) {
        result.result = -1;
        result.message = 'pagesize 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNumberCheck(req.body.last_marketsn)) {
        result.result = -1;
        result.message = 'last_marketsn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
	var expertsn = eval(req.params.expertsn);
    var pagesize = eval(req.body.pagesize);
    var last_marketsn = eval(req.body.last_marketsn);
    
    reviewModel.list(last_marketsn, expertsn, pagesize, function (dbresult, list, totalcount) {
        if (!dbresult) {
            result.result = -1;
            result.message = '전문가 리뷰 조회 중 에러가 발생했습니다.';
        }
        else {
            result.list = list;
            result.totalcount = totalcount;
        }
        res.json(result);
    });
});

module.exports = router;