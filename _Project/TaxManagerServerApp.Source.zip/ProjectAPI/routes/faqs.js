var express = require('express'),
    common = require('../common/common'),
    faqModel = require('../models/faqModel'),
    router = express.Router();

router.post('/list', function (req, res, next) {
	var version = req.headers.version;
    var result = {
        'result': 0,
        'message': '',
        'list': null,
		'totalcount': 0
    };
    
    if (!common.isNumberCheck(req.body.pagesize)) {
        result.result = -1;
        result.message = 'pagesize 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
    if (!common.isNumberCheck(req.body.last_faqsn)) {
        result.result = -1;
        result.message = 'last_faqsn 숫자로 입력 받아야 합니다.';
        res.json(result);
        return;
    }
    
	var pagesize = eval(req.body.pagesize);
	var last_faqsn = eval(req.body.last_faqsn);
    
	faqModel.list(last_faqsn, pagesize, function (dbresult, list, totalcount) {
		if (!dbresult) {
			result.result = -1;
			result.message = '공지 리스트 조회 중 에러가 발생했습니다.';
		}
		else {
			result.list = list;
			result.totalcount = totalcount;
		}
        res.json(result);
    });
});

module.exports = router;