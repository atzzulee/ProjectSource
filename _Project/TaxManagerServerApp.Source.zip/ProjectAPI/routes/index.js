var express = require('express'),
    async = require('async'),
    codeModel = require('../models/codeModel'),
    marketModel = require('../models/marketModel'),
    noticeModel = require('../models/noticeModel'),
    tipModel = require('../models/tipModel'),
	config = require('../config'),
    regioncode = require('../common/regioncode'),
    router = express.Router();

router.get('/', function (req, res, next) {
    res.json('');
});

router.post('/main', function (req, res, next) {
	var version = req.headers.version;
    var data = {
   		'result': 0,
   		'message': '',
   		'item': {
            'bidscount': 0,
            'bidsendcount': 0
        }
    };

    var asyncTasks = [];
    var task1 = function (callback) {
        marketModel.bidcount('110_002', function (dbresult, totalcount) {
            if (!dbresult) {
                callback(null, null);
            }
            else {
                callback(null, totalcount);
            }
        });
    }
    asyncTasks.push(task1);

    var task2 = function (callback) {
        marketModel.bidcount('110_004', function (dbresult, totalcount) {
            if (!dbresult) {
                callback(null, null);
            }
            else {
                callback(null, totalcount);
            }
        });
    }
    asyncTasks.push(task2);

    async.series(asyncTasks, function (err, results) {
        if (err) {
            result.result = -1;
            result.message = '카운팅 에러.';
        }
        else {
            data.item.bidscount = results[0];
            data.item.bidsendcount = results[1];
        }
        res.json(data);
    });
});

router.post('/maincontent', function (req, res, next) {
	var version = req.headers.version;
    var data = {
   		'result': 0,
   		'message': '',
   		'item': {
            'noticeslist': null,
            'tipslist': null
        }
    };

    var asyncTasks = [];
    var task1 = function (callback) {
        noticeModel.listByMain( function (dbresult, list) {
            if (!dbresult) {
                callback(null, null);
            }
            else {
                callback(null, list);
            }
        });
    }
    asyncTasks.push(task1);

    var task2 = function (callback) {
        tipModel.listByMain( function (dbresult, list) {
            if (!dbresult) {
                callback(null, null);
            }
            else {
                callback(null, list);
            }
        });
    }
    asyncTasks.push(task2);

    async.series(asyncTasks, function (err, results) {
        if (err) {
            result.result = -1;
            result.message = '메인컨텐츠 조회 시 에러가 발생했습니다.';
        }
        else {
            results[0].forEach(function (item) {
                item.attachurl = config.imageServer + item.attachurl;
                item.detailattachurl = config.imageServer + item.detailattachurl;
            });

            results[1].forEach(function (item) {
                item.attachurl = config.imageServer + item.attachurl;
            });
            
            data.item.noticeslist = results[0];
            data.item.tipslist = results[1];
        }
        res.json(data);
    });
});

router.post('/codelist', function (req, res, next) {
	var version = req.headers.version;
    var result = {
   		'result': 0,
   		'message': '',
   		'codelist': null,
   		'regionlist': regioncode
    };
    
    codeModel.list( function (dbresult, list) {
        if (!dbresult) {
            result.result = -1;
            result.message = '코드 리스트 조회 시 에러가 발생했습니다.';
        }
        else {
            var codeData = [];
            var item = [];
            var listitem = [];
            var count = 0;
            
            for (var i = 0 ; i < list.length ; ++i) {
                if (list[i].code.length == 3) {
                    if (count > 0)
                        codeData.push(item);
                    item = {
                        'code': list[i].code,
                        'value': list[i].value,
                        'list': []
                    };
                    count++;
                } else {
                    listitem = {
                        'code': list[i].code,
                        'value': list[i].value
                    }
                    item.list.push(listitem);
                }
            }
            
            if (count > 0)
                codeData.push(item);
            
            result.codelist = codeData;
        }
        res.json(result);
    });
});

module.exports = router;