var express = require('express'),
    bodyParser = require('body-parser'),
    //logger = require('morgan'),
	config = require('./config'),
	errorHandlers = require('./common/errorhandlers'),
    index = require('./routes/index'),
    experts = require('./routes/experts'),
    faqs = require('./routes/faqs'),
    notices = require('./routes/notices'),
    users = require('./routes/users'),
    api_experts = require('./routes/api_experts'),
    api_markets = require('./routes/api_markets'),
    api_pays = require('./routes/api_pays'),
    api_qnas = require('./routes/api_qnas'),
    api_users = require('./routes/api_users'),
	app = express();

require('./format/codeFormat');
require('./format/dateFormat');

//app.use(logger('dev'));
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());

// 라우터 설정
app.use('/', index);
app.use('/experts', experts);
app.use('/faqs', faqs);
app.use('/notices', notices);
app.use('/users', users);
app.use('/api/experts', api_experts);
app.use('/api/markets', api_markets);
app.use('/api/pays', api_pays);
app.use('/api/qnas', api_qnas);
app.use('/api/users', api_users);

app.use(errorHandlers.notFound);
app.use(errorHandlers.error);

app.listen(config.servicePort);
console.log("%s running on port %s.", config.name, config.servicePort);