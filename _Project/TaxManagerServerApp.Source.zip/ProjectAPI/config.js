var config = {
    name: 'TaxAccountingAPI',
	servicePort: 3000,
    imageServer: 'http://52.78.37.73:3002',
    gcm: {
        packagename: 'com.pcm.pcmmanager',
        server_access_key: 'AIzaSyAPE8FqNwZrF0w_0k-LOcq6Ry-5gChWLuI'
    },
    token: {
    	secret: 'TAM_API_Secret',
        timeout: 60 * 60 * 24 * 30
    },
	redis: {
        port: 6379,
        host: '127.0.0.1',
        maxConnections: 10
    }
};

module.exports = config;