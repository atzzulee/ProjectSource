var config = {
    name: 'TaxAccountingService',
    serviceIP: 'localhost',
	servicePort: 3003,
    adminApiServicePort: 3001,
    notResultServiceTime: 1000 * 60, // 60초에 1번씩 수행
    resultServiceTime: 1000 * 5, // 5초에 1번씩 수행
	redis: {
        port: 6379,
        host: '127.0.0.1',
        maxConnections: 20
    },
	token: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoiUHJvamVjdEFkbWluQVBJIiwiaWF0IjoxNDY3MTczMDgyLCJleHAiOjE0OTg3MDkwODJ9.detAgdjq54WM8Y1ZJwodjtT3EoWe5z53vXkj14AHhbI'
};

module.exports = config;