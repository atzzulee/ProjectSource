var request = require("request"),
	config = require('../config');

exports.getRequest = function getRequest(routerUrl, method) {
    return new Promise( function (resolve, reject) {
        request({
            'uri': 'http://' + config.serviceIP + ':' + config.adminApiServicePort + routerUrl,
            'headers': { 'Authorization': 'Bearer ' + config.token },
            'method': method,
            'timeout': 10000,
            'followRedirect': true,
            'maxRedirects': 10
        }, function (err, res, data) {
            if (data != null) {
                resolve(data);
            }
            else {
                reject(Error('AdminAPI 에러.'));
            }
        });
    });
}