var config = require('../config');

var poolRedis = require('pool-redis')({
  'host': config.redis.host,
  'port': config.redis.port,
  'maxConnections': config.redis.maxConnections
});

exports.add = function add(key, value, cb) {
    poolRedis.getClient( function (client, done) {
        client.rpush(key, value, function (err, result) {
            if (err) {
                console.log('Create Fail.');
                cb(false);
            }
            else {
                console.log('Create Success.');
                cb(true);
            }
        
            poolRedis.release(client);
        });
     });
};

exports.remove = function remove(key, value, cb) {
    poolRedis.getClient( function (client, done) {
        client.lrem(key, 0, value, function (err, result) {
            if (err) {
                console.log('Delete Fail.');
                cb(false);
            }
            else {
                console.log('Delete Success.');
                cb(true);
            }
            
            poolRedis.release(client);
       });
    });
};
            
exports.select = function select(key, cb) {
    poolRedis.getClient( function (client, done) {
        client.lrange(key, 0, -1, function (err, result) {
            if (err) {
                console.log('List Fail.');
                cb(false);
            }
            else {
                if (result != null) {
                    console.log('List Success.');
                    cb(true, result);
                }
                else {
                    console.log('List Fail.');
                    cb(false);
                }
            }
            
            poolRedis.release(client);
        });
    });
};
