var express = require('express'),
	request = require("request"),
	logger = require('morgan'),
	common = require('./common/common'),
	redisHelper = require("./common/redisHelper"),
	config = require('./config'),
	app = express(),
	router = express.Router();

var redisKey = 'BidCheckList';
var mongoService = null;
var redisService = null;

app.use(logger('dev'));
app.use('/', router);

router.get('/', function (req, res) {
	res.json('');
});

var mongoDB = null;

function serviceExecute() {
    var promise = common.getRequest('/services/bidCheckList', 'GET');
    promise.then( function (result) {
		var obj = JSON.parse(result);
		if (obj.result == 0) {
			console.log('AdminAPI 조회 성공.');
			mongoDB = obj.list;

			bidCheckExecute();
		}
		else {
            console.log('AdminAPI 조회 실패. ' + obj.message);
			initMongoService();
		}
    }, function (err) {
		console.log('AdminAPI 조회 에러.');
		initMongoService();
	});
}

function initMongoService() {
	mongoDB = null;

	if (mongoService != null) {
		clearInterval(mongoService);
	}

	mongoService = setInterval(serviceExecute, eval(config.notResultServiceTime));
	console.log('Mongo 서비스 10분대기.');
}

function bidCheckExecute() {
	if (redisService != null) {
		clearInterval(redisService);
	}

	redisHelper.select(redisKey, function (result, arr) {
		if (result) {
			for (var item in mongoDB) {
				var equalFlag = true;

				for (var i = 0; i < arr.length; i++) {
					var value = arr[i].split('|');

					if (mongoDB[item].marketsn == value[0]) {
						equalFlag = false;
						break;
					}
				}

				if (equalFlag) {
					var promise = new Promise( function (resolve, reject) {
						var date = new Date(mongoDB[item].regdate);
						date.setDate(date.getDate() + mongoDB[item].enddate);
						var value = mongoDB[item].marketsn + '|' + mongoDB[item].status + '|' + date.toJSON();

						redisHelper.add(redisKey, value, function (result) {
							if (result) {
								resolve(result);
							} else {
								reject(Error('Redis 저장실패.'));
							}
						});
					});

					promise.then( function (result) {
						console.log('Redis 저장성공.');
					}, function (err) {
						console.log('Redis 저장실패.');
					});
				}
			}
		}

		initMongoService();
		setTimeout(bidRedisCheckList, eval(config.resultServiceTime));
	});
}

function bidRedisCheckList() {
	console.log('Redis 서비스 시작.');

	if (redisService != null) {
		clearInterval(redisService);
	}

	redisHelper.select(redisKey, function (result, arr) {
		if (result) {
			if (arr.length > 0) {
				var now = new Date().toJSON();

				for (var i = 0; i < arr.length; i++) {
					var value = arr[i].split('|');

					if (now >= value[2]) {
						var promise = new Promise( function (resolve, reject) {
							var item = arr[i];
							var marketsn = value[0];
							var routerUrl = '';
							if (value[1] == '110_002')
								routerUrl = 'bidClose';
							else
								routerUrl = 'bidCancel';
							var isSuccess = false;

							var promise2 = common.getRequest('/services/' + routerUrl + '/' + marketsn, 'POST');
							promise2.then( function (result) {
								var obj = JSON.parse(result);
								if (obj.result == 0) {
									isSuccess = true;
									console.log('AdminAPI 처리 성공.');
								}
								else {
									console.log('AdminAPI 처리 실패. ' + obj.message);
								}

								if (isSuccess) {
									resolve(item);
								}
								else {
									reject(Error('삭제실패.'));
								}
							}, function (err) {
								console.log('AdminAPI 처리 에러.');
							});
						});
						promise.then( function (result) {
							redisHelper.remove(redisKey, result, function (result) {
								if (result) {
									console.log('Redis 삭제성공.');
								} else {
									console.log('Redis 삭제실패.');
								}
							});

							}, function (err) {
								console.log('Redis 삭제실패.');
						});
					}
				}

				// 카운트 서비스 동작 설정
				redisService = setInterval(bidRedisCheckList, eval(config.resultServiceTime));
				console.log('Redis 서비스 10초대기.');
			}
			else {
				console.log('Redis 서비스 종료.');
			}
		}
		else {
			console.log('Redis 서비스 종료.');
		}
	});
}

app.listen(config.servicePort, () => {
	console.log("%s running on port %s.", config.name, config.servicePort);
	serviceExecute();
});