﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.IO;

namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            for(int i = 1000; i <= 9999; i++)
            {
                string url = string.Format("http://wowpro.wownet.co.kr/future/player/BottomSms.asp?analid={0}&mtype=M", i);
                ReadHTMLSource(url);
            }
        }


        private string ReadHTMLSource(string url)
        {
            WebResponse response = null;
            Stream responseStream = null;
            StreamReader reader = null;
            string str2;
            try
            {
                response = WebRequest.Create(url).GetResponse();
                responseStream = response.GetResponseStream();
                reader = new StreamReader(responseStream, Encoding.UTF8);
                str2 = reader.ReadToEnd();
            }
            catch (Exception ex)
            {
                str2 = ex.Message;
            }
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                    reader.Dispose();
                    reader = null;
                }
                if (responseStream != null)
                {
                    responseStream.Close();
                    responseStream.Dispose();
                    responseStream = null;
                }
                if (response != null)
                {
                    response.Close();
                    response = null;
                }
            }
            return str2;
        }

        private bool ReadHTMLSource2(string url)
        {
            WebResponse response = null;
            Stream responseStream = null;
            StreamReader reader = null;
            string str2;
            try
            {
                response = WebRequest.Create(url).GetResponse();
                responseStream = response.GetResponseStream();

                if (response.ContentLength > 2000)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                str2 = ex.Message;
            }
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                    reader.Dispose();
                    reader = null;
                }
                if (responseStream != null)
                {
                    responseStream.Close();
                    responseStream.Dispose();
                    responseStream = null;
                }
                if (response != null)
                {
                    response.Close();
                    response = null;
                }
            }

            return false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string date = DateTime.Now.ToString("yyyyMMdd");

            string str = "http://180.68.207.250/G4WowHtm/일반_백진수대표{0}08{1}{2}.htm?1";
            bool flag = false;
            string _url = string.Empty;
            for(int i = 1; i <= 59; i++)
            {
                for (int j = 1; j <= 59; j++)
                {
                    string url = string.Format(str, date, i.ToString("00"), j.ToString("00"));
                    flag = ReadHTMLSource2(url);

                    if (flag)
                    {
                        _url = url;
                        break;
                    }
                }

                if (flag)
                {
                    break;
                }
            }

            if (flag)
            {
                textBox1.Text = _url;
            }
        }
    }
}
